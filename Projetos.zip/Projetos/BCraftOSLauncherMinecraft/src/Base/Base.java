package Base;

import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import Screens.Servidores;

import Screens.Biblioteca;
import Screens.Console;
import Screens.Jogar;
import Screens.Config;
import Screens.Logs;
import Screens.Skins;
import Screens.Login;

import Core.Login.Conta;
import Core.Login.GerenciadorLogin;
import Core.Login.LoginMicrosoft;

public class Base extends JPanel {

    private static final int TEMPO_INATIVIDADE = 30_000;

    private Image imagemFundo;

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel conteudo = new JPanel(cardLayout);
    private final Timer timerInatividade;

    private Window janela;
    private AWTEventListener detectorAtividade;

    // Login: a logica fica no Core.Login, a tela so tem layout.
    private final GerenciadorLogin login = new GerenciadorLogin(new File("Usuarios"));
    private final Login telaLogin = new Login();
    private JPanel barraInferior;
    private final JLabel rotuloConta = new JLabel();
    private boolean logado = false;

    public Base() {
        setLayout(new BorderLayout());
        setOpaque(true);

        carregarImagemFundo();

        // Todas as telas ficam nesta area central.
        // O fundo e a barra inferior nao sao removidos.
        conteudo.setOpaque(false);

        JPanel telaInicial = criarTelaInicial();

        // A tela de login cobre tudo ate o jogador entrar.
        conteudo.add(telaLogin, "login");
        conteudo.add(telaInicial, "inicio");
        conteudo.add(new Biblioteca(), "biblioteca");
        conteudo.add(new Servidores(), "servidores");
        conteudo.add(new Console(), "console");
        conteudo.add(new Jogar(), "jogar");
        conteudo.add(new Config(), "config");
        conteudo.add(new Logs(), "logs");
        conteudo.add(new Skins(), "skins");

        add(conteudo, BorderLayout.CENTER);

        // Barra original com os sete botoes (so aparece depois do login).
        barraInferior = criarBarraInferior();
        barraInferior.setVisible(false);
        add(barraInferior, BorderLayout.SOUTH);

        // Temporizador de inatividade.
        timerInatividade = new Timer(
                TEMPO_INATIVIDADE,
                e -> {
                    if (logado) {
                        mostrarTela("inicio");
                    }
                }
        );

        timerInatividade.setRepeats(false);

        instalarDetectorDeAtividade();

        cardLayout.show(conteudo, "login");
        configurarLogin();
    }

    // ------------------------------------------------------------ Login

    /**
     * Liga a tela de login ao Core.Login. Varias contas ficam salvas e a senha e pedida em TODO login.
     * Os retornos do Core vem de outra thread, entao voltam pela EDT.
     */
    private void configurarLogin() {
        atualizarContas();
        telaLogin.mostrarContas();

        telaLogin.setOnEntrarConta((id, senha) -> {
            telaLogin.setOcupado(true);
            telaLogin.esconderCodigo();
            telaLogin.setStatus("Verificando a senha...");
            login.entrarConta(id, senha, this::mostrarCodigoLogin, this::statusLogin, retornoLogin());
        });

        telaLogin.setOnAdicionarPirata((nome, senha, confirmacao) -> {
            telaLogin.setOcupado(true);
            telaLogin.setStatus("Criando a conta...");
            login.criarPirata(nome, senha, confirmacao, retornoLogin());
        });

        telaLogin.setOnAdicionarMicrosoft((senha, confirmacao) -> {
            telaLogin.setOcupado(true);
            telaLogin.esconderCodigo();
            telaLogin.setStatus("Conectando com a Microsoft...");
            login.criarMicrosoft(senha, confirmacao, this::mostrarCodigoLogin, this::statusLogin, retornoLogin());
        });

        telaLogin.setOnRemoverConta(id -> {
            login.removerConta(id);
            atualizarContas();
            telaLogin.mostrarContas();
        });

        telaLogin.setOnCancelar(login::cancelar);
        telaLogin.setOnAbrirPagina(this::abrirNavegador);
    }

    private void atualizarContas() {
        List<Login.ContaItem> itens = new ArrayList<>();
        for (GerenciadorLogin.ContaResumo r : login.listarContas()) {
            itens.add(new Login.ContaItem(r.id(), r.nome(), r.tipo().rotulo()));
        }
        telaLogin.setContas(itens, login.ultimaContaId());
    }

    private void mostrarCodigoLogin(LoginMicrosoft.Codigo codigo) {
        SwingUtilities.invokeLater(() -> {
            telaLogin.mostrarCodigo(codigo.codigo(), codigo.url());
            abrirNavegador(codigo.url());
        });
    }

    private void statusLogin(String texto) {
        SwingUtilities.invokeLater(() -> telaLogin.setStatus(texto));
    }

    private GerenciadorLogin.Retorno retornoLogin() {
        return new GerenciadorLogin.Retorno() {
            @Override
            public void aoSucesso(Conta conta) {
                SwingUtilities.invokeLater(() -> entrou(conta));
            }

            @Override
            public void aoErro(String mensagem) {
                SwingUtilities.invokeLater(() -> {
                    telaLogin.esconderCodigo();
                    telaLogin.setOcupado(false);
                    telaLogin.limparSenhas();
                    telaLogin.setErro(mensagem);
                });
            }
        };
    }

    private void entrou(Conta conta) {
        logado = true;
        telaLogin.esconderCodigo();
        telaLogin.setOcupado(false);
        telaLogin.limparSenhas();
        telaLogin.setStatus(" ");
        rotuloConta.setText(conta.getNome() + "  \u00b7  " + conta.getTipo().rotulo());
        barraInferior.setVisible(true);
        revalidate();
        mostrarTela("inicio");
    }

    /** Desloga e volta para a lista de contas (a senha sera pedida de novo). As contas continuam salvas. */
    public void sair() {
        login.sair();
        logado = false;
        timerInatividade.stop();
        barraInferior.setVisible(false);
        telaLogin.setOcupado(false);
        telaLogin.esconderCodigo();
        atualizarContas();
        telaLogin.mostrarContas();
        cardLayout.show(conteudo, "login");
        revalidate();
        repaint();
    }

    /** Conta que esta logada (nome, UUID, token) - sera usada pela logica do JOGAR. Null se ninguem logou. */
    public Conta getConta() {
        return login.getContaAtual();
    }

    private void abrirNavegador(String url) {
        try {
            if (Desktop.isDesktopSupported()
                    && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(URI.create(url));
            }
        } catch (Exception ignorado) {
            // sem navegador: o jogador abre o link mostrado na tela
        }
    }

    private void carregarImagemFundo() {
        File arquivo = new File(
                "src/ImagenMenu/default_background.jpg"
        );

        if (arquivo.exists()) {
            imagemFundo = new ImageIcon(
                    arquivo.getAbsolutePath()
            ).getImage();
        } else {
            System.out.println(
                    "Imagem nao encontrada: "
                            + arquivo.getAbsolutePath()
            );
        }
    }

    private JPanel criarTelaInicial() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setOpaque(false);

        // Conta logada + "Trocar conta" no canto. O resto fica livre para a arte de fundo.
        painel.add(criarChipDaConta(), BorderLayout.NORTH);

        return painel;
    }

    private JPanel criarChipDaConta() {
        JPanel faixa = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        faixa.setOpaque(false);

        JPanel chip = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 6)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(12, 35, 65, 155));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.setColor(new Color(255, 255, 255, 35));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.dispose();
            }
        };
        chip.setOpaque(false);

        rotuloConta.setForeground(new Color(240, 242, 247));
        rotuloConta.setFont(new Font("SansSerif", Font.BOLD, 12));

        JButton trocar = new JButton("Trocar conta");
        trocar.setFont(new Font("SansSerif", Font.BOLD, 12));
        trocar.setForeground(new Color(150, 205, 255));
        trocar.setContentAreaFilled(false);
        trocar.setBorderPainted(false);
        trocar.setFocusPainted(false);
        trocar.setMargin(new Insets(0, 0, 0, 0));
        trocar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        trocar.addActionListener(e -> sair());

        chip.add(rotuloConta);
        chip.add(trocar);
        faixa.add(chip);
        return faixa;
    }

    private JPanel criarBarraInferior() {
        JPanel barraInferior = new JPanel(
                new GridBagLayout()
        );

        barraInferior.setOpaque(false);
        barraInferior.setBorder(
                BorderFactory.createEmptyBorder(
                        12, 16, 16, 16
                )
        );

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 4, 0, 4);

        // Grupo esquerdo
        JPanel grupoEsquerdo = criarGrupo();

        JButton biblioteca = criarBotao("▤", "Biblioteca");
        biblioteca.addActionListener(
                e -> mostrarTela("biblioteca")
        );

        JButton servidores = criarBotao("◎", "Servidores");
        servidores.addActionListener(e ->
                mostrarTela("servidores")
        );

        JButton console = criarBotao("⌘", "Console");
        console.addActionListener(
                e -> mostrarTela("console")
        );

        grupoEsquerdo.add(biblioteca);
        grupoEsquerdo.add(servidores);
        grupoEsquerdo.add(console);

        // Botao central
        JButton jogar = criarBotao("▶", "JOGAR");
        jogar.setPreferredSize(new Dimension(104, 62));
        jogar.addActionListener(
                e -> mostrarTela("jogar")
        );

        // Grupo direito
        JPanel grupoDireito = criarGrupo();

        JButton logs = criarBotao("▧", "Logs");
        logs.addActionListener(
                e -> mostrarTela("logs")
        );
        JButton skins = criarBotao("♙", "Skins");
        skins.addActionListener(
                e -> mostrarTela("skins")
        );
        JButton config = criarBotao("⚙", "Config");
        config.addActionListener(
                e -> mostrarTela("config")
        );

        grupoDireito.add(logs);
        grupoDireito.add(skins);
        grupoDireito.add(config);

        // Mantem a distribuicao original dos grupos.
        gbc.gridx = 0;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.LINE_END;
        gbc.insets = new Insets(0, 0, 0, 12);
        barraInferior.add(grupoEsquerdo, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 12, 0, 12);
        barraInferior.add(jogar, gbc);

        gbc.gridx = 2;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(0, 12, 0, 0);
        barraInferior.add(grupoDireito, gbc);

        return barraInferior;
    }

    private JPanel criarGrupo() {
        JPanel grupo = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 4, 0)
        );

        grupo.setOpaque(false);
        return grupo;
    }

    private JButton criarBotao(String icone, String texto) {
        JButton botao = new JButton(
                "<html><div style='text-align:center;'>"
                        + "<span style='font-size:19pt;'>"
                        + icone
                        + "</span><br>"
                        + "<span style='font-size:10pt;'>"
                        + texto
                        + "</span></div></html>"
        );

        botao.setPreferredSize(new Dimension(94, 62));
        botao.setMinimumSize(new Dimension(94, 62));
        botao.setMaximumSize(new Dimension(94, 62));

        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("SansSerif", Font.BOLD, 11));

        botao.setHorizontalAlignment(SwingConstants.CENTER);
        botao.setVerticalAlignment(SwingConstants.CENTER);
        botao.setHorizontalTextPosition(SwingConstants.CENTER);
        botao.setVerticalTextPosition(SwingConstants.CENTER);

        botao.setMargin(new Insets(0, 0, 0, 0));
        botao.setBorder(BorderFactory.createEmptyBorder());
        botao.setBorderPainted(false);
        botao.setContentAreaFilled(false);
        botao.setOpaque(false);
        botao.setFocusPainted(false);
        botao.setRolloverEnabled(true);

        botao.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );

        // Pinta apenas o fundo arredondado translucido.
        botao.setUI(new BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();

                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                Color cor = b.getModel().isRollover()
                        ? new Color(83, 165, 235, 225)
                        : new Color(24, 66, 112, 190);

                g2.setColor(cor);
                g2.fillRoundRect(
                        0, 0,
                        b.getWidth(), b.getHeight(),
                        18, 18
                );

                g2.dispose();

                super.paint(g, c);
            }
        });

        return botao;
    }

    public void mostrarTela(String nomeTela) {
        cardLayout.show(conteudo, nomeTela);
        conteudo.revalidate();
        conteudo.repaint();
        repaint();

        reiniciarTemporizador();
    }

    private void instalarDetectorDeAtividade() {
        long mascaras =
                AWTEvent.MOUSE_EVENT_MASK
                        | AWTEvent.MOUSE_MOTION_EVENT_MASK
                        | AWTEvent.MOUSE_WHEEL_EVENT_MASK
                        | AWTEvent.KEY_EVENT_MASK;

        detectorAtividade = evento -> {
            if (janela == null || !janela.isActive()) {
                return;
            }

            Object origem = evento.getSource();

            if (!(origem instanceof Component)) {
                return;
            }

            Component componente = (Component) origem;
            Window janelaDoEvento;

            if (componente instanceof Window) {
                janelaDoEvento = (Window) componente;
            } else {
                janelaDoEvento =
                        SwingUtilities.getWindowAncestor(componente);
            }

            if (janelaDoEvento == janela) {
                reiniciarTemporizador();
            }
        };

        Toolkit.getDefaultToolkit().addAWTEventListener(
                detectorAtividade,
                mascaras
        );
    }

    private void reiniciarTemporizador() {
        if (timerInatividade != null && isDisplayable()) {
            timerInatividade.restart();
        }
    }

    @Override
    public void addNotify() {
        super.addNotify();

        janela = SwingUtilities.getWindowAncestor(this);

        if (timerInatividade != null) {
            timerInatividade.restart();
        }
    }

    @Override
    public void removeNotify() {
        if (timerInatividade != null) {
            timerInatividade.stop();
        }

        if (detectorAtividade != null) {
            Toolkit.getDefaultToolkit().removeAWTEventListener(
                    detectorAtividade
            );
        }

        super.removeNotify();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(
                RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR
        );

        if (imagemFundo != null) {
            g2.drawImage(
                    imagemFundo,
                    0, 0,
                    getWidth(), getHeight(),
                    this
            );
        } else {
            GradientPaint degrade = new GradientPaint(
                    0, 0,
                    new Color(16, 29, 57),
                    getWidth(), getHeight(),
                    new Color(75, 155, 230)
            );

            g2.setPaint(degrade);
            g2.fillRect(
                    0, 0,
                    getWidth(), getHeight()
            );
        }

        g2.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame janela = new JFrame("BCraft Launcher");

            janela.setDefaultCloseOperation(
                    JFrame.EXIT_ON_CLOSE
            );

            janela.setContentPane(new Base());
            janela.setSize(1024, 640);
            janela.setMinimumSize(new Dimension(800, 500));
            janela.setLocationRelativeTo(null);
            janela.setVisible(true);
        });
    }
}