package Core.Jogar;

public class VersaoList {
}
