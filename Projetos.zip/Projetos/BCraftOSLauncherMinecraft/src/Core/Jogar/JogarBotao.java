package Core.Jogar;

public class JogarBotao {
}
