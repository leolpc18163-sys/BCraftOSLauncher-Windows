package Core.Skins;

public class ResetarVisao {
}
