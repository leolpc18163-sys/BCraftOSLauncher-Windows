package Core.Skins;

public class CamadaExterna {
}
