package Core.Skins;

public class Remover {
}
