package Core.Skins;

public class Adicionar {
}
