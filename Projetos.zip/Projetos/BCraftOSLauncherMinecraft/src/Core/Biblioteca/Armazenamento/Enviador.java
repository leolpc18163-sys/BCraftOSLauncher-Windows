package Core.Biblioteca.Armazenamento;

public class Enviador {
}
