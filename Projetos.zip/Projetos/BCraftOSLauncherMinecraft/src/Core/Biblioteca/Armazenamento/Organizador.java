package Core.Biblioteca.Armazenamento;

public class Organizador {
}
