package Core.Biblioteca.Mods;

public class URLs {
}
