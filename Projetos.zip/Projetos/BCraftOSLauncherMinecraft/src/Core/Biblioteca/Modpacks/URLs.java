package Core.Biblioteca.Modpacks;

public class URLs {
}
