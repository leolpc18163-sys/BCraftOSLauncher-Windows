package Core.Biblioteca.Modpacks;

public class Instalador {
}
