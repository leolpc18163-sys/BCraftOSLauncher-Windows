package Core.Biblioteca.Verções;

public class URLs {
}
