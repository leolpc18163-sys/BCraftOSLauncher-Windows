package Core.Biblioteca.Verções;

public class Instalador {
}
