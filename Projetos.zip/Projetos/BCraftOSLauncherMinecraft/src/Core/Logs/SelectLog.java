package Core.Logs;

public class SelectLog {
}
