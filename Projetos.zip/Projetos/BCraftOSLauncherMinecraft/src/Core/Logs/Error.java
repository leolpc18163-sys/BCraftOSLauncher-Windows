package Core.Logs;

public class Error {
}
