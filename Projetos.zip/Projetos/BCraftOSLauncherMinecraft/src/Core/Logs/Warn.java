package Core.Logs;

public class Warn {
}
