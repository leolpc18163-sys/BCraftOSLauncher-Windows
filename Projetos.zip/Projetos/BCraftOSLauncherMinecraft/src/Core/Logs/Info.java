package Core.Logs;

public class Info {
}
