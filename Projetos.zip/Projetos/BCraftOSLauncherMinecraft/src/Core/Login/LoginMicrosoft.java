package Core.Login;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Login com conta Microsoft (fluxo de código de dispositivo, sem navegador embutido):
 *
 *   1. a Microsoft devolve um código curto + um link;
 *   2. o jogador abre o link no navegador e digita o código;
 *   3. Microsoft -> Xbox Live -> XSTS -> Minecraft Services -> perfil (nome e UUID).
 *
 * Precisa de um "Application (client) ID" de um app registrado no Azure (veja clientIdConfigurado()).
 * Esta classe não usa Swing: quem chama é que atualiza a tela.
 */
public final class LoginMicrosoft {

    /** Código que o jogador precisa digitar na página da Microsoft. */
    public record Codigo(String codigo, String url, int expiraEmSegundos) { }

    private record Resp(int status, Map<String, Object> corpo) { }

    private static final String ESCOPO = "XboxLive.signin offline_access";
    private static final String MS = "https://login.microsoftonline.com/consumers/oauth2/v2.0/";

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private final Path arquivoClientId;

    public LoginMicrosoft(File pastaUsuarios) {
        this.arquivoClientId = pastaUsuarios.toPath().resolve("microsoft_client_id.txt");
    }

    // ------------------------------------------------------ configuração

    /**
     * O client ID é lido (nesta ordem) de: propriedade -Dbcraft.ms.clientid,
     * variável de ambiente BCRAFT_MS_CLIENT_ID, ou do arquivo Usuarios/microsoft_client_id.txt.
     */
    public boolean clientIdConfigurado() {
        return lerClientId() != null;
    }

    private String lerClientId() {
        String v = System.getProperty("bcraft.ms.clientid");
        if (v == null || v.isBlank()) v = System.getenv("BCRAFT_MS_CLIENT_ID");
        if ((v == null || v.isBlank()) && Files.isRegularFile(arquivoClientId)) {
            try {
                v = Files.readString(arquivoClientId);
            } catch (IOException ignorado) { }
        }
        return v == null || v.isBlank() ? null : v.trim();
    }

    private String exigirClientId() throws ErroLogin {
        String id = lerClientId();
        if (id == null) {
            throw new ErroLogin("Login Microsoft ainda não configurado: coloque o Client ID do seu app Azure "
                    + "no arquivo Usuarios/microsoft_client_id.txt.");
        }
        return id;
    }

    // ------------------------------------------------------- login novo

    /**
     * Faz o login completo. Bloqueia até terminar (chame fora da thread da tela).
     *
     * @param aoCodigo  recebe o código/link assim que a Microsoft responde
     * @param aoStatus  recebe mensagens de progresso
     * @param cancelado devolve true quando o jogador cancelou
     */
    public Conta entrar(Consumer<Codigo> aoCodigo, Consumer<String> aoStatus,
                        BooleanSupplier cancelado) throws ErroLogin {
        String clientId = exigirClientId();

        status(aoStatus, "Pedindo o código de acesso à Microsoft...");
        Map<String, Object> dc = enviarForm(MS + "devicecode",
                Map.of("client_id", clientId, "scope", ESCOPO)).corpo();

        String deviceCode = Json.texto(dc, "device_code");
        String userCode = Json.texto(dc, "user_code");
        if (deviceCode == null || userCode == null) {
            throw new ErroLogin("A Microsoft recusou o pedido de login: " + descricaoErro(dc));
        }
        String url = Json.texto(dc, "verification_uri");
        if (url == null) url = "https://www.microsoft.com/link";
        int expira = (int) Json.numero(dc, "expires_in", 900);
        long intervalo = Json.numero(dc, "interval", 5);

        if (aoCodigo != null) aoCodigo.accept(new Codigo(userCode, url, expira));
        status(aoStatus, "Aguardando você entrar no navegador...");

        long limite = System.currentTimeMillis() + expira * 1000L;
        while (true) {
            dormir(intervalo * 1000, cancelado);
            if (System.currentTimeMillis() > limite) {
                throw new ErroLogin("O código expirou. Clique em entrar para gerar outro.");
            }

            Map<String, Object> t = enviarForm(MS + "token", Map.of(
                    "grant_type", "urn:ietf:params:oauth:grant-type:device_code",
                    "client_id", clientId,
                    "device_code", deviceCode)).corpo();

            String acesso = Json.texto(t, "access_token");
            if (acesso != null) {
                return completar(acesso, Json.texto(t, "refresh_token"), aoStatus);
            }

            String erro = Json.texto(t, "error");
            if ("authorization_pending".equals(erro)) continue;
            if ("slow_down".equals(erro)) { intervalo += 5; continue; }
            if ("authorization_declined".equals(erro)) throw new ErroLogin("Você recusou o login no navegador.");
            if ("expired_token".equals(erro)) throw new ErroLogin("O código expirou. Clique em entrar para gerar outro.");
            throw new ErroLogin("Falha no login Microsoft: " + descricaoErro(t));
        }
    }

    // ----------------------------------------------------- renovar sessão

    /** Usa o refresh token salvo para entrar de novo sem pedir código. */
    public Conta renovar(Conta conta, Consumer<String> aoStatus) throws ErroLogin {
        final String expirada = "Sessão expirada. Entre com a Microsoft de novo.";
        if (conta.getRefreshToken() == null) throw new ErroLogin(expirada);
        String clientId = exigirClientId();

        status(aoStatus, "Renovando a sessão Microsoft...");
        Map<String, Object> t = enviarForm(MS + "token", Map.of(
                "grant_type", "refresh_token",
                "client_id", clientId,
                "refresh_token", conta.getRefreshToken(),
                "scope", ESCOPO)).corpo();

        String acesso = Json.texto(t, "access_token");
        if (acesso == null) throw new ErroLogin(expirada);

        String novoRefresh = Json.texto(t, "refresh_token");
        return completar(acesso, novoRefresh != null ? novoRefresh : conta.getRefreshToken(), aoStatus);
    }

    // -------------------------------------- Xbox Live -> XSTS -> Minecraft

    private Conta completar(String msToken, String refresh, Consumer<String> aoStatus) throws ErroLogin {
        // 1) Xbox Live
        status(aoStatus, "Entrando no Xbox Live...");
        Map<String, Object> propsXbl = new LinkedHashMap<>();
        propsXbl.put("AuthMethod", "RPS");
        propsXbl.put("SiteName", "user.auth.xboxlive.com");
        propsXbl.put("RpsTicket", "d=" + msToken);
        Map<String, Object> corpoXbl = new LinkedHashMap<>();
        corpoXbl.put("Properties", propsXbl);
        corpoXbl.put("RelyingParty", "http://auth.xboxlive.com");
        corpoXbl.put("TokenType", "JWT");

        Resp xbl = enviarJson("https://user.auth.xboxlive.com/user/authenticate", corpoXbl);
        String xblToken = Json.texto(xbl.corpo(), "Token");
        if (xbl.status() != 200 || xblToken == null) {
            throw new ErroLogin("Não foi possível entrar no Xbox Live (código " + xbl.status() + ").");
        }

        // 2) XSTS
        status(aoStatus, "Pedindo autorização ao Xbox...");
        Map<String, Object> propsXsts = new LinkedHashMap<>();
        propsXsts.put("SandboxId", "RETAIL");
        propsXsts.put("UserTokens", List.of(xblToken));
        Map<String, Object> corpoXsts = new LinkedHashMap<>();
        corpoXsts.put("Properties", propsXsts);
        corpoXsts.put("RelyingParty", "rp://api.minecraftservices.com/");
        corpoXsts.put("TokenType", "JWT");

        Resp xsts = enviarJson("https://xsts.auth.xboxlive.com/xsts/authorize", corpoXsts);
        if (xsts.status() == 401) throw new ErroLogin(mensagemXbox(Json.numero(xsts.corpo(), "XErr", 0)));
        String xstsToken = Json.texto(xsts.corpo(), "Token");
        String uhs = uhs(xsts.corpo());
        if (xsts.status() != 200 || xstsToken == null || uhs == null) {
            throw new ErroLogin("O Xbox não autorizou o login (código " + xsts.status() + ").");
        }

        // 3) Minecraft Services
        status(aoStatus, "Entrando no Minecraft...");
        Map<String, Object> corpoMc = new LinkedHashMap<>();
        corpoMc.put("identityToken", "XBL3.0 x=" + uhs + ";" + xstsToken);
        Resp mc = enviarJson("https://api.minecraftservices.com/authentication/login_with_xbox", corpoMc);
        if (mc.status() == 403) {
            throw new ErroLogin("A Mojang não aceitou o app Azure. Novos apps precisam de aprovação da Mojang "
                    + "antes de poder logar jogadores (veja o formulário de revisão de apps do Minecraft).");
        }
        String mcToken = Json.texto(mc.corpo(), "access_token");
        if (mc.status() != 200 || mcToken == null) {
            throw new ErroLogin("Não foi possível entrar no Minecraft (código " + mc.status() + ").");
        }
        long validade = Json.numero(mc.corpo(), "expires_in", 86_400);

        // 4) Perfil (nome + UUID). Sem perfil = conta sem o jogo.
        status(aoStatus, "Carregando seu perfil...");
        Resp perfil = buscar("https://api.minecraftservices.com/minecraft/profile", mcToken);
        if (perfil.status() == 404) {
            throw new ErroLogin("Esta conta Microsoft não tem o Minecraft Java Edition. "
                    + "Se quiser jogar mesmo assim, use a aba Pirata.");
        }
        String nome = Json.texto(perfil.corpo(), "name");
        String id = Json.texto(perfil.corpo(), "id");
        if (perfil.status() != 200 || nome == null || id == null) {
            throw new ErroLogin("Não foi possível ler o perfil do Minecraft (código " + perfil.status() + ").");
        }

        return new Conta(ContaTipo.MICROSOFT, nome, comTracos(id), mcToken, refresh,
                System.currentTimeMillis() + validade * 1000L);
    }

    private static String uhs(Map<String, Object> corpo) {
        Map<String, Object> claims = Json.mapa(corpo.get("DisplayClaims"));
        List<Object> xui = Json.lista(claims.get("xui"));
        if (xui.isEmpty()) return null;
        return Json.texto(Json.mapa(xui.get(0)), "uhs");
    }

    private static String mensagemXbox(long xerr) {
        if (xerr == 2148916233L) return "Esta conta Microsoft não tem perfil Xbox. Crie um em xbox.com e tente de novo.";
        if (xerr == 2148916235L) return "O Xbox Live não está disponível no país desta conta.";
        if (xerr == 2148916236L || xerr == 2148916237L) return "Esta conta precisa de verificação de adulto no Xbox.";
        if (xerr == 2148916238L) return "Conta de menor de idade: precisa fazer parte de uma Família Microsoft.";
        return "O Xbox recusou o login (erro " + xerr + ").";
    }

    private static String comTracos(String id) {
        return id.length() == 32
                ? id.replaceFirst("(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{12})",
                                  "$1-$2-$3-$4-$5")
                : id;
    }

    private static String descricaoErro(Map<String, Object> corpo) {
        String d = Json.texto(corpo, "error_description");
        if (d == null) d = Json.texto(corpo, "error");
        if (d == null) return "resposta inesperada";
        int quebra = d.indexOf('\n');
        return quebra > 0 ? d.substring(0, quebra) : d;
    }

    // ---------------------------------------------------------------- HTTP

    private Resp enviarForm(String url, Map<String, String> campos) throws ErroLogin {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : campos.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8))
              .append('=')
              .append(URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8));
        }
        return enviar(HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("Accept", "application/json")
                .POST(BodyPublishers.ofString(sb.toString()))
                .build());
    }

    private Resp enviarJson(String url, Object corpo) throws ErroLogin {
        return enviar(HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(BodyPublishers.ofString(Json.escrever(corpo)))
                .build());
    }

    private Resp buscar(String url, String bearer) throws ErroLogin {
        return enviar(HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + bearer)
                .header("Accept", "application/json")
                .GET()
                .build());
    }

    private Resp enviar(HttpRequest req) throws ErroLogin {
        try {
            HttpResponse<String> r = http.send(req, BodyHandlers.ofString());
            Map<String, Object> corpo;
            try {
                corpo = Json.objeto(r.body());
            } catch (IllegalArgumentException naoEhJson) {
                corpo = new LinkedHashMap<>();
            }
            return new Resp(r.statusCode(), corpo);
        } catch (IOException e) {
            throw new ErroLogin("Sem conexão com a Microsoft/Mojang. Verifique sua internet.", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw ErroLogin.cancelado();
        }
    }

    private static void dormir(long ms, BooleanSupplier cancelado) throws ErroLogin {
        long fim = System.currentTimeMillis() + ms;
        try {
            while (System.currentTimeMillis() < fim) {
                if (cancelado != null && cancelado.getAsBoolean()) throw ErroLogin.cancelado();
                Thread.sleep(200);
            }
            if (cancelado != null && cancelado.getAsBoolean()) throw ErroLogin.cancelado();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw ErroLogin.cancelado();
        }
    }

    private static void status(Consumer<String> aoStatus, String texto) {
        if (aoStatus != null) aoStatus.accept(texto);
    }
}
