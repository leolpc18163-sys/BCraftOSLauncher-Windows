package Core.Login;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

/**
 * Senha do launcher: nunca é guardada. O arquivo guarda só um "hash" (para conferir a senha)
 * e, nas contas Microsoft, os tokens criptografados com uma chave que só existe com a senha certa.
 */
final class Seguranca {

    static final int SENHA_MIN = 4;
    static final int SENHA_MAX = 64;

    private static final int ITERACOES = 210_000;
    private static final SecureRandom ALEATORIO = new SecureRandom();

    private Seguranca() { }

    /** Mensagem de erro, ou null se a senha e a confirmação estão boas. */
    static String validarSenha(char[] senha, char[] confirmacao) {
        if (senha == null || senha.length == 0) return "Crie uma senha para esta conta.";
        if (senha.length < SENHA_MIN) return "A senha precisa ter pelo menos " + SENHA_MIN + " caracteres.";
        if (senha.length > SENHA_MAX) return "A senha pode ter no máximo " + SENHA_MAX + " caracteres.";
        if (confirmacao == null || !Arrays.equals(senha, confirmacao)) return "As senhas não são iguais.";
        return null;
    }

    static byte[] novoSal() {
        byte[] sal = new byte[16];
        ALEATORIO.nextBytes(sal);
        return sal;
    }

    /** Devolve {verificação (vai para o arquivo), chave AES (nunca vai para o arquivo)}. */
    static byte[][] derivar(char[] senha, byte[] sal) throws ErroLogin {
        PBEKeySpec spec = new PBEKeySpec(senha, sal, ITERACOES, 512);
        try {
            byte[] t = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return new byte[][] { Arrays.copyOfRange(t, 0, 32), Arrays.copyOfRange(t, 32, 64) };
        } catch (GeneralSecurityException e) {
            throw new ErroLogin("Este Java não suporta a proteção por senha.", e);
        } finally {
            spec.clearPassword();
        }
    }

    static boolean iguais(byte[] a, byte[] b) {
        return MessageDigest.isEqual(a, b);
    }

    static String cifrar(byte[] chave, String texto) throws ErroLogin {
        try {
            byte[] iv = new byte[12];
            ALEATORIO.nextBytes(iv);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(chave, "AES"), new GCMParameterSpec(128, iv));
            byte[] ct = c.doFinal(texto.getBytes(StandardCharsets.UTF_8));
            byte[] tudo = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, tudo, 0, iv.length);
            System.arraycopy(ct, 0, tudo, iv.length, ct.length);
            return b64(tudo);
        } catch (GeneralSecurityException e) {
            throw new ErroLogin("Não foi possível proteger os dados da conta.", e);
        }
    }

    static String decifrar(byte[] chave, String base64) throws ErroLogin {
        try {
            byte[] tudo = desb64(base64);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(chave, "AES"),
                    new GCMParameterSpec(128, tudo, 0, 12));
            return new String(c.doFinal(tudo, 12, tudo.length - 12), StandardCharsets.UTF_8);
        } catch (GeneralSecurityException | IllegalArgumentException e) {
            throw new ErroLogin("Não foi possível abrir os dados desta conta. Remova a conta e adicione de novo.", e);
        }
    }

    static String b64(byte[] b) { return Base64.getEncoder().encodeToString(b); }

    static byte[] desb64(String s) { return Base64.getDecoder().decode(s); }
}
