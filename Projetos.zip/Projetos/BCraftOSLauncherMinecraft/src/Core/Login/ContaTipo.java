package Core.Login;

public enum ContaTipo {
    MICROSOFT("Microsoft"),
    PIRATA("Pirata");

    private final String rotulo;

    ContaTipo(String rotulo) {
        this.rotulo = rotulo;
    }

    public String rotulo() {
        return rotulo;
    }
}
