package Core.Login;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * JSON mínimo, sem bibliotecas externas.
 * Lê para Map / List / String / Double / Boolean / null e escreve de volta.
 */
final class Json {

    private final String s;
    private int i;

    private Json(String s) {
        this.s = s;
    }

    // ------------------------------------------------------------ leitura

    /** Lê um objeto JSON; devolve mapa vazio se o texto estiver vazio ou não for um objeto. */
    static Map<String, Object> objeto(String texto) {
        if (texto == null || texto.isBlank()) return new LinkedHashMap<>();
        Json j = new Json(texto);
        j.pular();
        Object v = j.valor();
        j.pular();
        if (j.i != j.s.length()) throw j.falha("conteúdo extra");
        return mapa(v);
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> mapa(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : new LinkedHashMap<>();
    }

    @SuppressWarnings("unchecked")
    static List<Object> lista(Object o) {
        return o instanceof List ? (List<Object>) o : new ArrayList<>();
    }

    static String texto(Map<String, Object> m, String chave) {
        Object o = m.get(chave);
        return o == null ? null : o.toString();
    }

    static long numero(Map<String, Object> m, String chave, long padrao) {
        Object o = m.get(chave);
        return o instanceof Number n ? n.longValue() : padrao;
    }

    private Object valor() {
        if (i >= s.length()) throw falha("fim inesperado");
        switch (s.charAt(i)) {
            case '{': return objetoInterno();
            case '[': return arrayInterno();
            case '"': return textoInterno();
            case 't': literal("true");  return Boolean.TRUE;
            case 'f': literal("false"); return Boolean.FALSE;
            case 'n': literal("null");  return null;
            default:  return numeroInterno();
        }
    }

    private Map<String, Object> objetoInterno() {
        Map<String, Object> m = new LinkedHashMap<>();
        i++;
        pular();
        if (olha('}')) { i++; return m; }
        while (true) {
            pular();
            if (!olha('"')) throw falha("esperava uma chave");
            String chave = textoInterno();
            pular();
            esperar(':');
            pular();
            m.put(chave, valor());
            pular();
            if (olha(',')) { i++; continue; }
            esperar('}');
            return m;
        }
    }

    private List<Object> arrayInterno() {
        List<Object> l = new ArrayList<>();
        i++;
        pular();
        if (olha(']')) { i++; return l; }
        while (true) {
            pular();
            l.add(valor());
            pular();
            if (olha(',')) { i++; continue; }
            esperar(']');
            return l;
        }
    }

    private String textoInterno() {
        StringBuilder sb = new StringBuilder();
        i++; // aspas de abertura
        while (i < s.length()) {
            char c = s.charAt(i++);
            if (c == '"') return sb.toString();
            if (c != '\\') { sb.append(c); continue; }
            if (i >= s.length()) break;
            char e = s.charAt(i++);
            switch (e) {
                case 'n' -> sb.append('\n');
                case 'r' -> sb.append('\r');
                case 't' -> sb.append('\t');
                case 'b' -> sb.append('\b');
                case 'f' -> sb.append('\f');
                case 'u' -> {
                    if (i + 4 > s.length()) throw falha("escape \\u incompleto");
                    sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    i += 4;
                }
                default -> sb.append(e); // \" \\ \/
            }
        }
        throw falha("texto não fechado");
    }

    private Double numeroInterno() {
        int ini = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        if (ini == i) throw falha("valor inesperado");
        return Double.parseDouble(s.substring(ini, i));
    }

    private void literal(String palavra) {
        if (!s.startsWith(palavra, i)) throw falha("valor inesperado");
        i += palavra.length();
    }

    private boolean olha(char c) { return i < s.length() && s.charAt(i) == c; }

    private void esperar(char c) {
        if (!olha(c)) throw falha("esperava '" + c + "'");
        i++;
    }

    private void pular() {
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
    }

    private IllegalArgumentException falha(String motivo) {
        return new IllegalArgumentException("JSON inválido (posição " + i + "): " + motivo);
    }

    // ----------------------------------------------------------- escrita

    static String escrever(Object o) {
        StringBuilder sb = new StringBuilder();
        escrever(o, sb);
        return sb.toString();
    }

    private static void escrever(Object o, StringBuilder sb) {
        if (o == null) {
            sb.append("null");
        } else if (o instanceof Number || o instanceof Boolean) {
            sb.append(o);
        } else if (o instanceof Map<?, ?> m) {
            sb.append('{');
            boolean primeiro = true;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (!primeiro) sb.append(',');
                primeiro = false;
                aspas(String.valueOf(e.getKey()), sb);
                sb.append(':');
                escrever(e.getValue(), sb);
            }
            sb.append('}');
        } else if (o instanceof List<?> l) {
            sb.append('[');
            for (int k = 0; k < l.size(); k++) {
                if (k > 0) sb.append(',');
                escrever(l.get(k), sb);
            }
            sb.append(']');
        } else {
            aspas(o.toString(), sb);
        }
    }

    private static void aspas(String t, StringBuilder sb) {
        sb.append('"');
        for (int k = 0; k < t.length(); k++) {
            char c = t.charAt(k);
            switch (c) {
                case '"'  -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        sb.append('"');
    }
}
