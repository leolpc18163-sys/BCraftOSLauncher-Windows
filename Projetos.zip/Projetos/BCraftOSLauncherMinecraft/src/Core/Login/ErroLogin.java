package Core.Login;

/** Erro de login com mensagem pronta para mostrar ao jogador. */
public class ErroLogin extends Exception {

    private static final long serialVersionUID = 1L;

    private final boolean cancelado;

    public ErroLogin(String mensagem) {
        this(mensagem, null, false);
    }

    public ErroLogin(String mensagem, Throwable causa) {
        this(mensagem, causa, false);
    }

    private ErroLogin(String mensagem, Throwable causa, boolean cancelado) {
        super(mensagem, causa);
        this.cancelado = cancelado;
    }

    public static ErroLogin cancelado() {
        return new ErroLogin("Login cancelado.", null, true);
    }

    public boolean foiCancelado() {
        return cancelado;
    }
}
