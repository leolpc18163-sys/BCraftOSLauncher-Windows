package Core.Login;

import Core.Login.ArmazenamentoContas.Registro;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * Ponto único do login. Várias contas ficam salvas e TODO login pede a senha do launcher
 * (nunca entra sozinho).
 *
 * A senha do launcher é só local: protege a conta aqui no PC. A senha da conta Microsoft é digitada
 * apenas no site da Microsoft - o launcher nunca vê essa senha.
 *
 * Os retornos (Retorno, aoCodigo, aoStatus) vêm de OUTRA thread: com Swing, repasse para a EDT.
 * As senhas (char[]) recebidas são apagadas da memória quando a operação termina.
 */
public final class GerenciadorLogin {

    public interface Retorno {
        void aoSucesso(Conta conta);
        void aoErro(String mensagem);
    }

    /** Dados de uma conta salva para mostrar na lista (sem senha, sem token). */
    public record ContaResumo(String id, String nome, ContaTipo tipo) { }

    private interface Tarefa {
        Conta rodar() throws ErroLogin;
    }

    private final ArmazenamentoContas armazenamento;
    private final LoginMicrosoft microsoft;
    private final AtomicBoolean ocupado = new AtomicBoolean(false);
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bcraft-login");
        t.setDaemon(true);
        return t;
    });

    private volatile boolean cancelado;
    private volatile Conta contaAtual;

    /** @param pastaUsuarios pasta onde ficam os dados de conta (ex.: "Usuarios") */
    public GerenciadorLogin(File pastaUsuarios) {
        this.armazenamento = new ArmazenamentoContas(pastaUsuarios);
        this.microsoft = new LoginMicrosoft(pastaUsuarios);
    }

    // ------------------------------------------------------------ consulta

    public Conta getContaAtual() { return contaAtual; }

    public boolean estaLogado() { return contaAtual != null; }

    public boolean microsoftConfigurado() { return microsoft.clientIdConfigurado(); }

    public List<ContaResumo> listarContas() {
        return armazenamento.listar().stream()
                .map(r -> new ContaResumo(r.id(), r.nome(), r.tipo()))
                .toList();
    }

    /** Id da última conta usada (a tela deixa ela selecionada, mas a senha é sempre pedida). */
    public String ultimaContaId() { return armazenamento.ultima(); }

    // ------------------------------------------------------ adicionar contas

    public void criarPirata(String nome, char[] senha, char[] confirmacao, Retorno retorno) {
        executar(retorno, () -> {
            Conta conta = LoginPirata.entrar(nome);
            exigirSenhaBoa(senha, confirmacao);

            String id = idDe(conta);
            if (armazenamento.buscar(id) != null) {
                throw new ErroLogin("Já existe uma conta pirata com esse nome.");
            }
            guardar(novoRegistro(conta, id, senha));
            return conta;
        }, senha, confirmacao);
    }

    public void criarMicrosoft(char[] senha, char[] confirmacao,
                               Consumer<LoginMicrosoft.Codigo> aoCodigo,
                               Consumer<String> aoStatus, Retorno retorno) {
        executar(retorno, () -> {
            exigirSenhaBoa(senha, confirmacao); // confere a senha antes de abrir o navegador

            Conta conta = microsoft.entrar(aoCodigo, aoStatus, () -> cancelado);
            String id = idDe(conta);
            if (armazenamento.buscar(id) != null) {
                throw new ErroLogin("Esta conta Microsoft já foi adicionada.");
            }
            guardar(novoRegistro(conta, id, senha));
            return conta;
        }, senha, confirmacao);
    }

    // ---------------------------------------------------------------- entrar

    /** Entra numa conta salva. A senha é obrigatória, mesmo se já entrou antes. */
    public void entrarConta(String id, char[] senha,
                            Consumer<LoginMicrosoft.Codigo> aoCodigo,
                            Consumer<String> aoStatus, Retorno retorno) {
        executar(retorno, () -> {
            Registro r = armazenamento.buscar(id);
            if (r == null) throw new ErroLogin("Conta não encontrada.");
            if (senha == null || senha.length == 0) throw new ErroLogin("Digite a senha desta conta.");

            byte[][] chaves = Seguranca.derivar(senha, Seguranca.desb64(r.sal()));
            if (!Seguranca.iguais(chaves[0], Seguranca.desb64(r.hash()))) {
                throw new ErroLogin("Senha incorreta.");
            }

            if (r.tipo() == ContaTipo.PIRATA) {
                return new Conta(ContaTipo.PIRATA, r.nome(), r.uuid(), null, null, 0);
            }

            Conta conta = abrirCofre(r, chaves[1]);
            if (conta.tokenValido()) return conta;

            try {
                conta = microsoft.renovar(conta, aoStatus);
            } catch (ErroLogin e) {
                if (e.foiCancelado()) throw e;
                // a sessão venceu: pede o código de novo, mas só aceita a MESMA conta
                if (aoStatus != null) aoStatus.accept("Sessão expirada. Entre de novo na Microsoft...");
                Conta nova = microsoft.entrar(aoCodigo, aoStatus, () -> cancelado);
                if (!nova.getUuid().equals(r.uuid())) {
                    throw new ErroLogin("Você entrou com outra conta Microsoft. Use a conta " + r.nome() + ".");
                }
                conta = nova;
            }

            guardar(new Registro(r.id(), r.tipo(), conta.getNome(), r.uuid(), r.sal(), r.hash(),
                    Seguranca.cifrar(chaves[1], tokensJson(conta))));
            return conta;
        }, senha);
    }

    public void cancelar() {
        cancelado = true;
    }

    /** Só desloga (as contas continuam salvas; o próximo login pede a senha de novo). */
    public void sair() {
        cancelado = true;
        contaAtual = null;
    }

    /** Remove a conta da lista. Não pede senha, para quem esqueceu a senha não ficar preso. */
    public void removerConta(String id) {
        try {
            armazenamento.remover(id);
        } catch (IOException ignorado) { }
    }

    // ----------------------------------------------------------- interno

    private static String idDe(Conta c) {
        return c.isMicrosoft()
                ? "microsoft:" + c.getUuid()
                : "pirata:" + c.getNome().toLowerCase(Locale.ROOT);
    }

    private static void exigirSenhaBoa(char[] senha, char[] confirmacao) throws ErroLogin {
        String erro = Seguranca.validarSenha(senha, confirmacao);
        if (erro != null) throw new ErroLogin(erro);
    }

    private static Registro novoRegistro(Conta c, String id, char[] senha) throws ErroLogin {
        byte[] sal = Seguranca.novoSal();
        byte[][] chaves = Seguranca.derivar(senha, sal);
        String cofre = c.isMicrosoft() ? Seguranca.cifrar(chaves[1], tokensJson(c)) : null;
        return new Registro(id, c.getTipo(), c.getNome(), c.getUuid(),
                Seguranca.b64(sal), Seguranca.b64(chaves[0]), cofre);
    }

    private void guardar(Registro r) throws ErroLogin {
        try {
            armazenamento.salvar(r);
        } catch (IOException e) {
            throw new ErroLogin("Não foi possível salvar a conta na pasta Usuarios.", e);
        }
    }

    private static String tokensJson(Conta c) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("accessToken", c.getAccessToken());
        m.put("refreshToken", c.getRefreshToken());
        m.put("expiraEm", c.expiraEm());
        return Json.escrever(m);
    }

    private static Conta abrirCofre(Registro r, byte[] chave) throws ErroLogin {
        if (r.cofre() == null) throw new ErroLogin("Esta conta está sem dados salvos. Remova e adicione de novo.");
        try {
            Map<String, Object> m = Json.objeto(Seguranca.decifrar(chave, r.cofre()));
            return new Conta(ContaTipo.MICROSOFT, r.nome(), r.uuid(),
                    Json.texto(m, "accessToken"), Json.texto(m, "refreshToken"), Json.numero(m, "expiraEm", 0));
        } catch (IllegalArgumentException e) {
            throw new ErroLogin("Os dados desta conta estão corrompidos. Remova e adicione de novo.", e);
        }
    }

    private void executar(Retorno retorno, Tarefa tarefa, char[]... segredos) {
        if (!ocupado.compareAndSet(false, true)) {
            apagar(segredos);
            retorno.aoErro("Já existe um login em andamento.");
            return;
        }
        cancelado = false;

        executor.execute(() -> {
            Conta conta = null;
            String erro = null;
            try {
                conta = tarefa.rodar();
                contaAtual = conta;
                try {
                    armazenamento.definirUltima(idDe(conta));
                } catch (IOException ignorado) { }
            } catch (ErroLogin e) {
                erro = e.getMessage();
            } catch (RuntimeException e) {
                erro = "Erro inesperado no login: " + e.getMessage();
            } finally {
                apagar(segredos);
                ocupado.set(false);
            }

            if (conta != null) retorno.aoSucesso(conta);
            else retorno.aoErro(erro);
        });
    }

    private static void apagar(char[]... segredos) {
        for (char[] s : segredos) {
            if (s != null) Arrays.fill(s, '\0');
        }
    }
}
