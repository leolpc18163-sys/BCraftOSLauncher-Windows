package Core.Login;

import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.regex.Pattern;

/** Conta pirata (offline): só precisa de um nome. O UUID é o mesmo que o jogo gera em modo offline. */
public final class LoginPirata {

    private static final Pattern NOME_VALIDO = Pattern.compile("[A-Za-z0-9_]{3,16}");

    private LoginPirata() { }

    /** Devolve a mensagem de erro, ou null se o nome for válido. */
    public static String validar(String nome) {
        if (nome == null || nome.isBlank()) return "Digite um nome de jogador.";
        if (nome.length() < 3) return "O nome precisa ter pelo menos 3 caracteres.";
        if (nome.length() > 16) return "O nome pode ter no máximo 16 caracteres.";
        if (!NOME_VALIDO.matcher(nome).matches()) return "Use só letras, números e _ (sem espaços).";
        return null;
    }

    public static Conta entrar(String nomeDigitado) throws ErroLogin {
        String nome = nomeDigitado == null ? "" : nomeDigitado.trim();
        String erro = validar(nome);
        if (erro != null) throw new ErroLogin(erro);

        String uuid = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + nome).getBytes(StandardCharsets.UTF_8)).toString();
        return new Conta(ContaTipo.PIRATA, nome, uuid, null, null, 0);
    }
}
