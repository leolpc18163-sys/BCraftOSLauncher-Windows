package Core.Login;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Guarda todas as contas em Usuarios/contas.json (senha só como hash; tokens Microsoft criptografados). */
final class ArmazenamentoContas {

    /** Uma conta no arquivo. 'cofre' = tokens criptografados (só contas Microsoft). */
    record Registro(String id, ContaTipo tipo, String nome, String uuid,
                    String sal, String hash, String cofre) { }

    private record Estado(List<Registro> contas, String ultima) { }

    private final Path arquivo;

    ArmazenamentoContas(File pastaUsuarios) {
        this.arquivo = pastaUsuarios.toPath().resolve("contas.json");
    }

    synchronized List<Registro> listar() {
        return carregar().contas();
    }

    synchronized Registro buscar(String id) {
        for (Registro r : carregar().contas()) {
            if (r.id().equals(id)) return r;
        }
        return null;
    }

    synchronized String ultima() {
        return carregar().ultima();
    }

    /** Adiciona a conta ou, se o id já existe, troca os dados dela. */
    synchronized void salvar(Registro novo) throws IOException {
        Estado e = carregar();
        List<Registro> lista = new ArrayList<>(e.contas());
        boolean achou = false;
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).id().equals(novo.id())) {
                lista.set(i, novo);
                achou = true;
            }
        }
        if (!achou) lista.add(novo);
        gravar(new Estado(lista, e.ultima()));
    }

    synchronized void remover(String id) throws IOException {
        Estado e = carregar();
        List<Registro> lista = new ArrayList<>(e.contas());
        lista.removeIf(r -> r.id().equals(id));
        String ultima = id.equals(e.ultima()) ? null : e.ultima();
        gravar(new Estado(lista, ultima));
    }

    synchronized void definirUltima(String id) throws IOException {
        gravar(new Estado(carregar().contas(), id));
    }

    // ------------------------------------------------------------ arquivo

    private Estado carregar() {
        List<Registro> lista = new ArrayList<>();
        String ultima = null;
        if (Files.isRegularFile(arquivo)) {
            try {
                Map<String, Object> raiz = Json.objeto(Files.readString(arquivo));
                ultima = Json.texto(raiz, "ultima");
                for (Object o : Json.lista(raiz.get("contas"))) {
                    Registro r = deMapa(Json.mapa(o));
                    if (r != null) lista.add(r);
                }
            } catch (IOException | RuntimeException e) {
                // arquivo ilegível: trata como sem contas
            }
        }
        return new Estado(lista, ultima);
    }

    private void gravar(Estado e) throws IOException {
        Files.createDirectories(arquivo.getParent());
        Path tmp = arquivo.resolveSibling(arquivo.getFileName() + ".tmp");

        List<Object> contas = new ArrayList<>();
        for (Registro r : e.contas()) contas.add(paraMapa(r));
        Map<String, Object> raiz = new LinkedHashMap<>();
        if (e.ultima() != null) raiz.put("ultima", e.ultima());
        raiz.put("contas", contas);
        Files.writeString(tmp, Json.escrever(raiz));

        try { // só o dono lê o arquivo (no Windows isso é ignorado)
            Files.setPosixFilePermissions(tmp, PosixFilePermissions.fromString("rw-------"));
        } catch (UnsupportedOperationException | IOException ignorado) { }

        Files.move(tmp, arquivo, StandardCopyOption.REPLACE_EXISTING);
    }

    private static Map<String, Object> paraMapa(Registro r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", r.id());
        m.put("tipo", r.tipo().name());
        m.put("nome", r.nome());
        m.put("uuid", r.uuid());
        m.put("sal", r.sal());
        m.put("hash", r.hash());
        if (r.cofre() != null) m.put("cofre", r.cofre());
        return m;
    }

    private static Registro deMapa(Map<String, Object> m) {
        String id = Json.texto(m, "id");
        String tipo = Json.texto(m, "tipo");
        String nome = Json.texto(m, "nome");
        String uuid = Json.texto(m, "uuid");
        String sal = Json.texto(m, "sal");
        String hash = Json.texto(m, "hash");
        if (id == null || tipo == null || nome == null || uuid == null || sal == null || hash == null) return null;
        try {
            return new Registro(id, ContaTipo.valueOf(tipo), nome, uuid, sal, hash, Json.texto(m, "cofre"));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
