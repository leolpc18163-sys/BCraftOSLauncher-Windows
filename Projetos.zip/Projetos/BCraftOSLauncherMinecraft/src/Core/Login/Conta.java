package Core.Login;

import java.util.ArrayList;
import java.util.List;

/** Conta logada no launcher (Microsoft ou Pirata). Sem nenhuma dependência de tela. */
public final class Conta {

    private final ContaTipo tipo;
    private final String nome;
    private final String uuid;
    private final String accessToken;   // token do Minecraft (null na conta pirata)
    private final String refreshToken;  // renova o login Microsoft (null na conta pirata)
    private final long expiraEm;        // quando o accessToken vence (ms desde 1970)

    public Conta(ContaTipo tipo, String nome, String uuid,
                 String accessToken, String refreshToken, long expiraEm) {
        this.tipo = tipo;
        this.nome = nome;
        this.uuid = uuid;
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
        this.expiraEm = expiraEm;
    }

    public ContaTipo getTipo() { return tipo; }
    public String getNome() { return nome; }
    public String getUuid() { return uuid; }
    public String getAccessToken() { return accessToken; }
    public String getRefreshToken() { return refreshToken; }
    public boolean isMicrosoft() { return tipo == ContaTipo.MICROSOFT; }
    long expiraEm() { return expiraEm; }

    /** Conta pirata nunca vence; a Microsoft vale até 1 minuto antes do vencimento. */
    public boolean tokenValido() {
        if (!isMicrosoft()) return true;
        return accessToken != null && System.currentTimeMillis() < expiraEm - 60_000;
    }

    /** Argumentos de login que o Minecraft espera ao iniciar o jogo (usado pela lógica do JOGAR). */
    public List<String> argumentosDeJogo() {
        List<String> a = new ArrayList<>();
        a.add("--username");    a.add(nome);
        a.add("--uuid");        a.add(uuid);
        a.add("--accessToken"); a.add(isMicrosoft() && accessToken != null ? accessToken : "0");
        a.add("--userType");    a.add(isMicrosoft() ? "msa" : "legacy");
        return a;
    }
}
