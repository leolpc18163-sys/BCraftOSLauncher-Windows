package Core.Console;

public class MostrarCosole {
}
