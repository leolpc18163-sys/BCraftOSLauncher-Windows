package Core.Console;

public class SelecionarServidor {
}
