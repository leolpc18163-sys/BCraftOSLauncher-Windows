package Core.Console;

public class ChatComandos {
}
