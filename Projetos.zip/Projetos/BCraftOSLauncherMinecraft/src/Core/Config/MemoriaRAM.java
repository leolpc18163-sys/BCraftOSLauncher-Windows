package Core.Config;

public class MemoriaRAM {
}
