package Core.Config;

public class Argumentos {
}
