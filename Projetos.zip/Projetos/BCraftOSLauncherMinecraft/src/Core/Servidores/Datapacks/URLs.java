package Core.Servidores.Datapacks;

public class URLs {
}
