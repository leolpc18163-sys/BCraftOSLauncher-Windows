package Core.Servidores.Modpacks;

public class URLs {
}
