package Core.Servidores.Principal;

public class Ligar {
}
