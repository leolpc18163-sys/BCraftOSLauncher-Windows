package Core.Servidores.Principal;

public class Deligar {
}
