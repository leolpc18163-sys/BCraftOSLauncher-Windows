package Core.Servidores.Principal;

public class Salvar {
}
