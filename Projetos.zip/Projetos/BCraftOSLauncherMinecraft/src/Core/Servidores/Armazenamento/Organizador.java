package Core.Servidores.Armazenamento;

public class Organizador {
}
