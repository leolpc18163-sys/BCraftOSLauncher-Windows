package Core.Servidores.Armazenamento;

public class Enviador {
}
