package Core.Servidores.Plugins;

public class ModrinthList {
}
