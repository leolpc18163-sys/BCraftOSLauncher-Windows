package Core.Servidores.Plugins;

public class URLs {
}
