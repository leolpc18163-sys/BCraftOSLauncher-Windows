package Core.Servidores.Plugins;

public class Instalador {
}
