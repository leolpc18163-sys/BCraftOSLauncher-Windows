package Core.Servidores.Mods;

public class URLs {
}
