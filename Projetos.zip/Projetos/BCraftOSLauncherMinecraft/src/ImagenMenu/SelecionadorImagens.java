package ImagenMenu;

public class SelecionadorImagens {
}
