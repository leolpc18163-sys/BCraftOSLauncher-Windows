package Screens;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Tela "Jogar": escolha da versão e um botão JOGAR grande.
 * O nome do jogador vem da tela de login.
 * Só o layout - a lógica de abrir o jogo fica para depois (setOnJogar).
 */
public class Jogar extends JPanel {

    private static final Color PAINEL = new Color(12, 35, 65, 155);
    private static final Color CAIXA = new Color(4, 14, 30, 170);
    private static final Color DESTAQUE = new Color(38, 105, 165, 235);
    private static final Color DESTAQUE_HOVER = new Color(83, 165, 235, 240);
    private static final Color TEXTO = new Color(240, 242, 247);
    private static final Color TEXTO_SECUNDARIO = new Color(195, 225, 255);
    private static final Color BORDA = new Color(255, 255, 255, 35);
    private static final Color BORDA_BOTAO = new Color(150, 205, 255, 90);

    /** A área rolável da lista tem espaço para, no mínimo, este número de versões. */
    private static final int MIN_LINHAS = 30;
    private static final int ALTURA_LINHA = 28;
    private static final int LINHAS_VISIVEIS = 5;

    private final DefaultListModel<String> modeloVersoes = new DefaultListModel<>();
    private final JList<String> listaVersoes = criarLista();
    private final JLabel status = new JLabel("Pronto para jogar.");
    private final Barra barra = new Barra();
    private final JButton botaoJogar = new JButton("▶  JOGAR");
    private Runnable aoJogar = () -> { };

    public Jogar() {
        setLayout(new BorderLayout());
        setOpaque(false);
        montarInterface();
        botaoJogar.addActionListener(e -> aoJogar.run());
    }

    // ---------------------------------------------------------------- API

    public String getVersao() { return listaVersoes.getSelectedValue(); }

    public void setVersoes(List<String> versoes) {
        modeloVersoes.clear();
        for (String v : versoes) modeloVersoes.addElement(v);
        if (!modeloVersoes.isEmpty()) listaVersoes.setSelectedIndex(0);
        listaVersoes.revalidate();   // a lista cresce se passar de MIN_LINHAS versões
        listaVersoes.repaint();
    }

    public void setStatus(String texto) { status.setText(texto); }

    /** 0-100 mostra a barra; valor negativo esconde. */
    public void setProgresso(int porcento) {
        barra.setValor(porcento);
    }

    public void setOnJogar(Runnable acao) {
        this.aoJogar = acao == null ? () -> { } : acao;
    }

    // ------------------------------------------------------------- Layout

    private void montarInterface() {
        JPanel raiz = new JPanel(new BorderLayout(12, 12));
        raiz.setOpaque(false);
        raiz.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Jogar");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel subtitulo = new JLabel("Escolha a versão e entre no jogo.");
        subtitulo.setForeground(TEXTO_SECUNDARIO);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel cabecalho = new JPanel();
        cabecalho.setOpaque(false);
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.add(titulo);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(subtitulo);

        // Cartão compacto, centralizado.
        JPanel cartao = painelTranslucido(PAINEL, 20);
        cartao.setLayout(new BoxLayout(cartao, BoxLayout.Y_AXIS));
        cartao.setBorder(new EmptyBorder(18, 22, 18, 22));
        cartao.setPreferredSize(new Dimension(420, 330));

        cartao.add(rotulo("Versão"));
        cartao.add(Box.createVerticalStrut(4));
        cartao.add(criarCaixaDaLista());
        cartao.add(Box.createVerticalGlue());

        status.setForeground(TEXTO_SECUNDARIO);
        status.setFont(new Font("SansSerif", Font.PLAIN, 12));
        status.setAlignmentX(LEFT_ALIGNMENT);
        cartao.add(status);
        cartao.add(Box.createVerticalStrut(6));
        barra.setAlignmentX(LEFT_ALIGNMENT);
        cartao.add(barra);
        cartao.add(Box.createVerticalStrut(14));

        estilizarBotaoJogar();
        botaoJogar.setAlignmentX(LEFT_ALIGNMENT);
        botaoJogar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        cartao.add(botaoJogar);

        JPanel centro = new JPanel(new GridBagLayout());
        centro.setOpaque(false);
        centro.add(cartao);

        raiz.add(cabecalho, BorderLayout.NORTH);
        raiz.add(centro, BorderLayout.CENTER);
        add(raiz, BorderLayout.CENTER);
    }

    private JLabel rotulo(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(TEXTO_SECUNDARIO);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    // ---------------------------------------------------------- Estilo

    private JPanel painelTranslucido(Color fundo, int arco) {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(fundo);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);
                g2.setColor(BORDA);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        return p;
    }

    private void estilizarBotaoJogar() {
        JButton b = botaoJogar;
        b.setFont(new Font("SansSerif", Font.BOLD, 17));
        b.setForeground(TEXTO);
        b.setBackground(DESTAQUE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(10, 20, 10, 20));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(c.getBackground());
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 18, 18);
                g2.setColor(BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 18, 18);
                g2.dispose();
                paint(g, c);
            }
        });
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(DESTAQUE_HOVER); }
            @Override public void mouseExited(MouseEvent e) { b.setBackground(DESTAQUE); }
        });
    }

    /** JList clicável; o espaço rolável é de no mínimo MIN_LINHAS e cresce com mais versões. */
    private JList<String> criarLista() {
        JList<String> l = new JList<String>(modeloVersoes) {
            @Override
            public Dimension getPreferredSize() {
                Dimension d = super.getPreferredSize();
                d.height = Math.max(getModel().getSize(), MIN_LINHAS) * ALTURA_LINHA;
                return d;
            }
        };
        l.setOpaque(false);
        l.setFixedCellHeight(ALTURA_LINHA);
        l.setVisibleRowCount(LINHAS_VISIVEIS);
        l.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        l.setForeground(TEXTO);
        l.setFont(new Font("SansSerif", Font.PLAIN, 13));
        l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        l.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> lista, Object v, int i,
                                                          boolean sel, boolean foco) {
                JLabel lb = (JLabel) super.getListCellRendererComponent(lista, v, i, sel, false);
                lb.setForeground(TEXTO);
                lb.setOpaque(sel);
                lb.setBackground(new Color(38, 105, 165, 220));
                lb.setBorder(new EmptyBorder(0, 12, 0, 12));
                return lb;
            }
        });
        return l;
    }

    private JComponent criarCaixaDaLista() {
        JScrollPane rolagem = new JScrollPane(listaVersoes,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        rolagem.setOpaque(false);
        rolagem.getViewport().setOpaque(false);
        rolagem.setBorder(BorderFactory.createEmptyBorder());
        rolagem.getVerticalScrollBar().setUnitIncrement(ALTURA_LINHA);

        JScrollBar barraV = rolagem.getVerticalScrollBar();
        barraV.setOpaque(false);
        barraV.setPreferredSize(new Dimension(10, 0));
        barraV.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() { }
            @Override protected JButton createDecreaseButton(int o) { return vazio(); }
            @Override protected JButton createIncreaseButton(int o) { return vazio(); }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(150, 205, 255, 120));
                g2.fillRoundRect(r.x + 2, r.y, r.width - 4, r.height, 8, 8);
                g2.dispose();
            }
            private JButton vazio() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });

        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(4, 4, 4, 4));
        caixa.add(rolagem, BorderLayout.CENTER);
        int altura = LINHAS_VISIVEIS * ALTURA_LINHA + 8;
        caixa.setPreferredSize(new Dimension(100, altura));
        caixa.setMaximumSize(new Dimension(Integer.MAX_VALUE, altura));
        caixa.setAlignmentX(LEFT_ALIGNMENT);
        return caixa;
    }

    /** Barra de progresso fina e arredondada (escondida quando valor < 0). */
    private static class Barra extends JComponent {
        private int valor = -1;

        Barra() {
            setPreferredSize(new Dimension(100, 8));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 8));
        }

        void setValor(int v) {
            this.valor = v;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(CAIXA);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            if (valor >= 0) {
                int w = Math.min(getWidth(), getWidth() * valor / 100);
                g2.setColor(new Color(120, 195, 255));
                g2.fillRoundRect(0, 0, w, getHeight(), 8, 8);
            }
            g2.dispose();
        }
    }
}