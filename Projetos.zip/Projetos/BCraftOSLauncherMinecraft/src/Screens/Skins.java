package Screens;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/**
 * Tela "Skins": lista de skins à esquerda, visualizador 3D no centro e detalhes à direita.
 *
 * O 3D é desenhado por software (rasterizador próprio em Java2D): sem bibliotecas extras
 * e funciona com os painéis semitransparentes do launcher. Recursos do visualizador:
 * girar arrastando, zoom com a roda, giro automático, animação de andar, respiração em
 * repouso, camada externa (chapéu/jaqueta/mangas/calça) ligável, modelo Clássico/Fino,
 * textura com pixels nítidos, iluminação por face, sombra e plataforma no chão,
 * suporte a skins antigas 64x32 (convertidas) e detecção automática do modelo.
 *
 * Só o layout/visualização - ler, salvar e aplicar skins fica para depois (callbacks).
 */
public class Skins extends JPanel {

    private static final Color PAINEL = new Color(12, 35, 65, 155);
    private static final Color CAIXA = new Color(4, 14, 30, 170);
    private static final Color BOTAO = new Color(25, 75, 125, 225);
    private static final Color BOTAO_HOVER = new Color(38, 105, 165, 240);
    private static final Color DESTAQUE = new Color(38, 105, 165, 235);
    private static final Color DESTAQUE_HOVER = new Color(83, 165, 235, 240);
    private static final Color SELECAO = new Color(38, 105, 165, 220);
    private static final Color TEXTO = new Color(240, 242, 247);
    private static final Color TEXTO_SECUNDARIO = new Color(195, 225, 255);
    private static final Color AZUL_CLARO = new Color(120, 195, 255);
    private static final Color BORDA = new Color(255, 255, 255, 35);
    private static final Color BORDA_BOTAO = new Color(150, 205, 255, 90);

    // ================================================================ Item

    /** Uma skin da biblioteca do usuário. */
    public static class SkinItem {
        public final String nome;
        public final Object origem;      // ex.: o File do .png; a tela não mexe nele
        public boolean fino;             // true = braços finos (Alex), false = clássico (Steve)
        final BufferedImage tex64;       // textura normalizada em 64x64
        final boolean convertida;        // veio de 64x32 (formato antigo)
        final int[] pixels;

        /** @param fino null para detectar automaticamente pelo desenho do braço. */
        public SkinItem(String nome, BufferedImage textura, Boolean fino, Object origem) {
            this.nome = nome;
            this.origem = origem;
            BufferedImage base = textura;
            if (base.getWidth() != 64) {                       // skins HD: reduz com pixels nítidos
                int h = Math.max(32, base.getHeight() * 64 / base.getWidth());
                BufferedImage r = new BufferedImage(64, h, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = r.createGraphics();
                g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                        RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                g.drawImage(base, 0, 0, 64, h, null);
                g.dispose();
                base = r;
            }
            this.convertida = base.getHeight() < 64;
            this.tex64 = normalizar(base);
            this.pixels = tex64.getRGB(0, 0, 64, 64, null, 0, 64);
            this.fino = fino != null ? fino : detectarFino(pixels);
        }

        @Override public String toString() { return nome; }
    }

    private static BufferedImage normalizar(BufferedImage src) {
        BufferedImage out = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        if (src.getHeight() >= 64) return out;
        // Formato antigo 64x32: o lado esquerdo é o direito espelhado.
        int[] px = out.getRGB(0, 0, 64, 64, null, 0, 64);
        copiarMembro(px, 40, 16, 32, 48);   // braço
        copiarMembro(px, 0, 16, 16, 48);    // perna
        out.setRGB(0, 0, 64, 64, px, 0, 64);
        return out;
    }

    /** Copia um membro 4x12x4 espelhando cada face (e trocando os lados). */
    private static void copiarMembro(int[] px, int ox, int oy, int dx, int dy) {
        espelhar(px, ox + 4, oy, dx + 4, dy, 4, 4);          // topo
        espelhar(px, ox + 8, oy, dx + 8, dy, 4, 4);          // base
        espelhar(px, ox, oy + 4, dx + 8, dy + 4, 4, 12);     // lado direito -> lado esquerdo
        espelhar(px, ox + 4, oy + 4, dx + 4, dy + 4, 4, 12); // frente
        espelhar(px, ox + 8, oy + 4, dx, dy + 4, 4, 12);     // lado esquerdo -> lado direito
        espelhar(px, ox + 12, oy + 4, dx + 12, dy + 4, 4, 12); // costas
    }

    private static void espelhar(int[] px, int sx, int sy, int dx, int dy, int w, int h) {
        for (int j = 0; j < h; j++)
            for (int i = 0; i < w; i++)
                px[(dy + j) * 64 + dx + i] = px[(sy + j) * 64 + sx + (w - 1 - i)];
    }

    /** Braço fino deixa a última coluna do braço direito transparente. */
    private static boolean detectarFino(int[] px) {
        return (px[20 * 64 + 55] >>> 24) == 0 && (px[24 * 64 + 54] >>> 24) == 0;
    }

    // ============================================================== Campos

    private final DefaultListModel<SkinItem> modelo = new DefaultListModel<>();
    private final JList<SkinItem> lista = new JList<>(modelo);
    private final Visualizador3D visor = new Visualizador3D();
    private final JToggleButton chipGirar = chip("Girar");
    private final JToggleButton chipAndar = chip("Andar");
    private final JToggleButton chipCamada = chip("Camada externa");
    private final JToggleButton chipClassico = chip("Clássico");
    private final JToggleButton chipFino = chip("Fino");
    private final JLabel valorNome = new JLabel("-");
    private final JLabel valorFormato = new JLabel("-");
    private final Miniatura miniFrente = new Miniatura("Frente");
    private final Miniatura miniCostas = new Miniatura("Costas");
    private final JButton botaoUsar = botao("Usar esta skin");
    private final JButton botaoRemover = botao("Remover");
    private final Cena cenaMini = new Cena(3);
    private Consumer<SkinItem> aoSelecionar = s -> { };
    private Consumer<SkinItem> aoUsar = s -> { };
    private Consumer<SkinItem> aoRemover = s -> { };
    private Consumer<SkinItem> aoMudarModelo = s -> { };
    private Runnable aoAdicionar = () -> { };
    private boolean ajustando;

    public Skins() {
        setLayout(new BorderLayout());
        setOpaque(false);
        montarInterface();
        atualizarDetalhes();
    }

    // ================================================================= API

    public void setSkins(List<SkinItem> skins) {
        ajustando = true;
        modelo.clear();
        for (SkinItem s : skins) modelo.addElement(s);
        ajustando = false;
        if (!modelo.isEmpty()) lista.setSelectedIndex(0);
        else atualizarDetalhes();
    }

    public void adicionarSkin(SkinItem s) {
        modelo.addElement(s);
        lista.setSelectedIndex(modelo.size() - 1);
    }

    public void removerSkin(SkinItem s) {
        modelo.removeElement(s);
        if (!modelo.isEmpty()) lista.setSelectedIndex(0);
        else atualizarDetalhes();
    }

    public SkinItem getSelecionada() { return lista.getSelectedValue(); }

    public void setOnSelecionar(Consumer<SkinItem> c) { aoSelecionar = c == null ? s -> { } : c; }
    public void setOnUsar(Consumer<SkinItem> c) { aoUsar = c == null ? s -> { } : c; }
    public void setOnRemover(Consumer<SkinItem> c) { aoRemover = c == null ? s -> { } : c; }
    public void setOnMudarModelo(Consumer<SkinItem> c) { aoMudarModelo = c == null ? s -> { } : c; }
    public void setOnAdicionar(Runnable r) { aoAdicionar = r == null ? () -> { } : r; }

    // ============================================================== Layout

    private void montarInterface() {
        JPanel raiz = new JPanel(new BorderLayout(12, 12));
        raiz.setOpaque(false);
        raiz.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Skins");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel subtitulo = new JLabel("Veja sua skin em 3D, gire, dê zoom e escolha qual usar.");
        subtitulo.setForeground(TEXTO_SECUNDARIO);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        JPanel cabecalho = new JPanel();
        cabecalho.setOpaque(false);
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.add(titulo);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(subtitulo);

        JPanel corpo = new JPanel(new BorderLayout(12, 0));
        corpo.setOpaque(false);
        corpo.add(montarPainelEsquerdo(), BorderLayout.WEST);
        corpo.add(montarPainelCentral(), BorderLayout.CENTER);
        corpo.add(montarPainelDireito(), BorderLayout.EAST);

        raiz.add(cabecalho, BorderLayout.NORTH);
        raiz.add(corpo, BorderLayout.CENTER);
        add(raiz, BorderLayout.CENTER);
    }

    private JPanel montarPainelEsquerdo() {
        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BorderLayout(0, 8));
        painel.setBorder(new EmptyBorder(12, 12, 12, 12));
        painel.setPreferredSize(new Dimension(210, 100));

        JLabel t = new JLabel("Suas skins");
        t.setForeground(TEXTO);
        t.setFont(new Font("SansSerif", Font.BOLD, 15));

        lista.setOpaque(false);
        lista.setFixedCellHeight(52);
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lista.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lista.setCellRenderer(new SkinRenderer());
        lista.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || ajustando) return;
            atualizarDetalhes();
            SkinItem s = lista.getSelectedValue();
            if (s != null) aoSelecionar.accept(s);
        });

        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(4, 4, 4, 4));
        caixa.add(criarRolagem(lista), BorderLayout.CENTER);

        JButton adicionar = botao("+ Adicionar");
        adicionar.addActionListener(e -> aoAdicionar.run());
        botaoRemover.addActionListener(e -> {
            SkinItem s = lista.getSelectedValue();
            if (s != null) aoRemover.accept(s);
        });
        for (JButton b : new JButton[]{adicionar, botaoRemover}) {
            b.setFont(new Font("SansSerif", Font.BOLD, 11));
            b.setBorder(new EmptyBorder(6, 4, 6, 4));
        }
        JPanel acoes = new JPanel(new GridLayout(1, 2, 6, 0));
        acoes.setOpaque(false);
        acoes.add(adicionar);
        acoes.add(botaoRemover);

        painel.add(t, BorderLayout.NORTH);
        painel.add(caixa, BorderLayout.CENTER);
        painel.add(acoes, BorderLayout.SOUTH);
        return painel;
    }

    private JPanel montarPainelCentral() {
        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BorderLayout(0, 8));
        painel.setBorder(new EmptyBorder(10, 10, 10, 10));

        chipGirar.setSelected(true);
        chipCamada.setSelected(true);
        chipGirar.addActionListener(e -> visor.setGirar(chipGirar.isSelected()));
        chipAndar.addActionListener(e -> visor.setAndar(chipAndar.isSelected()));
        chipCamada.addActionListener(e -> {
            visor.setCamadaExterna(chipCamada.isSelected());
            atualizarMiniaturas();
        });
        JButton resetar = botao("Resetar vista");
        resetar.setFont(new Font("SansSerif", Font.BOLD, 11));
        resetar.addActionListener(e -> visor.resetarVista());

        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        chips.setOpaque(false);
        chips.add(chipGirar);
        chips.add(chipAndar);
        chips.add(chipCamada);
        JPanel barra = new JPanel(new BorderLayout(8, 0));
        barra.setOpaque(false);
        barra.add(chips, BorderLayout.WEST);
        barra.add(resetar, BorderLayout.EAST);

        painel.add(visor, BorderLayout.CENTER);
        painel.add(barra, BorderLayout.SOUTH);
        return painel;
    }

    private JPanel montarPainelDireito() {
        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(new EmptyBorder(12, 12, 12, 12));
        painel.setPreferredSize(new Dimension(214, 100));

        JLabel t = new JLabel("Detalhes");
        t.setForeground(TEXTO);
        t.setFont(new Font("SansSerif", Font.BOLD, 15));
        t.setAlignmentX(LEFT_ALIGNMENT);
        painel.add(t);
        painel.add(Box.createVerticalStrut(8));

        painel.add(linhaInfo("Nome", valorNome));
        painel.add(Box.createVerticalStrut(6));
        painel.add(linhaInfo("Formato", valorFormato));
        painel.add(Box.createVerticalStrut(8));

        JLabel rm = new JLabel("Modelo dos braços");
        rm.setForeground(TEXTO_SECUNDARIO);
        rm.setFont(new Font("SansSerif", Font.PLAIN, 11));
        rm.setAlignmentX(LEFT_ALIGNMENT);
        painel.add(rm);
        painel.add(Box.createVerticalStrut(3));
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(chipClassico);
        grupo.add(chipFino);
        chipClassico.setSelected(true);
        java.awt.event.ActionListener trocar = e -> {
            SkinItem s = lista.getSelectedValue();
            if (s == null) return;
            s.fino = chipFino.isSelected();
            visor.setFino(s.fino);
            atualizarMiniaturas();
            lista.repaint();
            aoMudarModelo.accept(s);
        };
        chipClassico.addActionListener(trocar);
        chipFino.addActionListener(trocar);
        JPanel modelos = new JPanel(new GridLayout(1, 2, 6, 0));
        modelos.setOpaque(false);
        modelos.add(chipClassico);
        modelos.add(chipFino);
        modelos.setAlignmentX(LEFT_ALIGNMENT);
        modelos.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        painel.add(modelos);
        painel.add(Box.createVerticalStrut(10));

        JPanel minis = new JPanel(new GridLayout(1, 2, 6, 0));
        minis.setOpaque(false);
        minis.add(miniFrente);
        minis.add(miniCostas);
        minis.setAlignmentX(LEFT_ALIGNMENT);
        painel.add(minis);
        painel.add(Box.createVerticalGlue());
        painel.add(Box.createVerticalStrut(10));

        botaoUsar.setBackground(DESTAQUE);
        botaoUsar.putClientProperty("normal", DESTAQUE);
        botaoUsar.putClientProperty("hover", DESTAQUE_HOVER);
        botaoUsar.setAlignmentX(LEFT_ALIGNMENT);
        botaoUsar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        botaoUsar.addActionListener(e -> {
            SkinItem s = lista.getSelectedValue();
            if (s != null) aoUsar.accept(s);
        });
        painel.add(botaoUsar);
        return painel;
    }

    private JPanel linhaInfo(String rotulo, JLabel valor) {
        JLabel r = new JLabel(rotulo);
        r.setForeground(TEXTO_SECUNDARIO);
        r.setFont(new Font("SansSerif", Font.PLAIN, 11));
        valor.setForeground(TEXTO);
        valor.setFont(new Font("SansSerif", Font.BOLD, 12));
        JPanel p = new JPanel(new BorderLayout(0, 1));
        p.setOpaque(false);
        p.add(r, BorderLayout.NORTH);
        p.add(valor, BorderLayout.CENTER);
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        return p;
    }

    // ========================================================== Atualização

    private void atualizarDetalhes() {
        SkinItem s = lista.getSelectedValue();
        boolean tem = s != null;
        botaoUsar.setEnabled(tem);
        botaoRemover.setEnabled(tem);
        chipClassico.setEnabled(tem);
        chipFino.setEnabled(tem);
        if (!tem) {
            valorNome.setText("-");
            valorFormato.setText("-");
            visor.setSkin(null);
            miniFrente.setImagem(null);
            miniCostas.setImagem(null);
            return;
        }
        valorNome.setText(s.nome);
        valorFormato.setText(s.convertida ? "64x32 (convertida)" : "64x64");
        chipFino.setSelected(s.fino);
        chipClassico.setSelected(!s.fino);
        visor.setSkin(s);
        atualizarMiniaturas();
    }

    private void atualizarMiniaturas() {
        SkinItem s = lista.getSelectedValue();
        if (s == null) return;
        boolean externa = chipCamada.isSelected();
        miniFrente.setImagem(cenaMini.renderizar(s.pixels, s.fino, externa, 0f, 0f, 92f, 0f, false, 96, 150));
        miniCostas.setImagem(cenaMini.renderizar(s.pixels, s.fino, externa, (float) Math.PI, 0f, 92f, 0f, false, 96, 150));
    }

    // ============================================================= Renderers

    /** Linha da lista: rosto da skin + nome + modelo. */
    private static class SkinRenderer extends JComponent implements ListCellRenderer<SkinItem> {
        private SkinItem skin;
        private boolean selecionado;

        @Override
        public Component getListCellRendererComponent(JList<? extends SkinItem> l, SkinItem v,
                                                      int i, boolean sel, boolean foco) {
            skin = v;
            selecionado = sel;
            return this;
        }

        @Override public Dimension getPreferredSize() { return new Dimension(100, 52); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (selecionado) {
                g2.setColor(SELECAO);
                g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 12, 12);
            }
            if (skin != null) {
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                        RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                g2.drawImage(skin.tex64, 10, 10, 42, 42, 8, 8, 16, 16, null);   // rosto
                g2.drawImage(skin.tex64, 9, 9, 43, 43, 40, 8, 48, 16, null);    // chapéu
                g2.setColor(TEXTO);
                g2.setFont(new Font("SansSerif", Font.BOLD, 13));
                g2.drawString(skin.nome, 52, 24);
                g2.setColor(new Color(195, 225, 255, 190));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                g2.drawString(skin.fino ? "Fino" : "Clássico", 52, 40);
            }
            g2.dispose();
        }
    }

    /** Pré-visualização 2D pequena (frente/costas). */
    private static class Miniatura extends JComponent {
        private final String titulo;
        private BufferedImage imagem;

        Miniatura(String titulo) {
            this.titulo = titulo;
            setPreferredSize(new Dimension(96, 172));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 172));
        }

        void setImagem(BufferedImage img) {
            this.imagem = img;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(CAIXA);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            g2.setColor(BORDA);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            if (imagem != null) {
                g2.drawImage(imagem, (getWidth() - imagem.getWidth()) / 2, 4, null);
            }
            g2.setColor(TEXTO_SECUNDARIO);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(titulo, (getWidth() - fm.stringWidth(titulo)) / 2, getHeight() - 7);
            g2.dispose();
        }
    }

    // ================================================== Visualizador 3D (Swing)

    private static class Visualizador3D extends JComponent {
        private static final float DIST_PADRAO = 92f;
        private static final float YAW_PADRAO = (float) Math.toRadians(-28);
        private static final float PITCH_PADRAO = (float) Math.toRadians(12);

        private final Cena cena = new Cena(2);
        private SkinItem skin;
        private boolean fino;
        private boolean girar = true;
        private boolean andar;
        private boolean externa = true;
        private float yaw = YAW_PADRAO;
        private float pitch = PITCH_PADRAO;
        private float dist = DIST_PADRAO;
        private float fase;               // tempo da animação
        private boolean arrastando;
        private int ultimoX, ultimoY;
        private long ultimoQuadro = System.nanoTime();

        Visualizador3D() {
            setPreferredSize(new Dimension(360, 300));
            setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
            MouseAdapter m = new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) {
                    arrastando = true;
                    ultimoX = e.getX();
                    ultimoY = e.getY();
                }
                @Override public void mouseReleased(MouseEvent e) { arrastando = false; }
                @Override public void mouseDragged(MouseEvent e) {
                    yaw += (e.getX() - ultimoX) * 0.011f;
                    pitch += (e.getY() - ultimoY) * 0.008f;
                    pitch = Math.max(-1.25f, Math.min(1.25f, pitch));
                    ultimoX = e.getX();
                    ultimoY = e.getY();
                }
                @Override public void mouseWheelMoved(MouseWheelEvent e) {
                    dist *= (float) Math.pow(1.09, e.getPreciseWheelRotation());
                    dist = Math.max(42f, Math.min(170f, dist));
                }
            };
            addMouseListener(m);
            addMouseMotionListener(m);
            addMouseWheelListener(m);
            new Timer(16, e -> {
                long agora = System.nanoTime();
                float dt = Math.min(0.1f, (agora - ultimoQuadro) / 1e9f);
                ultimoQuadro = agora;
                if (!isShowing()) return;      // não gasta CPU quando a tela está escondida
                fase += dt;
                if (girar && !arrastando) yaw += dt * 0.7f;
                repaint();
            }).start();
        }

        void setSkin(SkinItem s) { skin = s; if (s != null) fino = s.fino; repaint(); }
        void setFino(boolean f) { fino = f; }
        void setGirar(boolean b) { girar = b; }
        void setAndar(boolean b) { andar = b; }
        void setCamadaExterna(boolean b) { externa = b; }
        void resetarVista() { yaw = YAW_PADRAO; pitch = PITCH_PADRAO; dist = DIST_PADRAO; }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            Shape recorte = new RoundRectangle2D.Float(0, 0, w, h, 16, 16);
            g2.setPaint(new GradientPaint(0, 0, new Color(6, 18, 36, 175), 0, h, new Color(16, 44, 78, 175)));
            g2.fill(recorte);
            g2.setColor(BORDA);
            g2.drawRoundRect(0, 0, w - 1, h - 1, 16, 16);

            if (skin == null) {
                g2.setColor(TEXTO_SECUNDARIO);
                g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
                String m = "Nenhuma skin selecionada";
                g2.drawString(m, (w - g2.getFontMetrics().stringWidth(m)) / 2, h / 2);
                g2.dispose();
                return;
            }

            g2.setClip(recorte);
            BufferedImage img = cena.renderizar(skin.pixels, fino, externa, yaw, pitch, dist, fase, andar, w, h);
            desenharChao(g2);
            g2.drawImage(img, 0, 0, null);
            g2.setClip(null);

            g2.setFont(new Font("SansSerif", Font.BOLD, 13));
            g2.setColor(TEXTO);
            g2.drawString(skin.nome, 14, 24);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            g2.setColor(new Color(195, 225, 255, 130));
            String dica = "Arraste para girar  •  Roda do mouse para zoom";
            g2.drawString(dica, (w - g2.getFontMetrics().stringWidth(dica)) / 2, h - 10);
            g2.dispose();
        }

        /** Sombra suave e anel da plataforma, projetados no chão da cena. */
        private void desenharChao(Graphics2D g2) {
            int[] raios = {13, 10, 7};
            int[] alfas = {38, 52, 70};
            for (int k = 0; k < raios.length; k++) {
                g2.setColor(new Color(0, 0, 0, alfas[k]));
                g2.fill(circuloNoChao(raios[k]));
            }
            g2.setColor(new Color(150, 205, 255, 70));
            g2.setStroke(new BasicStroke(1.4f));
            g2.draw(circuloNoChao(15));
        }

        private Polygon circuloNoChao(float raio) {
            Polygon p = new Polygon();
            for (int i = 0; i < 40; i++) {
                double a = i * Math.PI * 2 / 40;
                Point2D.Float s = cena.projetar((float) Math.cos(a) * raio, 0f, (float) Math.sin(a) * raio);
                p.addPoint(Math.round(s.x), Math.round(s.y));
            }
            return p;
        }
    }

    // ===================================================== Rasterizador 3D

    /**
     * Cena do boneco desenhada por software: projeção em perspectiva, z-buffer com
     * interpolação perspectiva-correta das coordenadas da textura, amostragem sem
     * suavização (pixels nítidos), iluminação por face e supersampling.
     */
    static final class Cena {
        private final int ss;
        private int w, h;
        private int[] big;
        private float[] zb;
        private BufferedImage saida;
        private int[] saidaPx;
        // câmera da última renderização (usada para projetar o chão)
        private float cosY = 1, sinY, cosP = 1, sinP, dist = 92, foco = 100, cx, cy;

        Cena(int supersampling) { this.ss = supersampling; }

        /** Projeta um ponto do mundo para a tela (mesma câmera do último quadro). */
        Point2D.Float projetar(float x, float y, float z) {
            float[] c = paraCamera(x, y - 16f, z);
            float prof = dist - c[2];
            return new Point2D.Float(cx + foco * c[0] / prof, cy - foco * c[1] / prof);
        }

        private float[] paraCamera(float x, float y, float z) {
            float x1 = x * cosY + z * sinY;
            float z1 = -x * sinY + z * cosY;
            float y2 = y * cosP - z1 * sinP;
            float z2 = y * sinP + z1 * cosP;
            return new float[]{x1, y2, z2};
        }

        BufferedImage renderizar(int[] tex, boolean fino, boolean externa, float yaw, float pitch,
                                 float distancia, float t, boolean andar, int largura, int altura) {
            garantir(largura, altura);
            Arrays.fill(big, 0);
            Arrays.fill(zb, 0f);
            cosY = (float) Math.cos(yaw);
            sinY = (float) Math.sin(yaw);
            cosP = (float) Math.cos(pitch);
            sinP = (float) Math.sin(pitch);
            dist = distancia;
            foco = 0.74f * altura * 92f / 32f;
            cx = largura / 2f;
            cy = altura * 0.47f;

            // ---- pose ----
            float bB = 0, bAd = 0, bAe = 0, bPd = 0, bPe = 0, zAd, zAe, subida = 0;
            if (andar) {
                float s = (float) Math.sin(t * 5.2f);
                bAd = 0.55f * s;  bAe = -0.55f * s;
                bPd = -0.62f * s; bPe = 0.62f * s;
                zAd = 0.04f;      zAe = -0.04f;
                subida = 0.45f * Math.abs((float) Math.cos(t * 5.2f));
            } else {
                float r = (float) Math.sin(t * 1.6f);   // respiração
                bAd = 0.03f * r;  bAe = -0.03f * r;
                zAd = 0.05f + 0.035f * r;  zAe = -0.05f - 0.035f * r;
            }
            float aw = fino ? 3f : 4f;

            // ---- camada base (sempre opaca) ----
            parte(tex, true, -4, 24, -4, 4, 32, 4, 0, 0, 8, 8, 8, 0, 24, 0, 0, 0, subida);
            parte(tex, true, -4, 12, -2, 4, 24, 2, 16, 16, 8, 12, 4, 0, 12, 0, 0, 0, subida);
            parte(tex, true, -4 - aw, 12, -2, -4, 24, 2, 40, 16, (int) aw, 12, 4, -4 - aw / 2, 22, 0, bAd, zAd, subida);
            parte(tex, true, 4, 12, -2, 4 + aw, 24, 2, 32, 48, (int) aw, 12, 4, 4 + aw / 2, 22, 0, bAe, zAe, subida);
            parte(tex, true, -4, 0, -2, 0, 12, 2, 0, 16, 4, 12, 4, -2, 12, 0, bPd, 0, subida);
            parte(tex, true, 0, 0, -2, 4, 12, 2, 16, 48, 4, 12, 4, 2, 12, 0, bPe, 0, subida);
            // ---- camada externa (translúcida, um pouco maior) ----
            if (externa) {
                float i1 = 0.5f, i2 = 0.25f;
                parte(tex, false, -4 - i1, 24 - i1, -4 - i1, 4 + i1, 32 + i1, 4 + i1, 32, 0, 8, 8, 8, 0, 24, 0, 0, 0, subida);
                parte(tex, false, -4 - i2, 12 - i2, -2 - i2, 4 + i2, 24 + i2, 2 + i2, 16, 32, 8, 12, 4, 0, 12, 0, 0, 0, subida);
                parte(tex, false, -4 - aw - i2, 12 - i2, -2 - i2, -4 + i2, 24 + i2, 2 + i2, 40, 32, (int) aw, 12, 4, -4 - aw / 2, 22, 0, bAd, zAd, subida);
                parte(tex, false, 4 - i2, 12 - i2, -2 - i2, 4 + aw + i2, 24 + i2, 2 + i2, 48, 48, (int) aw, 12, 4, 4 + aw / 2, 22, 0, bAe, zAe, subida);
                parte(tex, false, -4 - i2, 0 - i2, -2 - i2, 0 + i2, 12 + i2, 2 + i2, 0, 32, 4, 12, 4, -2, 12, 0, bPd, 0, subida);
                parte(tex, false, 0 - i2, 0 - i2, -2 - i2, 4 + i2, 12 + i2, 2 + i2, 0, 48, 4, 12, 4, 2, 12, 0, bPe, 0, subida);
            }
            reduzir();
            return saida;
        }

        private void garantir(int largura, int altura) {
            if (saida != null && w == largura && h == altura) return;
            w = Math.max(1, largura);
            h = Math.max(1, altura);
            big = new int[w * ss * h * ss];
            zb = new float[w * ss * h * ss];
            saida = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB_PRE);
            saidaPx = ((java.awt.image.DataBufferInt) saida.getRaster().getDataBuffer()).getData();
        }

        /** Uma parte do corpo: uma caixa com textura, girada em torno de um pivô. */
        private void parte(int[] tex, boolean opaca,
                           float x0, float y0, float z0, float x1, float y1, float z1,
                           int u0, int v0, int tw, int th, int td,
                           float px, float py, float pz, float rotX, float rotZ, float subida) {
            // Cada face: 4 cantos (BL, BR, TR, TL, vistos de fora) + retângulo da textura.
            float[][][] cantos = {
                    // frente (+z)
                    {{x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}},
                    // costas (-z)
                    {{x1, y0, z0}, {x0, y0, z0}, {x0, y1, z0}, {x1, y1, z0}},
                    // lado direito do personagem (-x)
                    {{x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, {x0, y1, z0}},
                    // lado esquerdo do personagem (+x)
                    {{x1, y0, z1}, {x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1}},
                    // topo (+y): embaixo da imagem fica a frente
                    {{x0, y1, z1}, {x1, y1, z1}, {x1, y1, z0}, {x0, y1, z0}},
                    // base (-y): em cima da imagem fica a frente
                    {{x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}}
            };
            // retângulos de textura {uEsq, vCima, uDir, vBaixo}
            float[][] uv = {
                    {u0 + td, v0 + td, u0 + td + tw, v0 + td + th},                 // frente
                    {u0 + 2 * td + tw, v0 + td, u0 + 2 * td + 2 * tw, v0 + td + th},// costas
                    {u0, v0 + td, u0 + td, v0 + td + th},                           // -x
                    {u0 + td + tw, v0 + td, u0 + 2 * td + tw, v0 + td + th},        // +x
                    {u0 + td, v0, u0 + td + tw, v0 + td},                           // topo
                    {u0 + td + tw, v0, u0 + td + 2 * tw, v0 + td}                   // base
            };
            float cr = (float) Math.cos(rotX), sr = (float) Math.sin(rotX);
            float cz = (float) Math.cos(rotZ), sz = (float) Math.sin(rotZ);

            for (int f = 0; f < 6; f++) {
                float[][] cam = new float[4][];
                float[] sx = new float[4], sy = new float[4], iw = new float[4];
                for (int k = 0; k < 4; k++) {
                    float x = cantos[f][k][0] - px, y = cantos[f][k][1] - py, z = cantos[f][k][2] - pz;
                    // gira em X e depois em Z em torno do pivô
                    float y1r = y * cr - z * sr;
                    float z1r = y * sr + z * cr;
                    float x2 = x * cz - y1r * sz;
                    float y2 = x * sz + y1r * cz;
                    float mx = x2 + px, my = y2 + py + subida, mz = z1r + pz;
                    float[] c = paraCamera(mx, my - 16f, mz);
                    cam[k] = c;
                    float prof = dist - c[2];
                    sx[k] = (cx + foco * c[0] / prof) * ss;
                    sy[k] = (cy - foco * c[1] / prof) * ss;
                    iw[k] = 1f / prof;
                }
                // normal em espaço de câmera e descarte das faces de trás
                float ax = cam[1][0] - cam[0][0], ay = cam[1][1] - cam[0][1], az = cam[1][2] - cam[0][2];
                float bx = cam[2][0] - cam[0][0], by = cam[2][1] - cam[0][1], bz = cam[2][2] - cam[0][2];
                float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
                float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (len < 1e-6f) continue;
                nx /= len; ny /= len; nz /= len;
                float vx = -cam[0][0], vy = -cam[0][1], vz = dist - cam[0][2];
                if (nx * vx + ny * vy + nz * vz <= 0) continue;
                // luz fixa na câmera (vinda de cima, da esquerda e da frente)
                float dot = nx * -0.36f + ny * 0.62f + nz * 0.70f;
                float brilho = Math.max(0.48f, Math.min(1.06f, 0.72f + 0.30f * dot));

                float[] r = uv[f];
                float[] us = {r[0], r[2], r[2], r[0]};
                float[] vs = {r[3], r[3], r[1], r[1]};
                triangulo(tex, opaca, brilho, r, sx, sy, iw, us, vs, 0, 1, 2);
                triangulo(tex, opaca, brilho, r, sx, sy, iw, us, vs, 0, 2, 3);
            }
        }

        private void triangulo(int[] tex, boolean opaca, float brilho, float[] reg,
                               float[] sx, float[] sy, float[] iw, float[] us, float[] vs,
                               int a, int b, int c) {
            int bw = w * ss, bh = h * ss;
            float x0 = sx[a], y0 = sy[a], x1 = sx[b], y1 = sy[b], x2 = sx[c], y2 = sy[c];
            float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
            if (Math.abs(area) < 1e-6f) return;
            float inv = 1f / area;
            int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2))));
            int maxX = Math.min(bw - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
            int minY = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2))));
            int maxY = Math.min(bh - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
            float iw0 = iw[a], iw1 = iw[b], iw2 = iw[c];
            float u0 = us[a] * iw0, u1 = us[b] * iw1, u2 = us[c] * iw2;
            float v0 = vs[a] * iw0, v1 = vs[b] * iw1, v2 = vs[c] * iw2;
            float uMin = reg[0] + 0.001f, uMax = reg[2] - 0.001f;
            float vMin = reg[1] + 0.001f, vMax = reg[3] - 0.001f;

            for (int y = minY; y <= maxY; y++) {
                float py = y + 0.5f;
                for (int x = minX; x <= maxX; x++) {
                    float px = x + 0.5f;
                    float w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) * inv;
                    float w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) * inv;
                    float w2 = 1f - w0 - w1;
                    if (w0 < 0 || w1 < 0 || w2 < 0) continue;
                    float iwp = w0 * iw0 + w1 * iw1 + w2 * iw2;
                    int idx = y * bw + x;
                    if (iwp <= zb[idx]) continue;
                    float u = (w0 * u0 + w1 * u1 + w2 * u2) / iwp;
                    float v = (w0 * v0 + w1 * v1 + w2 * v2) / iwp;
                    u = u < uMin ? uMin : Math.min(u, uMax);
                    v = v < vMin ? vMin : Math.min(v, vMax);
                    int argb = tex[((int) v) * 64 + (int) u];
                    int al = opaca ? 255 : argb >>> 24;
                    if (al == 0) continue;
                    int r = Math.min(255, (int) (((argb >> 16) & 255) * brilho));
                    int g = Math.min(255, (int) (((argb >> 8) & 255) * brilho));
                    int bl = Math.min(255, (int) ((argb & 255) * brilho));
                    if (al == 255) {
                        big[idx] = 0xFF000000 | (r << 16) | (g << 8) | bl;
                        zb[idx] = iwp;
                    } else {
                        float sa = al / 255f;
                        int d = big[idx];
                        float resto = 1f - sa;
                        int na = Math.min(255, (int) (al + (d >>> 24) * resto));
                        int nr = Math.min(255, (int) (r * sa + ((d >> 16) & 255) * resto));
                        int ng = Math.min(255, (int) (g * sa + ((d >> 8) & 255) * resto));
                        int nb = Math.min(255, (int) (bl * sa + (d & 255) * resto));
                        big[idx] = (na << 24) | (nr << 16) | (ng << 8) | nb;
                    }
                }
            }
        }

        /** Filtro de caixa ss x ss (supersampling) sobre pixels pré-multiplicados. */
        private void reduzir() {
            int bw = w * ss;
            int n = ss * ss;
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int sa = 0, sr = 0, sg = 0, sb = 0;
                    for (int j = 0; j < ss; j++) {
                        int linha = (y * ss + j) * bw + x * ss;
                        for (int i = 0; i < ss; i++) {
                            int p = big[linha + i];
                            sa += p >>> 24;
                            sr += (p >> 16) & 255;
                            sg += (p >> 8) & 255;
                            sb += p & 255;
                        }
                    }
                    saidaPx[y * w + x] = ((sa / n) << 24) | ((sr / n) << 16) | ((sg / n) << 8) | (sb / n);
                }
            }
        }
    }

    // ================================================================ Estilo

    private JScrollPane criarRolagem(JList<?> l) {
        JScrollPane r = new JScrollPane(l, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        r.setOpaque(false);
        r.getViewport().setOpaque(false);
        r.setBorder(BorderFactory.createEmptyBorder());
        r.getVerticalScrollBar().setUnitIncrement(26);
        JScrollBar barra = r.getVerticalScrollBar();
        barra.setOpaque(false);
        barra.setPreferredSize(new Dimension(10, 0));
        barra.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() { }
            @Override protected JButton createDecreaseButton(int o) { return vazioBtn(); }
            @Override protected JButton createIncreaseButton(int o) { return vazioBtn(); }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle rr) { }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle rr) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(150, 205, 255, 120));
                g2.fillRoundRect(rr.x + 2, rr.y, rr.width - 4, rr.height, 8, 8);
                g2.dispose();
            }
            private JButton vazioBtn() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });
        return r;
    }

    private JPanel painelTranslucido(Color fundo, int arco) {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(fundo);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);
                g2.setColor(BORDA);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        return p;
    }

    private JToggleButton chip(String texto) {
        JToggleButton b = new JToggleButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(5, 10, 5, 10));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean on = ((AbstractButton) c).isSelected();
                g2.setColor(on ? new Color(120, 195, 255, 55) : CAIXA);
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 14, 14);
                g2.setColor(on ? AZUL_CLARO : BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 14, 14);
                c.setForeground(!c.isEnabled() ? new Color(195, 225, 255, 70)
                        : on ? AZUL_CLARO : new Color(195, 225, 255, 150));
                g2.dispose();
                paint(g, c);
            }
        });
        return b;
    }

    private JButton botao(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setForeground(TEXTO);
        b.setBackground(BOTAO);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(7, 12, 7, 12));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color fundo = c.isEnabled() ? c.getBackground()
                        : new Color(c.getBackground().getRed(), c.getBackground().getGreen(),
                        c.getBackground().getBlue(), 90);
                g2.setColor(fundo);
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 16, 16);
                g2.setColor(BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 16, 16);
                c.setForeground(c.isEnabled() ? TEXTO : new Color(240, 242, 247, 110));
                g2.dispose();
                paint(g, c);
            }
        });
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                Object hv = b.getClientProperty("hover");
                b.setBackground(hv instanceof Color ? (Color) hv : BOTAO_HOVER);
            }
            @Override public void mouseExited(MouseEvent e) {
                Object n = b.getClientProperty("normal");
                b.setBackground(n instanceof Color ? (Color) n : BOTAO);
            }
        });
        return b;
    }
}