package Screens;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Tela "Logs": à esquerda a lista de inicializações (número + versão),
 * à direita o conteúdo do log lido e mostrado como lista de linhas
 * (sem abrir o .txt/.zip). Só o layout - quem lê o arquivo chama setConteudo().
 */
public class Logs extends JPanel {

    private static final Color PAINEL = new Color(12, 35, 65, 155);
    private static final Color CAIXA = new Color(4, 14, 30, 170);
    private static final Color BOTAO = new Color(25, 75, 125, 225);
    private static final Color BOTAO_HOVER = new Color(38, 105, 165, 240);
    private static final Color SELECAO = new Color(38, 105, 165, 220);
    private static final Color TEXTO = new Color(240, 242, 247);
    private static final Color TEXTO_SECUNDARIO = new Color(195, 225, 255);
    private static final Color NUMERO_LINHA = new Color(195, 225, 255, 110);
    private static final Color COR_INFO = new Color(120, 195, 255);
    private static final Color COR_WARN = new Color(255, 205, 110);
    private static final Color COR_ERROR = new Color(255, 135, 135);
    private static final Color BORDA = new Color(255, 255, 255, 35);
    private static final Color BORDA_BOTAO = new Color(150, 205, 255, 90);

    private enum Nivel { INFO, WARN, ERROR }

    /** Uma inicialização do launcher (um arquivo de log). */
    public static class EntradaLog {
        public final int numero;
        public final String versao;
        public final String data;
        public final Object origem;   // ex.: o File do .txt/.zip; a tela não mexe nele

        public EntradaLog(int numero, String versao, String data, Object origem) {
            this.numero = numero;
            this.versao = versao;
            this.data = data;
            this.origem = origem;
        }
    }

    private static class Linha {
        final int numero;
        final String texto;
        final Nivel nivel;

        Linha(int numero, String texto) {
            this.numero = numero;
            this.texto = texto;
            if (texto.contains("ERROR") || texto.contains("FATAL") || texto.contains("Exception")) {
                nivel = Nivel.ERROR;
            } else if (texto.contains("WARN")) {
                nivel = Nivel.WARN;
            } else {
                nivel = Nivel.INFO;
            }
        }
    }

    private final DefaultListModel<EntradaLog> modeloLogs = new DefaultListModel<>();
    private final JList<EntradaLog> listaLogs = new JList<>(modeloLogs);
    private final DefaultListModel<Linha> modeloLinhas = new DefaultListModel<>();
    private final JList<Linha> listaLinhas = new JList<>(modeloLinhas);
    private final List<Linha> todasLinhas = new ArrayList<>();
    private final JToggleButton chipInfo = chip("INFO", COR_INFO);
    private final JToggleButton chipWarn = chip("WARN", COR_WARN);
    private final JToggleButton chipError = chip("ERROR", COR_ERROR);
    private final JTextField campoBusca = criarCampoBusca();
    private final JLabel status = new JLabel("Selecione um log na lista.");
    private final CardLayout cartas = new CardLayout();
    private final JPanel areaLinhas = new JPanel(cartas);
    private final JLabel vazio = new JLabel("Selecione um log na lista ao lado.", SwingConstants.CENTER);
    private Consumer<EntradaLog> aoSelecionar = l -> { };
    private boolean ajustando;

    public Logs() {
        setLayout(new BorderLayout());
        setOpaque(false);
        montarInterface();
    }

    // ---------------------------------------------------------------- API

    public void setLogs(List<EntradaLog> logs) {
        ajustando = true;
        modeloLogs.clear();
        for (EntradaLog l : logs) modeloLogs.addElement(l);
        ajustando = false;
        setConteudo(new ArrayList<>());
    }

    public EntradaLog getSelecionado() { return listaLogs.getSelectedValue(); }

    /** Chamado quando o usuário clica num log; quem recebe lê o arquivo e chama setConteudo(). */
    public void setOnSelecionar(Consumer<EntradaLog> consumidor) {
        this.aoSelecionar = consumidor == null ? l -> { } : consumidor;
    }

    /** Mostra as linhas do log lido (pode ser chamado de qualquer thread). */
    public void setConteudo(List<String> linhas) {
        SwingUtilities.invokeLater(() -> {
            todasLinhas.clear();
            int n = 1;
            for (String t : linhas) todasLinhas.add(new Linha(n++, t));
            aplicarFiltro();
            if (linhas.isEmpty() && listaLogs.getSelectedValue() == null) {
                cartas.show(areaLinhas, "vazio");
            }
        });
    }

    // ------------------------------------------------------------- Layout

    private void montarInterface() {
        JPanel raiz = new JPanel(new BorderLayout(12, 12));
        raiz.setOpaque(false);
        raiz.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Logs");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel subtitulo = new JLabel("Registro de cada inicialização do launcher.");
        subtitulo.setForeground(TEXTO_SECUNDARIO);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel cabecalho = new JPanel();
        cabecalho.setOpaque(false);
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.add(titulo);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(subtitulo);

        JPanel corpo = new JPanel(new BorderLayout(12, 0));
        corpo.setOpaque(false);
        corpo.add(montarPainelEsquerdo(), BorderLayout.WEST);
        corpo.add(montarPainelDireito(), BorderLayout.CENTER);

        raiz.add(cabecalho, BorderLayout.NORTH);
        raiz.add(corpo, BorderLayout.CENTER);
        add(raiz, BorderLayout.CENTER);
    }

    private JPanel montarPainelEsquerdo() {
        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BorderLayout(0, 8));
        painel.setBorder(new EmptyBorder(12, 12, 12, 12));
        painel.setPreferredSize(new Dimension(230, 100));

        JLabel t = new JLabel("Inicializações");
        t.setForeground(TEXTO);
        t.setFont(new Font("SansSerif", Font.BOLD, 15));

        listaLogs.setOpaque(false);
        listaLogs.setFixedCellHeight(48);
        listaLogs.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaLogs.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        listaLogs.setCellRenderer(new LogRenderer());
        listaLogs.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || ajustando) return;
            EntradaLog sel = listaLogs.getSelectedValue();
            if (sel != null) {
                status.setText("Lendo log #" + sel.numero + "...");
                aoSelecionar.accept(sel);
            }
        });

        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(4, 4, 4, 4));
        caixa.add(criarRolagem(listaLogs, false), BorderLayout.CENTER);

        painel.add(t, BorderLayout.NORTH);
        painel.add(caixa, BorderLayout.CENTER);
        return painel;
    }

    private JPanel montarPainelDireito() {
        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BorderLayout(0, 8));
        painel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Barra: filtros + busca + copiar
        chipInfo.setSelected(true);
        chipWarn.setSelected(true);
        chipError.setSelected(true);
        for (JToggleButton c : new JToggleButton[]{chipInfo, chipWarn, chipError}) {
            c.addActionListener(e -> aplicarFiltro());
        }
        campoBusca.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { aplicarFiltro(); }
            @Override public void removeUpdate(DocumentEvent e) { aplicarFiltro(); }
            @Override public void changedUpdate(DocumentEvent e) { aplicarFiltro(); }
        });
        JButton copiar = botao("Copiar");
        copiar.addActionListener(e -> copiarVisivel());

        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        filtros.setOpaque(false);
        filtros.add(chipInfo);
        filtros.add(chipWarn);
        filtros.add(chipError);

        JPanel busca = painelTranslucido(CAIXA, 14);
        busca.setLayout(new BorderLayout());
        busca.setBorder(new EmptyBorder(4, 12, 4, 12));
        busca.add(campoBusca, BorderLayout.CENTER);

        JPanel barra = new JPanel(new BorderLayout(8, 0));
        barra.setOpaque(false);
        barra.add(filtros, BorderLayout.WEST);
        barra.add(busca, BorderLayout.CENTER);
        barra.add(copiar, BorderLayout.EAST);

        // Lista de linhas do log
        listaLinhas.setOpaque(false);
        listaLinhas.setFixedCellHeight(20);
        listaLinhas.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        listaLinhas.setCellRenderer(new LinhaRenderer());

        vazio.setForeground(TEXTO_SECUNDARIO);
        vazio.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(4, 4, 4, 4));
        areaLinhas.setOpaque(false);
        areaLinhas.add(vazio, "vazio");
        areaLinhas.add(criarRolagem(listaLinhas, true), "lista");
        cartas.show(areaLinhas, "vazio");
        caixa.add(areaLinhas, BorderLayout.CENTER);

        status.setForeground(TEXTO_SECUNDARIO);
        status.setFont(new Font("SansSerif", Font.PLAIN, 12));

        painel.add(barra, BorderLayout.NORTH);
        painel.add(caixa, BorderLayout.CENTER);
        painel.add(status, BorderLayout.SOUTH);
        return painel;
    }

    // ----------------------------------------------------------- Filtros

    private void aplicarFiltro() {
        String termo = campoBusca.getText().trim().toLowerCase();
        modeloLinhas.clear();
        List<Linha> visiveis = new ArrayList<>();
        for (Linha l : todasLinhas) {
            boolean nivelOk = (l.nivel == Nivel.INFO && chipInfo.isSelected())
                    || (l.nivel == Nivel.WARN && chipWarn.isSelected())
                    || (l.nivel == Nivel.ERROR && chipError.isSelected());
            if (nivelOk && (termo.isEmpty() || l.texto.toLowerCase().contains(termo))) {
                visiveis.add(l);
            }
        }
        for (Linha l : visiveis) modeloLinhas.addElement(l);
        if (listaLogs.getSelectedValue() != null) {
            cartas.show(areaLinhas, "lista");
            EntradaLog sel = listaLogs.getSelectedValue();
            status.setText("Log #" + sel.numero + " (" + sel.versao + ")  •  "
                    + visiveis.size() + " de " + todasLinhas.size() + " linhas");
        }
    }

    private void copiarVisivel() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < modeloLinhas.size(); i++) {
            sb.append(modeloLinhas.get(i).texto).append('\n');
        }
        Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new StringSelection(sb.toString()), null);
    }

    // ---------------------------------------------------------- Renderers

    /** Linha da lista da esquerda: "Log #12" + versão e data. */
    private static class LogRenderer extends JComponent implements ListCellRenderer<EntradaLog> {
        private EntradaLog log;
        private boolean selecionado;

        @Override
        public Component getListCellRendererComponent(JList<? extends EntradaLog> l, EntradaLog v,
                                                      int i, boolean sel, boolean foco) {
            log = v;
            selecionado = sel;
            return this;
        }

        @Override
        public Dimension getPreferredSize() { return new Dimension(100, 48); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (selecionado) {
                g2.setColor(SELECAO);
                g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 12, 12);
            }
            if (log != null) {
                g2.setColor(TEXTO);
                g2.setFont(new Font("SansSerif", Font.BOLD, 13));
                g2.drawString("Log #" + log.numero, 14, 20);
                g2.setColor(new Color(195, 225, 255, 190));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                g2.drawString(log.versao + "  •  " + log.data, 14, 37);
            }
            g2.dispose();
        }
    }

    /** Linha do log: número apagado + texto colorido pelo nível. */
    private static class LinhaRenderer extends JComponent implements ListCellRenderer<Linha> {
        private static final Font FONTE = new Font(Font.MONOSPACED, Font.PLAIN, 12);
        private Linha linha;
        private boolean selecionada;

        @Override
        public Component getListCellRendererComponent(JList<? extends Linha> l, Linha v,
                                                      int i, boolean sel, boolean foco) {
            linha = v;
            selecionada = sel;
            return this;
        }

        @Override
        public Dimension getPreferredSize() {
            FontMetrics fm = getFontMetrics(FONTE);
            int w = linha == null ? 100 : 58 + fm.stringWidth(linha.texto) + 16;
            return new Dimension(w, 20);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (selecionada) {
                g2.setColor(new Color(38, 105, 165, 150));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
            if (linha != null) {
                g2.setFont(FONTE);
                FontMetrics fm = g2.getFontMetrics();
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                String n = String.valueOf(linha.numero);
                g2.setColor(NUMERO_LINHA);
                g2.drawString(n, 44 - fm.stringWidth(n), y);
                g2.setColor(linha.nivel == Nivel.ERROR ? COR_ERROR
                        : linha.nivel == Nivel.WARN ? COR_WARN : TEXTO);
                g2.drawString(linha.texto, 58, y);
            }
            g2.dispose();
        }
    }

    // ---------------------------------------------------------- Estilo

    private JScrollPane criarRolagem(JList<?> lista, boolean horizontal) {
        JScrollPane r = new JScrollPane(lista,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                horizontal ? ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED
                        : ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        r.setOpaque(false);
        r.getViewport().setOpaque(false);
        r.setBorder(BorderFactory.createEmptyBorder());
        r.getVerticalScrollBar().setUnitIncrement(20);
        estilizarBarra(r.getVerticalScrollBar(), true);
        estilizarBarra(r.getHorizontalScrollBar(), false);
        return r;
    }

    private void estilizarBarra(JScrollBar barra, boolean vertical) {
        barra.setOpaque(false);
        barra.setPreferredSize(vertical ? new Dimension(10, 0) : new Dimension(0, 10));
        barra.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() { }
            @Override protected JButton createDecreaseButton(int o) { return vazioBtn(); }
            @Override protected JButton createIncreaseButton(int o) { return vazioBtn(); }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(150, 205, 255, 120));
                if (vertical) g2.fillRoundRect(r.x + 2, r.y, r.width - 4, r.height, 8, 8);
                else g2.fillRoundRect(r.x, r.y + 2, r.width, r.height - 4, 8, 8);
                g2.dispose();
            }
            private JButton vazioBtn() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });
    }

    private JPanel painelTranslucido(Color fundo, int arco) {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(fundo);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);
                g2.setColor(BORDA);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        return p;
    }

    private JTextField criarCampoBusca() {
        JTextField tf = new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getText().isEmpty()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                            RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    g2.setColor(new Color(195, 225, 255, 110));
                    g2.setFont(getFont());
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString("Buscar no log...", getInsets().left,
                            (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
                    g2.dispose();
                }
            }
        };
        tf.setOpaque(false);
        tf.setBorder(BorderFactory.createEmptyBorder());
        tf.setForeground(TEXTO);
        tf.setCaretColor(TEXTO);
        tf.setFont(new Font("SansSerif", Font.PLAIN, 12));
        return tf;
    }

    private JToggleButton chip(String texto, Color cor) {
        JToggleButton b = new JToggleButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(5, 10, 5, 10));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean on = ((AbstractButton) c).isSelected();
                g2.setColor(on ? new Color(cor.getRed(), cor.getGreen(), cor.getBlue(), 55) : CAIXA);
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 14, 14);
                g2.setColor(on ? cor : BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 14, 14);
                c.setForeground(on ? cor : new Color(195, 225, 255, 120));
                g2.dispose();
                paint(g, c);
            }
        });
        return b;
    }

    private JButton botao(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setForeground(TEXTO);
        b.setBackground(BOTAO);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(6, 12, 6, 12));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(c.getBackground());
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 16, 16);
                g2.setColor(BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 16, 16);
                g2.dispose();
                paint(g, c);
            }
        });
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(BOTAO_HOVER); }
            @Override public void mouseExited(MouseEvent e) { b.setBackground(BOTAO); }
        });
        return b;
    }
}