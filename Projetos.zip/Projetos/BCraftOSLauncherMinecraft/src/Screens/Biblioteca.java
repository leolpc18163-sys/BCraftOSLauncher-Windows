package Screens;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Tela "Biblioteca": quatro abas.
 *  - Minhas versões: lista das instalações + detalhes + ações (abrir pasta, duplicar, renomear, excluir).
 *  - Instalar versões: lista de versões oficiais (filtro por tipo e busca) + painel de instalação
 *    (nome, loader, botão Baixar e instalar, progresso).
 *  - Modpacks: lista dos modpacks (instâncias) + detalhes + ações (abrir pasta, duplicar, renomear, excluir).
 *  - Mods: escolhe a instância (o modpack), cria um modpack novo ali mesmo e baixa os mods para ele.
 *
 * Só o layout e o comportamento de tela (filtros/busca). Carregar, baixar e instalar
 * ficam para a lógica (pacote core), ligada pelos callbacks setOn... e pelos set... abaixo.
 */
public class Biblioteca extends JPanel {

    private static final Color PAINEL = new Color(12, 35, 65, 155);
    private static final Color CAIXA = new Color(4, 14, 30, 170);
    private static final Color BOTAO = new Color(25, 75, 125, 225);
    private static final Color BOTAO_HOVER = new Color(38, 105, 165, 240);
    private static final Color DESTAQUE = new Color(38, 105, 165, 235);
    private static final Color DESTAQUE_HOVER = new Color(83, 165, 235, 240);
    private static final Color PERIGO = new Color(150, 50, 60, 225);
    private static final Color PERIGO_HOVER = new Color(190, 70, 80, 240);
    private static final Color SELECAO = new Color(38, 105, 165, 220);
    private static final Color TEXTO = new Color(240, 242, 247);
    private static final Color TEXTO_SECUNDARIO = new Color(195, 225, 255);
    private static final Color AZUL_CLARO = new Color(120, 195, 255);
    private static final Color VERDE = new Color(120, 225, 160);
    private static final Color BORDA = new Color(255, 255, 255, 35);
    private static final Color BORDA_BOTAO = new Color(150, 205, 255, 90);

    /** A área rolável da lista de versões tem espaço para, no mínimo, este número de linhas. */
    private static final int MIN_LINHAS = 30;
    private static final String[] LOADERS = {"Vanilla", "Fabric", "Forge", "NeoForge", "Quilt"};
    private static final String[] TIPOS = {"Release", "Snapshot", "Beta", "Alpha"};

    // ================================================================ Modelos

    /** Uma instalação do usuário (aba "Minhas versões"). */
    public static class Instalacao {
        public final String nome;
        public final String versao;
        public final String tipo;        // Release, Snapshot, Beta, Alpha
        public final String loader;      // Vanilla, Fabric, Forge, NeoForge, Quilt
        public final String ultimoUso;   // texto pronto, ex.: "hoje 15:31"
        public final String tamanho;     // texto pronto, ex.: "412 MB"
        public final String pasta;
        public final Object origem;

        public Instalacao(String nome, String versao, String tipo, String loader,
                          String ultimoUso, String tamanho, String pasta, Object origem) {
            this.nome = nome;
            this.versao = versao;
            this.tipo = tipo;
            this.loader = loader;
            this.ultimoUso = ultimoUso;
            this.tamanho = tamanho;
            this.pasta = pasta;
            this.origem = origem;
        }

        @Override public String toString() { return nome; }
    }

    /** Uma versão oficial disponível para instalar (aba "Instalar versões"). */
    public static class VersaoMc {
        public final String id;          // ex.: "1.21.8"
        public final String tipo;        // Release, Snapshot, Beta, Alpha
        public final String data;        // texto pronto, ex.: "17/07/2025"
        public final boolean instalada;

        public VersaoMc(String id, String tipo, String data, boolean instalada) {
            this.id = id;
            this.tipo = tipo;
            this.data = data;
            this.instalada = instalada;
        }

        @Override public String toString() { return id; }
    }

    /** O que o usuário pediu na aba de instalar. */
    public static class PedidoInstalacao {
        public final String versao;
        public final String tipo;
        public final String loader;
        public final String nome;        // vazio = usar o padrão (a própria versão)

        PedidoInstalacao(String versao, String tipo, String loader, String nome) {
            this.versao = versao;
            this.tipo = tipo;
            this.loader = loader;
            this.nome = nome;
        }
    }

    /** Um modpack = uma instância onde os mods são instalados. */
    public static class Modpack {
        public final String nome;
        public final String versaoMc;
        public final String loader;
        public final int qtdMods;
        public final String ultimoUso;
        public final String pasta;
        public final Object origem;

        public Modpack(String nome, String versaoMc, String loader, int qtdMods,
                       String ultimoUso, String pasta, Object origem) {
            this.nome = nome;
            this.versaoMc = versaoMc;
            this.loader = loader;
            this.qtdMods = qtdMods;
            this.ultimoUso = ultimoUso;
            this.pasta = pasta;
            this.origem = origem;
        }

        @Override public String toString() { return nome; }
    }

    /** Um mod encontrado na busca (ou já instalado no modpack). */
    public static class ModItem {
        public final String nome;
        public final String autor;
        public final String descricao;
        public final String downloads;   // texto pronto, ex.: "12,4 mi"
        public final boolean instalado;
        public final Object origem;

        public ModItem(String nome, String autor, String descricao, String downloads,
                       boolean instalado, Object origem) {
            this.nome = nome;
            this.autor = autor;
            this.descricao = descricao;
            this.downloads = downloads;
            this.instalado = instalado;
            this.origem = origem;
        }

        @Override public String toString() { return nome; }
    }

    /** O que o usuário pediu ao criar um modpack. */
    public static class PedidoModpack {
        public final String nome;
        public final String versaoMc;
        public final String loader;

        PedidoModpack(String nome, String versaoMc, String loader) {
            this.nome = nome;
            this.versaoMc = versaoMc;
            this.loader = loader;
        }
    }

    // ================================================================ Campos

    private JTabbedPane abas;

    // aba 1
    private final List<Instalacao> todasInstalacoes = new ArrayList<>();
    private final DefaultListModel<Instalacao> modeloInstalacoes = new DefaultListModel<>();
    private final JList<Instalacao> listaInstalacoes = new JList<>(modeloInstalacoes);
    private final JTextField buscaInstalacoes = criarCampoBusca("Buscar instalação...");
    private final JLabel contagem = new JLabel(" ");
    private final CardLayout cartasInstalacoes = new CardLayout();
    private final JPanel areaInstalacoes = new JPanel(cartasInstalacoes);
    private final JLabel dNome = valor();
    private final JLabel dVersao = valor();
    private final JLabel dLoader = valor();
    private final JLabel dTipo = valor();
    private final JLabel dUltimoUso = valor();
    private final JLabel dTamanho = valor();
    private final JLabel dPasta = valor();
    private final JButton botaoAbrirPasta = botao("Abrir pasta");
    private final JButton botaoDuplicar = botao("Duplicar");
    private final JButton botaoRenomear = botao("Renomear");
    private final JButton botaoExcluir = botao("Excluir");

    // aba 2
    private final List<VersaoMc> todasVersoes = new ArrayList<>();
    private final DefaultListModel<VersaoMc> modeloVersoes = new DefaultListModel<>();
    private final JList<VersaoMc> listaVersoes = criarListaVersoes();
    private final JToggleButton[] chipsTipo = new JToggleButton[TIPOS.length];
    private final JToggleButton[] chipsLoader = new JToggleButton[LOADERS.length];
    private final JTextField buscaVersoes = criarCampoBusca("Buscar versão...");
    private final JLabel versaoEscolhida = new JLabel("Nenhuma versão selecionada");
    private final JTextField campoNomeInstalacao = criarCampoDica("Igual à versão (opcional)");
    private final JButton botaoInstalar = botao("Baixar e instalar");
    private final JLabel statusInstalacao = new JLabel("Selecione uma versão para continuar.");
    private final Barra barra = new Barra();

    // aba 3 e 4 (o mesmo modelo e a mesma seleção valem nas duas abas)
    private final DefaultListModel<Modpack> modeloModpacks = new DefaultListModel<>();
    private final ListSelectionModel selecaoModpack = new DefaultListSelectionModel();
    private final JList<Modpack> listaModpacks = new JList<>(modeloModpacks);
    private final JList<Modpack> listaInstancia = new JList<>(modeloModpacks);
    private final JLabel contagemModpacks = new JLabel(" ");
    private final CardLayout cartasModpacks = new CardLayout();
    private final JPanel areaModpacks = new JPanel(cartasModpacks);
    private final JLabel pNome = valor();
    private final JLabel pVersao = valor();
    private final JLabel pLoader = valor();
    private final JLabel pMods = valor();
    private final JLabel pUltimoUso = valor();
    private final JLabel pPasta = valor();
    private final JButton botaoPAbrir = botao("Abrir pasta");
    private final JButton botaoPDuplicar = botao("Duplicar");
    private final JButton botaoPRenomear = botao("Renomear");
    private final JButton botaoPExcluir = botao("Excluir");

    private final CardLayout cartasEsquerdaMods = new CardLayout();
    private final JPanel esquerdaMods = new JPanel(cartasEsquerdaMods);
    private final JTextField campoNomeModpack = criarCampoDica("Nome do modpack");
    private final DefaultListModel<VersaoMc> modeloVersoesModpack = new DefaultListModel<>();
    private final JList<VersaoMc> listaVersoesModpack = new JList<>(modeloVersoesModpack);
    private final JToggleButton[] chipsLoaderModpack = new JToggleButton[LOADERS.length - 1];
    private final JLabel avisoCriacao = new JLabel(" ");
    private final List<ModItem> todosMods = new ArrayList<>();
    private final DefaultListModel<ModItem> modeloMods = new DefaultListModel<>();
    private final JList<ModItem> listaMods = new JList<>(modeloMods);
    private final JToggleButton chipTodos = chip("Todos");
    private final JToggleButton chipInstalados = chip("Instalados");
    private final JTextField buscaMods = criarCampoBusca("Buscar mods (ex.: sodium, jei, create)...");
    private final JLabel tituloMods = new JLabel("Mods");
    private final CardLayout cartasMods = new CardLayout();
    private final JPanel areaMods = new JPanel(cartasMods);
    private final JLabel statusMods = new JLabel("Selecione um modpack para baixar mods.");
    private final Barra barraMods = new Barra();
    private final JButton botaoBaixarMod = botao("Baixar");
    private final JButton botaoRemoverMod = botao("Remover");

    // callbacks
    private Runnable aoAtualizar = () -> { };
    private Consumer<Instalacao> aoSelecionarInstalacao = i -> { };
    private Consumer<Instalacao> aoAbrirPasta = i -> { };
    private Consumer<Instalacao> aoDuplicar = i -> { };
    private Consumer<Instalacao> aoRenomear = i -> { };
    private Consumer<Instalacao> aoExcluir = i -> { };
    private Consumer<PedidoInstalacao> aoInstalar = p -> { };
    private Runnable aoImportarModpack = () -> { };
    private Consumer<Modpack> aoSelecionarModpack = m -> { };
    private Consumer<Modpack> aoAbrirPastaModpack = m -> { };
    private Consumer<Modpack> aoDuplicarModpack = m -> { };
    private Consumer<Modpack> aoRenomearModpack = m -> { };
    private Consumer<Modpack> aoExcluirModpack = m -> { };
    private Consumer<PedidoModpack> aoCriarModpack = p -> { };
    private BiConsumer<Modpack, String> aoBuscarMods = (m, q) -> { };
    private BiConsumer<Modpack, ModItem> aoBaixarMod = (m, i) -> { };
    private BiConsumer<Modpack, ModItem> aoRemoverMod = (m, i) -> { };

    public Biblioteca() {
        setLayout(new BorderLayout());
        setOpaque(false);
        montarInterface();
        atualizarDetalhes();
        atualizarPainelInstalar();
        atualizarModpacks();
        atualizarBotoesMod();
    }

    // ===================================================================== API

    public void setInstalacoes(List<Instalacao> lista) {
        todasInstalacoes.clear();
        todasInstalacoes.addAll(lista);
        filtrarInstalacoes();
    }

    public Instalacao getInstalacaoSelecionada() { return listaInstalacoes.getSelectedValue(); }

    public void setVersoesDisponiveis(List<VersaoMc> lista) {
        todasVersoes.clear();
        todasVersoes.addAll(lista);
        filtrarVersoes();
    }

    public VersaoMc getVersaoSelecionada() { return listaVersoes.getSelectedValue(); }

    public void setModpacks(List<Modpack> lista) {
        modeloModpacks.clear();
        for (Modpack m : lista) modeloModpacks.addElement(m);
        if (!modeloModpacks.isEmpty()) selecaoModpack.setSelectionInterval(0, 0);
        else selecaoModpack.clearSelection();
        atualizarModpacks();
    }

    public Modpack getModpackSelecionado() { return listaModpacks.getSelectedValue(); }

    /** Resultado da busca de mods (ou os mods já instalados no modpack). */
    public void setMods(List<ModItem> lista) {
        todosMods.clear();
        todosMods.addAll(lista);
        filtrarMods();
    }

    public ModItem getModSelecionado() { return listaMods.getSelectedValue(); }

    /** 0-100 mostra a barra; valor negativo esconde. */
    public void setProgressoMods(int porcento) { barraMods.setValor(porcento); }
    public void setStatusMods(String texto) { statusMods.setText(texto); }

    /** 0-100 mostra a barra; valor negativo esconde. */
    public void setProgresso(int porcento) { barra.setValor(porcento); }
    public void setStatusInstalacao(String texto) { statusInstalacao.setText(texto); }

    public void setOnAtualizar(Runnable r) { aoAtualizar = r == null ? () -> { } : r; }
    public void setOnSelecionarInstalacao(Consumer<Instalacao> c) { aoSelecionarInstalacao = c == null ? i -> { } : c; }
    public void setOnAbrirPasta(Consumer<Instalacao> c) { aoAbrirPasta = c == null ? i -> { } : c; }
    public void setOnDuplicar(Consumer<Instalacao> c) { aoDuplicar = c == null ? i -> { } : c; }
    public void setOnRenomear(Consumer<Instalacao> c) { aoRenomear = c == null ? i -> { } : c; }
    public void setOnExcluir(Consumer<Instalacao> c) { aoExcluir = c == null ? i -> { } : c; }
    public void setOnInstalar(Consumer<PedidoInstalacao> c) { aoInstalar = c == null ? p -> { } : c; }
    public void setOnImportarModpack(Runnable r) { aoImportarModpack = r == null ? () -> { } : r; }
    public void setOnSelecionarModpack(Consumer<Modpack> c) { aoSelecionarModpack = c == null ? m -> { } : c; }
    public void setOnAbrirPastaModpack(Consumer<Modpack> c) { aoAbrirPastaModpack = c == null ? m -> { } : c; }
    public void setOnDuplicarModpack(Consumer<Modpack> c) { aoDuplicarModpack = c == null ? m -> { } : c; }
    public void setOnRenomearModpack(Consumer<Modpack> c) { aoRenomearModpack = c == null ? m -> { } : c; }
    public void setOnExcluirModpack(Consumer<Modpack> c) { aoExcluirModpack = c == null ? m -> { } : c; }
    public void setOnCriarModpack(Consumer<PedidoModpack> c) { aoCriarModpack = c == null ? p -> { } : c; }
    public void setOnBuscarMods(BiConsumer<Modpack, String> c) { aoBuscarMods = c == null ? (m, q) -> { } : c; }
    public void setOnBaixarMod(BiConsumer<Modpack, ModItem> c) { aoBaixarMod = c == null ? (m, i) -> { } : c; }
    public void setOnRemoverMod(BiConsumer<Modpack, ModItem> c) { aoRemoverMod = c == null ? (m, i) -> { } : c; }

    // =================================================================== Layout

    private void montarInterface() {
        JPanel cabecalho = new JPanel();
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setOpaque(false);
        cabecalho.setBorder(new EmptyBorder(16, 16, 10, 16));
        JLabel titulo = new JLabel("Biblioteca");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel descricao = new JLabel("Gerencie suas instalações do Minecraft e instale novas versões.");
        descricao.setForeground(TEXTO_SECUNDARIO);
        descricao.setFont(new Font("SansSerif", Font.PLAIN, 13));
        cabecalho.add(titulo);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(descricao);

        abas = new JTabbedPane();
        abas.setOpaque(false);
        abas.setFont(new Font("SansSerif", Font.BOLD, 13));
        abas.setForeground(TEXTO);
        abas.setFocusable(false);
        abas.setUI(new BasicTabbedPaneUI() {
            @Override protected void installDefaults() {
                super.installDefaults();
                tabAreaInsets = new Insets(3, 4, 3, 4);
                contentBorderInsets = new Insets(0, 0, 0, 0);
            }
            @Override protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) { }
            @Override protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex,
                                                    int x, int y, int w, int h, boolean isSelected) { }
            @Override protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects,
                                                         int tabIndex, Rectangle iconRect,
                                                         Rectangle textRect, boolean isSelected) { }
            @Override protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex,
                                                        int x, int y, int w, int h, boolean isSelected) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isSelected ? new Color(65, 145, 210, 205) : new Color(12, 35, 65, 135));
                g2.fillRoundRect(x + 2, y + 2, w - 4, h - 4, 12, 12);
                g2.dispose();
            }
            @Override protected Insets getContentBorderInsets(int tabPlacement) {
                return new Insets(5, 3, 3, 3);
            }
        });
        abas.addTab("Minhas versões", montarAbaMinhasVersoes());
        abas.addTab("Instalar versões", montarAbaInstalarVersoes());
        abas.addTab("Modpacks", montarAbaModpacks());
        abas.addTab("Mods", montarAbaMods());

        JPanel areaAbas = new JPanel(new BorderLayout());
        areaAbas.setOpaque(false);
        areaAbas.setBorder(new EmptyBorder(0, 16, 16, 16));
        areaAbas.add(abas, BorderLayout.CENTER);

        add(cabecalho, BorderLayout.NORTH);
        add(areaAbas, BorderLayout.CENTER);
    }

    // ------------------------------------------------------- aba: Minhas versões

    private JPanel montarAbaMinhasVersoes() {
        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BorderLayout(0, 10));
        painel.setBorder(new EmptyBorder(14, 14, 14, 14));

        // topo: título + contagem | busca + atualizar
        JLabel titulo = new JLabel("Minhas instalações");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 16));
        contagem.setForeground(TEXTO_SECUNDARIO);
        contagem.setFont(new Font("SansSerif", Font.PLAIN, 12));
        JPanel textos = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        textos.setOpaque(false);
        textos.add(titulo);
        textos.add(contagem);

        JPanel busca = caixaDoCampo(buscaInstalacoes);
        busca.setPreferredSize(new Dimension(210, 30));
        buscaInstalacoes.getDocument().addDocumentListener(simples(this::filtrarInstalacoes));
        JButton atualizar = botao("Atualizar lista");
        atualizar.addActionListener(e -> aoAtualizar.run());
        JPanel direita = new JPanel(new BorderLayout(8, 0));
        direita.setOpaque(false);
        direita.add(busca, BorderLayout.CENTER);
        direita.add(atualizar, BorderLayout.EAST);

        JPanel topo = new JPanel(new BorderLayout(10, 0));
        topo.setOpaque(false);
        topo.add(textos, BorderLayout.WEST);
        topo.add(direita, BorderLayout.EAST);

        // centro: lista | detalhes
        listaInstalacoes.setOpaque(false);
        listaInstalacoes.setFixedCellHeight(58);
        listaInstalacoes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaInstalacoes.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        listaInstalacoes.setCellRenderer(new InstalacaoRenderer());
        listaInstalacoes.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            atualizarDetalhes();
            Instalacao sel = listaInstalacoes.getSelectedValue();
            if (sel != null) aoSelecionarInstalacao.accept(sel);
        });

        JLabel vazio = new JLabel("Suas instalações aparecerão aqui.", SwingConstants.CENTER);
        vazio.setForeground(TEXTO_SECUNDARIO);
        vazio.setFont(new Font("SansSerif", Font.PLAIN, 14));
        areaInstalacoes.setOpaque(false);
        areaInstalacoes.add(vazio, "vazio");
        areaInstalacoes.add(criarRolagem(listaInstalacoes), "lista");
        cartasInstalacoes.show(areaInstalacoes, "vazio");

        JPanel caixaLista = painelTranslucido(CAIXA, 14);
        caixaLista.setLayout(new BorderLayout());
        caixaLista.setBorder(new EmptyBorder(4, 4, 4, 4));
        caixaLista.add(areaInstalacoes, BorderLayout.CENTER);

        JPanel centro = new JPanel(new BorderLayout(12, 0));
        centro.setOpaque(false);
        centro.add(caixaLista, BorderLayout.CENTER);
        centro.add(montarDetalhes(), BorderLayout.EAST);

        painel.add(topo, BorderLayout.NORTH);
        painel.add(centro, BorderLayout.CENTER);
        return painel;
    }

    private JPanel montarDetalhes() {
        JPanel d = painelTranslucido(CAIXA, 14);
        d.setLayout(new BoxLayout(d, BoxLayout.Y_AXIS));
        d.setBorder(new EmptyBorder(12, 14, 12, 14));
        d.setPreferredSize(new Dimension(260, 100));

        JLabel t = new JLabel("Detalhes");
        t.setForeground(TEXTO);
        t.setFont(new Font("SansSerif", Font.BOLD, 14));
        t.setAlignmentX(LEFT_ALIGNMENT);
        d.add(t);
        d.add(Box.createVerticalStrut(8));
        d.add(linhaInfo("Nome", dNome));
        d.add(Box.createVerticalStrut(6));
        JPanel duas = new JPanel(new GridLayout(1, 2, 8, 0));
        duas.setOpaque(false);
        duas.add(linhaInfo("Versão", dVersao));
        duas.add(linhaInfo("Loader", dLoader));
        duas.setAlignmentX(LEFT_ALIGNMENT);
        duas.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        d.add(duas);
        d.add(Box.createVerticalStrut(6));
        JPanel duas2 = new JPanel(new GridLayout(1, 2, 8, 0));
        duas2.setOpaque(false);
        duas2.add(linhaInfo("Tipo", dTipo));
        duas2.add(linhaInfo("Tamanho", dTamanho));
        duas2.setAlignmentX(LEFT_ALIGNMENT);
        duas2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        d.add(duas2);
        d.add(Box.createVerticalStrut(6));
        d.add(linhaInfo("Último uso", dUltimoUso));
        d.add(Box.createVerticalStrut(6));
        d.add(linhaInfo("Pasta", dPasta));
        d.add(Box.createVerticalGlue());
        d.add(Box.createVerticalStrut(8));

        botaoAbrirPasta.addActionListener(e -> acao(aoAbrirPasta));
        botaoDuplicar.addActionListener(e -> acao(aoDuplicar));
        botaoRenomear.addActionListener(e -> acao(aoRenomear));
        botaoExcluir.addActionListener(e -> acao(aoExcluir));
        botaoExcluir.setBackground(PERIGO);
        botaoExcluir.putClientProperty("normal", PERIGO);
        botaoExcluir.putClientProperty("hover", PERIGO_HOVER);
        JPanel acoes = new JPanel(new GridLayout(2, 2, 6, 6));
        acoes.setOpaque(false);
        for (JButton b : new JButton[]{botaoAbrirPasta, botaoDuplicar, botaoRenomear, botaoExcluir}) {
            b.setFont(new Font("SansSerif", Font.BOLD, 11));
            b.setBorder(new EmptyBorder(6, 4, 6, 4));
            acoes.add(b);
        }
        acoes.setAlignmentX(LEFT_ALIGNMENT);
        acoes.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        d.add(acoes);
        return d;
    }

    private void acao(Consumer<Instalacao> c) {
        Instalacao i = listaInstalacoes.getSelectedValue();
        if (i != null) c.accept(i);
    }

    // ------------------------------------------------------ aba: Instalar versões

    private JPanel montarAbaInstalarVersoes() {
        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BorderLayout(12, 0));
        painel.setBorder(new EmptyBorder(14, 14, 14, 14));

        // ---- esquerda: filtros + lista de versões
        JPanel esquerda = new JPanel(new BorderLayout(0, 8));
        esquerda.setOpaque(false);

        JLabel titulo = new JLabel("Versões disponíveis");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 16));

        ButtonGroup grupoTipo = new ButtonGroup();
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        chips.setOpaque(false);
        for (int i = 0; i < TIPOS.length; i++) {
            chipsTipo[i] = chip(TIPOS[i]);
            grupoTipo.add(chipsTipo[i]);
            chipsTipo[i].addActionListener(e -> filtrarVersoes());
            chips.add(chipsTipo[i]);
        }
        chipsTipo[0].setSelected(true);

        JPanel busca = caixaDoCampo(buscaVersoes);
        busca.setPreferredSize(new Dimension(170, 28));
        buscaVersoes.getDocument().addDocumentListener(simples(this::filtrarVersoes));

        JPanel barra1 = new JPanel(new BorderLayout(8, 0));
        barra1.setOpaque(false);
        barra1.add(chips, BorderLayout.WEST);
        barra1.add(busca, BorderLayout.EAST);

        JPanel cabLista = new JPanel(new BorderLayout(0, 8));
        cabLista.setOpaque(false);
        cabLista.add(titulo, BorderLayout.NORTH);
        cabLista.add(barra1, BorderLayout.SOUTH);

        listaVersoes.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            atualizarPainelInstalar();
        });
        JPanel caixaLista = painelTranslucido(CAIXA, 14);
        caixaLista.setLayout(new BorderLayout());
        caixaLista.setBorder(new EmptyBorder(4, 4, 4, 4));
        caixaLista.add(criarRolagem(listaVersoes), BorderLayout.CENTER);

        esquerda.add(cabLista, BorderLayout.NORTH);
        esquerda.add(caixaLista, BorderLayout.CENTER);

        // ---- direita: painel de instalação
        JPanel dir = painelTranslucido(CAIXA, 14);
        dir.setLayout(new BoxLayout(dir, BoxLayout.Y_AXIS));
        dir.setBorder(new EmptyBorder(12, 14, 12, 14));
        dir.setPreferredSize(new Dimension(280, 100));

        JLabel t = new JLabel("Instalar");
        t.setForeground(TEXTO);
        t.setFont(new Font("SansSerif", Font.BOLD, 14));
        t.setAlignmentX(LEFT_ALIGNMENT);
        dir.add(t);
        dir.add(Box.createVerticalStrut(8));

        dir.add(rotulo("Versão selecionada"));
        dir.add(Box.createVerticalStrut(2));
        versaoEscolhida.setForeground(AZUL_CLARO);
        versaoEscolhida.setFont(new Font("SansSerif", Font.BOLD, 15));
        versaoEscolhida.setAlignmentX(LEFT_ALIGNMENT);
        dir.add(versaoEscolhida);
        dir.add(Box.createVerticalStrut(10));

        dir.add(rotulo("Nome da instalação"));
        dir.add(Box.createVerticalStrut(3));
        JPanel caixaNome = caixaDoCampo(campoNomeInstalacao);
        caixaNome.setAlignmentX(LEFT_ALIGNMENT);
        caixaNome.setPreferredSize(new Dimension(100, 30));
        caixaNome.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        dir.add(caixaNome);
        dir.add(Box.createVerticalStrut(10));

        dir.add(rotulo("Loader"));
        dir.add(Box.createVerticalStrut(3));
        ButtonGroup grupoLoader = new ButtonGroup();
        JPanel loaders = new JPanel(new GridLayout(2, 3, 6, 6));
        loaders.setOpaque(false);
        for (int i = 0; i < LOADERS.length; i++) {
            chipsLoader[i] = chip(LOADERS[i]);
            chipsLoader[i].setBorder(new EmptyBorder(5, 4, 5, 4));
            grupoLoader.add(chipsLoader[i]);
            loaders.add(chipsLoader[i]);
        }
        chipsLoader[0].setSelected(true);
        loaders.setAlignmentX(LEFT_ALIGNMENT);
        loaders.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));
        dir.add(loaders);
        dir.add(Box.createVerticalGlue());
        dir.add(Box.createVerticalStrut(8));

        statusInstalacao.setForeground(TEXTO_SECUNDARIO);
        statusInstalacao.setFont(new Font("SansSerif", Font.PLAIN, 12));
        statusInstalacao.setAlignmentX(LEFT_ALIGNMENT);
        dir.add(statusInstalacao);
        dir.add(Box.createVerticalStrut(6));
        barra.setAlignmentX(LEFT_ALIGNMENT);
        dir.add(barra);
        dir.add(Box.createVerticalStrut(10));

        botaoInstalar.setBackground(DESTAQUE);
        botaoInstalar.putClientProperty("normal", DESTAQUE);
        botaoInstalar.putClientProperty("hover", DESTAQUE_HOVER);
        botaoInstalar.setAlignmentX(LEFT_ALIGNMENT);
        botaoInstalar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        botaoInstalar.addActionListener(e -> {
            VersaoMc v = listaVersoes.getSelectedValue();
            if (v == null) return;
            String loader = LOADERS[0];
            for (int i = 0; i < chipsLoader.length; i++) if (chipsLoader[i].isSelected()) loader = LOADERS[i];
            aoInstalar.accept(new PedidoInstalacao(v.id, v.tipo, loader, campoNomeInstalacao.getText().trim()));
        });
        dir.add(botaoInstalar);

        painel.add(esquerda, BorderLayout.CENTER);
        painel.add(dir, BorderLayout.EAST);
        return painel;
    }


    // ----------------------------------------------------------- aba: Modpacks

    private JPanel montarAbaModpacks() {
        selecaoModpack.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaModpacks.setSelectionModel(selecaoModpack);
        listaInstancia.setSelectionModel(selecaoModpack);
        selecaoModpack.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            atualizarModpacks();
            Modpack sel = listaModpacks.getSelectedValue();
            if (sel != null) aoSelecionarModpack.accept(sel);
        });

        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BorderLayout(0, 10));
        painel.setBorder(new EmptyBorder(14, 14, 14, 14));

        JLabel titulo = new JLabel("Meus modpacks");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 16));
        contagemModpacks.setForeground(TEXTO_SECUNDARIO);
        contagemModpacks.setFont(new Font("SansSerif", Font.PLAIN, 12));
        JPanel textos = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        textos.setOpaque(false);
        textos.add(titulo);
        textos.add(contagemModpacks);
        JButton importar = botao("Importar modpack");
        importar.addActionListener(e -> aoImportarModpack.run());
        JPanel topo = new JPanel(new BorderLayout(10, 0));
        topo.setOpaque(false);
        topo.add(textos, BorderLayout.WEST);
        topo.add(importar, BorderLayout.EAST);

        listaModpacks.setOpaque(false);
        listaModpacks.setFixedCellHeight(58);
        listaModpacks.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        listaModpacks.setCellRenderer(new ModpackRenderer());

        JLabel vazio = new JLabel("<html><div style='text-align:center'>Seus modpacks aparecerão aqui.<br>"
                + "Crie o primeiro na aba Mods.</div></html>", SwingConstants.CENTER);
        vazio.setForeground(TEXTO_SECUNDARIO);
        vazio.setFont(new Font("SansSerif", Font.PLAIN, 14));
        areaModpacks.setOpaque(false);
        areaModpacks.add(vazio, "vazio");
        areaModpacks.add(criarRolagem(listaModpacks), "lista");
        cartasModpacks.show(areaModpacks, "vazio");

        JPanel caixaLista = painelTranslucido(CAIXA, 14);
        caixaLista.setLayout(new BorderLayout());
        caixaLista.setBorder(new EmptyBorder(4, 4, 4, 4));
        caixaLista.add(areaModpacks, BorderLayout.CENTER);

        JPanel centro = new JPanel(new BorderLayout(12, 0));
        centro.setOpaque(false);
        centro.add(caixaLista, BorderLayout.CENTER);
        centro.add(montarDetalhesModpack(), BorderLayout.EAST);

        painel.add(topo, BorderLayout.NORTH);
        painel.add(centro, BorderLayout.CENTER);
        return painel;
    }

    private JPanel montarDetalhesModpack() {
        JPanel d = painelTranslucido(CAIXA, 14);
        d.setLayout(new BoxLayout(d, BoxLayout.Y_AXIS));
        d.setBorder(new EmptyBorder(12, 14, 12, 14));
        d.setPreferredSize(new Dimension(260, 100));

        JLabel t = new JLabel("Detalhes");
        t.setForeground(TEXTO);
        t.setFont(new Font("SansSerif", Font.BOLD, 14));
        t.setAlignmentX(LEFT_ALIGNMENT);
        d.add(t);
        d.add(Box.createVerticalStrut(8));
        d.add(linhaInfo("Nome", pNome));
        d.add(Box.createVerticalStrut(6));
        JPanel duas = new JPanel(new GridLayout(1, 2, 8, 0));
        duas.setOpaque(false);
        duas.add(linhaInfo("Minecraft", pVersao));
        duas.add(linhaInfo("Loader", pLoader));
        duas.setAlignmentX(LEFT_ALIGNMENT);
        duas.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        d.add(duas);
        d.add(Box.createVerticalStrut(6));
        JPanel duas2 = new JPanel(new GridLayout(1, 2, 8, 0));
        duas2.setOpaque(false);
        duas2.add(linhaInfo("Mods", pMods));
        duas2.add(linhaInfo("Último uso", pUltimoUso));
        duas2.setAlignmentX(LEFT_ALIGNMENT);
        duas2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        d.add(duas2);
        d.add(Box.createVerticalStrut(6));
        d.add(linhaInfo("Pasta", pPasta));
        d.add(Box.createVerticalGlue());
        d.add(Box.createVerticalStrut(8));

        botaoPAbrir.addActionListener(e -> acaoModpack(aoAbrirPastaModpack));
        botaoPDuplicar.addActionListener(e -> acaoModpack(aoDuplicarModpack));
        botaoPRenomear.addActionListener(e -> acaoModpack(aoRenomearModpack));
        botaoPExcluir.addActionListener(e -> acaoModpack(aoExcluirModpack));
        botaoPExcluir.setBackground(PERIGO);
        botaoPExcluir.putClientProperty("normal", PERIGO);
        botaoPExcluir.putClientProperty("hover", PERIGO_HOVER);
        JPanel acoes = new JPanel(new GridLayout(2, 2, 6, 6));
        acoes.setOpaque(false);
        for (JButton b : new JButton[]{botaoPAbrir, botaoPDuplicar, botaoPRenomear, botaoPExcluir}) {
            b.setFont(new Font("SansSerif", Font.BOLD, 11));
            b.setBorder(new EmptyBorder(6, 4, 6, 4));
            acoes.add(b);
        }
        acoes.setAlignmentX(LEFT_ALIGNMENT);
        acoes.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        d.add(acoes);
        return d;
    }

    private void acaoModpack(Consumer<Modpack> c) {
        Modpack m = listaModpacks.getSelectedValue();
        if (m != null) c.accept(m);
    }

    // ---------------------------------------------------------------- aba: Mods

    private JPanel montarAbaMods() {
        JPanel painel = painelTranslucido(PAINEL, 20);
        painel.setLayout(new BorderLayout(12, 0));
        painel.setBorder(new EmptyBorder(14, 14, 14, 14));

        // ---- esquerda: instância (modpack) ou formulário de criar
        esquerdaMods.setOpaque(false);
        esquerdaMods.setPreferredSize(new Dimension(270, 100));
        esquerdaMods.add(montarEscolherInstancia(), "lista");
        esquerdaMods.add(montarCriarModpack(), "criar");
        cartasEsquerdaMods.show(esquerdaMods, "lista");

        // ---- direita: busca e lista de mods
        JPanel direita = new JPanel(new BorderLayout(0, 8));
        direita.setOpaque(false);

        tituloMods.setForeground(TEXTO);
        tituloMods.setFont(new Font("SansSerif", Font.BOLD, 16));
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(chipTodos);
        grupo.add(chipInstalados);
        chipTodos.setSelected(true);
        chipTodos.addActionListener(e -> filtrarMods());
        chipInstalados.addActionListener(e -> filtrarMods());
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        chips.setOpaque(false);
        chips.add(chipTodos);
        chips.add(chipInstalados);
        JPanel linha1 = new JPanel(new BorderLayout(8, 0));
        linha1.setOpaque(false);
        linha1.add(tituloMods, BorderLayout.WEST);
        linha1.add(chips, BorderLayout.EAST);

        JPanel busca = caixaDoCampo(buscaMods);
        busca.setPreferredSize(new Dimension(100, 30));
        JButton buscar = botao("Buscar");
        Runnable fazerBusca = () -> {
            Modpack m = listaInstancia.getSelectedValue();
            if (m != null) aoBuscarMods.accept(m, buscaMods.getText().trim());
        };
        buscar.addActionListener(e -> fazerBusca.run());
        buscaMods.addActionListener(e -> fazerBusca.run());
        JPanel linha2 = new JPanel(new BorderLayout(8, 0));
        linha2.setOpaque(false);
        linha2.add(busca, BorderLayout.CENTER);
        linha2.add(buscar, BorderLayout.EAST);

        JPanel cab = new JPanel(new BorderLayout(0, 8));
        cab.setOpaque(false);
        cab.add(linha1, BorderLayout.NORTH);
        cab.add(linha2, BorderLayout.SOUTH);

        listaMods.setOpaque(false);
        listaMods.setFixedCellHeight(58);
        listaMods.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaMods.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        listaMods.setCellRenderer(new ModRenderer());
        listaMods.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) atualizarBotoesMod();
        });
        JLabel vazio = new JLabel("Selecione ou crie um modpack para baixar mods.", SwingConstants.CENTER);
        vazio.setForeground(TEXTO_SECUNDARIO);
        vazio.setFont(new Font("SansSerif", Font.PLAIN, 14));
        areaMods.setOpaque(false);
        areaMods.add(vazio, "vazio");
        areaMods.add(criarRolagem(listaMods), "lista");
        cartasMods.show(areaMods, "vazio");
        JPanel caixaMods = painelTranslucido(CAIXA, 14);
        caixaMods.setLayout(new BorderLayout());
        caixaMods.setBorder(new EmptyBorder(4, 4, 4, 4));
        caixaMods.add(areaMods, BorderLayout.CENTER);

        // rodapé: status + progresso | Remover, Baixar
        statusMods.setForeground(TEXTO_SECUNDARIO);
        statusMods.setFont(new Font("SansSerif", Font.PLAIN, 12));
        JPanel estado = new JPanel(new BorderLayout(0, 4));
        estado.setOpaque(false);
        estado.add(statusMods, BorderLayout.CENTER);
        estado.add(barraMods, BorderLayout.SOUTH);
        botaoBaixarMod.setBackground(DESTAQUE);
        botaoBaixarMod.putClientProperty("normal", DESTAQUE);
        botaoBaixarMod.putClientProperty("hover", DESTAQUE_HOVER);
        botaoBaixarMod.addActionListener(e -> {
            Modpack m = listaInstancia.getSelectedValue();
            ModItem i = listaMods.getSelectedValue();
            if (m != null && i != null) aoBaixarMod.accept(m, i);
        });
        botaoRemoverMod.setBackground(PERIGO);
        botaoRemoverMod.putClientProperty("normal", PERIGO);
        botaoRemoverMod.putClientProperty("hover", PERIGO_HOVER);
        botaoRemoverMod.addActionListener(e -> {
            Modpack m = listaInstancia.getSelectedValue();
            ModItem i = listaMods.getSelectedValue();
            if (m != null && i != null) aoRemoverMod.accept(m, i);
        });
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botoes.setOpaque(false);
        botoes.add(botaoRemoverMod);
        botoes.add(botaoBaixarMod);
        JPanel rodape = new JPanel(new BorderLayout(12, 0));
        rodape.setOpaque(false);
        rodape.add(estado, BorderLayout.CENTER);
        rodape.add(botoes, BorderLayout.EAST);

        direita.add(cab, BorderLayout.NORTH);
        direita.add(caixaMods, BorderLayout.CENTER);
        direita.add(rodape, BorderLayout.SOUTH);

        painel.add(esquerdaMods, BorderLayout.WEST);
        painel.add(direita, BorderLayout.CENTER);
        return painel;
    }

    /** Lista de instâncias (modpacks) + botão para criar um modpack novo. */
    private JPanel montarEscolherInstancia() {
        JPanel p = painelTranslucido(CAIXA, 14);
        p.setLayout(new BorderLayout(0, 8));
        p.setBorder(new EmptyBorder(12, 12, 12, 12));

        JLabel t = new JLabel("Instância");
        t.setForeground(TEXTO);
        t.setFont(new Font("SansSerif", Font.BOLD, 14));
        JLabel dica = new JLabel("Escolha o modpack de destino.");
        dica.setForeground(TEXTO_SECUNDARIO);
        dica.setFont(new Font("SansSerif", Font.PLAIN, 11));
        JPanel cab = new JPanel(new BorderLayout(0, 2));
        cab.setOpaque(false);
        cab.add(t, BorderLayout.NORTH);
        cab.add(dica, BorderLayout.SOUTH);

        listaInstancia.setOpaque(false);
        listaInstancia.setFixedCellHeight(52);
        listaInstancia.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        listaInstancia.setCellRenderer(new ModpackRenderer());

        JPanel caixa = painelTranslucido(new Color(0, 0, 0, 60), 12);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(3, 3, 3, 3));
        caixa.add(criarRolagem(listaInstancia), BorderLayout.CENTER);

        JButton criar = botao("+ Criar modpack");
        criar.addActionListener(e -> {
            avisoCriacao.setText(" ");
            cartasEsquerdaMods.show(esquerdaMods, "criar");
            campoNomeModpack.requestFocusInWindow();
        });

        p.add(cab, BorderLayout.NORTH);
        p.add(caixa, BorderLayout.CENTER);
        p.add(criar, BorderLayout.SOUTH);
        return p;
    }

    /** Formulário de criação: nome, versão do Minecraft e loader. */
    private JPanel montarCriarModpack() {
        JPanel p = painelTranslucido(CAIXA, 14);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(new EmptyBorder(12, 12, 12, 12));

        JLabel t = new JLabel("Novo modpack");
        t.setForeground(TEXTO);
        t.setFont(new Font("SansSerif", Font.BOLD, 14));
        t.setAlignmentX(LEFT_ALIGNMENT);
        p.add(t);
        p.add(Box.createVerticalStrut(8));

        p.add(rotulo("Nome"));
        p.add(Box.createVerticalStrut(3));
        JPanel caixaNome = caixaDoCampo(campoNomeModpack);
        caixaNome.setAlignmentX(LEFT_ALIGNMENT);
        caixaNome.setPreferredSize(new Dimension(100, 30));
        caixaNome.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        p.add(caixaNome);
        p.add(Box.createVerticalStrut(8));

        p.add(rotulo("Versão do Minecraft"));
        p.add(Box.createVerticalStrut(3));
        listaVersoesModpack.setOpaque(false);
        listaVersoesModpack.setFixedCellHeight(28);
        listaVersoesModpack.setVisibleRowCount(4);
        listaVersoesModpack.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaVersoesModpack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        listaVersoesModpack.setCellRenderer(new VersaoLinhaRenderer());
        JPanel caixaVersoes = painelTranslucido(new Color(0, 0, 0, 60), 12);
        caixaVersoes.setLayout(new BorderLayout());
        caixaVersoes.setBorder(new EmptyBorder(3, 3, 3, 3));
        caixaVersoes.add(criarRolagem(listaVersoesModpack), BorderLayout.CENTER);
        caixaVersoes.setAlignmentX(LEFT_ALIGNMENT);
        caixaVersoes.setPreferredSize(new Dimension(100, 130));
        caixaVersoes.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        p.add(caixaVersoes);
        p.add(Box.createVerticalStrut(8));

        p.add(rotulo("Loader"));
        p.add(Box.createVerticalStrut(3));
        ButtonGroup grupo = new ButtonGroup();
        JPanel loaders = new JPanel(new GridLayout(1, chipsLoaderModpack.length, 4, 0));
        loaders.setOpaque(false);
        for (int i = 0; i < chipsLoaderModpack.length; i++) {
            chipsLoaderModpack[i] = chip(LOADERS[i + 1]);
            chipsLoaderModpack[i].setFont(new Font("SansSerif", Font.BOLD, 10));
            chipsLoaderModpack[i].setBorder(new EmptyBorder(5, 2, 5, 2));
            grupo.add(chipsLoaderModpack[i]);
            loaders.add(chipsLoaderModpack[i]);
        }
        chipsLoaderModpack[0].setSelected(true);
        loaders.setAlignmentX(LEFT_ALIGNMENT);
        loaders.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        p.add(loaders);
        p.add(Box.createVerticalGlue());

        avisoCriacao.setForeground(new Color(255, 160, 160));
        avisoCriacao.setFont(new Font("SansSerif", Font.PLAIN, 11));
        avisoCriacao.setAlignmentX(LEFT_ALIGNMENT);
        p.add(avisoCriacao);
        p.add(Box.createVerticalStrut(6));

        JButton cancelar = botao("Cancelar");
        cancelar.addActionListener(e -> cartasEsquerdaMods.show(esquerdaMods, "lista"));
        JButton criar = botao("Criar");
        criar.setBackground(DESTAQUE);
        criar.putClientProperty("normal", DESTAQUE);
        criar.putClientProperty("hover", DESTAQUE_HOVER);
        criar.addActionListener(e -> {
            String nome = campoNomeModpack.getText().trim();
            VersaoMc v = listaVersoesModpack.getSelectedValue();
            if (nome.isEmpty() || v == null) {
                avisoCriacao.setText("Dê um nome e escolha a versão.");
                return;
            }
            String loader = LOADERS[1];
            for (int i = 0; i < chipsLoaderModpack.length; i++) {
                if (chipsLoaderModpack[i].isSelected()) loader = LOADERS[i + 1];
            }
            aoCriarModpack.accept(new PedidoModpack(nome, v.id, loader));
            campoNomeModpack.setText("");
            listaVersoesModpack.clearSelection();
            cartasEsquerdaMods.show(esquerdaMods, "lista");
        });
        JPanel botoes = new JPanel(new GridLayout(1, 2, 6, 0));
        botoes.setOpaque(false);
        botoes.add(cancelar);
        botoes.add(criar);
        botoes.setAlignmentX(LEFT_ALIGNMENT);
        botoes.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        p.add(botoes);
        return p;
    }

    // ------------------------------------------------ estado das abas Modpacks/Mods

    private void atualizarModpacks() {
        Modpack m = listaModpacks.getSelectedValue();
        boolean tem = m != null;
        int total = modeloModpacks.size();
        contagemModpacks.setText(total == 0 ? " " : total + (total == 1 ? " modpack" : " modpacks"));
        cartasModpacks.show(areaModpacks, total == 0 ? "vazio" : "lista");
        pNome.setText(tem ? m.nome : "-");
        pVersao.setText(tem ? m.versaoMc : "-");
        pLoader.setText(tem ? m.loader : "-");
        pMods.setText(tem ? String.valueOf(m.qtdMods) : "-");
        pUltimoUso.setText(tem ? m.ultimoUso : "-");
        pPasta.setText(tem ? m.pasta : "-");
        pPasta.setToolTipText(tem ? m.pasta : null);
        for (JButton b : new JButton[]{botaoPAbrir, botaoPDuplicar, botaoPRenomear, botaoPExcluir}) {
            b.setEnabled(tem);
        }
        // aba Mods
        tituloMods.setText(tem ? "Mods para " + m.nome : "Mods");
        cartasMods.show(areaMods, tem ? "lista" : "vazio");
        statusMods.setText(tem ? m.versaoMc + " • " + m.loader + "  —  busque um mod e clique em Baixar."
                : "Selecione um modpack para baixar mods.");
        atualizarBotoesMod();
    }

    private void filtrarMods() {
        ModItem anterior = listaMods.getSelectedValue();
        modeloMods.clear();
        for (ModItem i : todosMods) {
            if (!chipInstalados.isSelected() || i.instalado) modeloMods.addElement(i);
        }
        if (anterior != null && modeloMods.contains(anterior)) listaMods.setSelectedValue(anterior, true);
        atualizarBotoesMod();
    }

    private void atualizarBotoesMod() {
        boolean tem = listaInstancia.getSelectedValue() != null;
        ModItem i = listaMods.getSelectedValue();
        botaoBaixarMod.setEnabled(tem && i != null && !i.instalado);
        botaoBaixarMod.setText(i != null && i.instalado ? "Instalado" : "Baixar");
        botaoRemoverMod.setEnabled(tem && i != null && i.instalado);
    }

    // ============================================================ Filtros e estado

    private void filtrarInstalacoes() {
        String termo = buscaInstalacoes.getText().trim().toLowerCase();
        Instalacao anterior = listaInstalacoes.getSelectedValue();
        modeloInstalacoes.clear();
        for (Instalacao i : todasInstalacoes) {
            if (termo.isEmpty() || i.nome.toLowerCase().contains(termo)
                    || i.versao.toLowerCase().contains(termo) || i.loader.toLowerCase().contains(termo)) {
                modeloInstalacoes.addElement(i);
            }
        }
        if (anterior != null && modeloInstalacoes.contains(anterior)) {
            listaInstalacoes.setSelectedValue(anterior, true);
        } else if (!modeloInstalacoes.isEmpty()) {
            listaInstalacoes.setSelectedIndex(0);
        }
        int total = todasInstalacoes.size();
        contagem.setText(total == 0 ? " " : total + (total == 1 ? " instalação" : " instalações"));
        cartasInstalacoes.show(areaInstalacoes, modeloInstalacoes.isEmpty() ? "vazio" : "lista");
        atualizarDetalhes();
    }

    private void filtrarVersoes() {
        String tipo = TIPOS[0];
        for (int i = 0; i < chipsTipo.length; i++) if (chipsTipo[i].isSelected()) tipo = TIPOS[i];
        String termo = buscaVersoes.getText().trim().toLowerCase();
        VersaoMc anterior = listaVersoes.getSelectedValue();
        modeloVersoes.clear();
        for (VersaoMc v : todasVersoes) {
            if (v.tipo.equalsIgnoreCase(tipo) && (termo.isEmpty() || v.id.toLowerCase().contains(termo))) {
                modeloVersoes.addElement(v);
            }
        }
        if (anterior != null && modeloVersoes.contains(anterior)) {
            listaVersoes.setSelectedValue(anterior, true);
        } else {
            listaVersoes.clearSelection();
        }
        listaVersoes.revalidate();   // a lista cresce se passar de MIN_LINHAS versões
        listaVersoes.repaint();
        atualizarPainelInstalar();
        modeloVersoesModpack.clear();
        for (VersaoMc v : todasVersoes) modeloVersoesModpack.addElement(v);
    }

    private void atualizarDetalhes() {
        Instalacao i = listaInstalacoes.getSelectedValue();
        boolean tem = i != null;
        dNome.setText(tem ? i.nome : "-");
        dVersao.setText(tem ? i.versao : "-");
        dLoader.setText(tem ? i.loader : "-");
        dTipo.setText(tem ? i.tipo : "-");
        dUltimoUso.setText(tem ? i.ultimoUso : "-");
        dTamanho.setText(tem ? i.tamanho : "-");
        dPasta.setText(tem ? i.pasta : "-");
        dPasta.setToolTipText(tem ? i.pasta : null);
        for (JButton b : new JButton[]{botaoAbrirPasta, botaoDuplicar, botaoRenomear, botaoExcluir}) {
            b.setEnabled(tem);
        }
    }

    private void atualizarPainelInstalar() {
        VersaoMc v = listaVersoes.getSelectedValue();
        botaoInstalar.setEnabled(v != null);
        if (v == null) {
            versaoEscolhida.setText("Nenhuma versão selecionada");
            statusInstalacao.setText("Selecione uma versão para continuar.");
        } else {
            versaoEscolhida.setText(v.id + "  (" + v.tipo + ")");
            statusInstalacao.setText(v.instalada ? "Esta versão já está instalada." : "Pronto para instalar.");
        }
    }

    // ================================================================ Renderers

    private static final Color[] CORES_LOADER = {
            new Color(74, 160, 90), new Color(178, 140, 80), new Color(200, 90, 60),
            new Color(225, 135, 45), new Color(150, 100, 200)
    };

    private static Color corDoLoader(String loader) {
        for (int i = 0; i < LOADERS.length; i++) if (LOADERS[i].equalsIgnoreCase(loader)) return CORES_LOADER[i];
        return new Color(90, 140, 200);
    }

    /** Linha de uma instalação: ícone do loader, nome, versão • loader • tipo e último uso. */
    private static class InstalacaoRenderer extends JComponent implements ListCellRenderer<Instalacao> {
        private Instalacao item;
        private boolean selecionado;

        @Override
        public Component getListCellRendererComponent(JList<? extends Instalacao> l, Instalacao v,
                                                      int i, boolean sel, boolean foco) {
            item = v;
            selecionado = sel;
            return this;
        }

        @Override public Dimension getPreferredSize() { return new Dimension(100, 58); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (selecionado) {
                g2.setColor(SELECAO);
                g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 12, 12);
            }
            if (item != null) {
                g2.setColor(corDoLoader(item.loader));
                g2.fillRoundRect(12, 11, 36, 36, 10, 10);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("SansSerif", Font.BOLD, 17));
                String letra = item.loader.isEmpty() ? "?" : item.loader.substring(0, 1).toUpperCase();
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(letra, 12 + (36 - fm.stringWidth(letra)) / 2, 11 + (36 - fm.getHeight()) / 2 + fm.getAscent());

                g2.setColor(TEXTO);
                g2.setFont(new Font("SansSerif", Font.BOLD, 13));
                g2.drawString(item.nome, 58, 26);
                g2.setColor(new Color(195, 225, 255, 190));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                g2.drawString(item.versao + "  •  " + item.loader + "  •  " + item.tipo, 58, 43);
                String uso = item.ultimoUso;
                g2.drawString(uso, getWidth() - 14 - g2.getFontMetrics().stringWidth(uso), 26);
            }
            g2.dispose();
        }
    }

    /** Linha de uma versão disponível: id, tipo • data e etiqueta "Instalada". */
    private static class VersaoRenderer extends JComponent implements ListCellRenderer<VersaoMc> {
        private VersaoMc item;
        private boolean selecionado;

        @Override
        public Component getListCellRendererComponent(JList<? extends VersaoMc> l, VersaoMc v,
                                                      int i, boolean sel, boolean foco) {
            item = v;
            selecionado = sel;
            return this;
        }

        @Override public Dimension getPreferredSize() { return new Dimension(100, 40); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (selecionado) {
                g2.setColor(SELECAO);
                g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 12, 12);
            }
            if (item != null) {
                g2.setColor(TEXTO);
                g2.setFont(new Font("SansSerif", Font.BOLD, 13));
                g2.drawString(item.id, 14, 17);
                g2.setColor(new Color(195, 225, 255, 170));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                g2.drawString(item.tipo + "  •  " + item.data, 14, 32);
                if (item.instalada) {
                    String s = "Instalada";
                    FontMetrics fm = g2.getFontMetrics();
                    int w = fm.stringWidth(s) + 16;
                    int x = getWidth() - 14 - w;
                    g2.setColor(new Color(120, 225, 160, 45));
                    g2.fillRoundRect(x, 10, w, 20, 12, 12);
                    g2.setColor(VERDE);
                    g2.drawRoundRect(x, 10, w, 20, 12, 12);
                    g2.drawString(s, x + 8, 24);
                }
            }
            g2.dispose();
        }
    }


    /** Linha de um modpack: cubo colorido, nome, "Minecraft • loader" e quantidade de mods. */
    private static class ModpackRenderer extends JComponent implements ListCellRenderer<Modpack> {
        private Modpack item;
        private boolean selecionado;

        @Override
        public Component getListCellRendererComponent(JList<? extends Modpack> l, Modpack v,
                                                      int i, boolean sel, boolean foco) {
            item = v;
            selecionado = sel;
            return this;
        }

        @Override public Dimension getPreferredSize() { return new Dimension(100, 52); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (selecionado) {
                g2.setColor(SELECAO);
                g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 12, 12);
            }
            if (item != null) {
                int h = getHeight();
                g2.setColor(corDoLoader(item.loader));
                g2.fillRoundRect(10, (h - 34) / 2, 34, 34, 10, 10);
                g2.setColor(new Color(255, 255, 255, 235));
                g2.setFont(new Font("SansSerif", Font.BOLD, 11));
                String q = String.valueOf(item.qtdMods);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(q, 10 + (34 - fm.stringWidth(q)) / 2, (h - 34) / 2 + 15);
                g2.setFont(new Font("SansSerif", Font.PLAIN, 9));
                fm = g2.getFontMetrics();
                g2.drawString("mods", 10 + (34 - fm.stringWidth("mods")) / 2, (h - 34) / 2 + 27);

                g2.setColor(TEXTO);
                g2.setFont(new Font("SansSerif", Font.BOLD, 13));
                g2.drawString(item.nome, 54, h / 2 - 3);
                g2.setColor(new Color(195, 225, 255, 190));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                g2.drawString(item.versaoMc + "  •  " + item.loader, 54, h / 2 + 13);
            }
            g2.dispose();
        }
    }

    /** Linha de um mod: ícone, nome, autor • downloads, descrição e etiqueta "Instalado". */
    private static class ModRenderer extends JComponent implements ListCellRenderer<ModItem> {
        private ModItem item;
        private boolean selecionado;

        @Override
        public Component getListCellRendererComponent(JList<? extends ModItem> l, ModItem v,
                                                      int i, boolean sel, boolean foco) {
            item = v;
            selecionado = sel;
            return this;
        }

        @Override public Dimension getPreferredSize() { return new Dimension(100, 58); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (selecionado) {
                g2.setColor(SELECAO);
                g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 12, 12);
            }
            if (item != null) {
                float hue = (Math.abs(item.nome.hashCode()) % 360) / 360f;
                g2.setColor(Color.getHSBColor(hue, 0.5f, 0.68f));
                g2.fillRoundRect(12, 11, 36, 36, 10, 10);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("SansSerif", Font.BOLD, 17));
                String letra = item.nome.isEmpty() ? "?" : item.nome.substring(0, 1).toUpperCase();
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(letra, 12 + (36 - fm.stringWidth(letra)) / 2, 11 + (36 - fm.getHeight()) / 2 + fm.getAscent());

                int direita = getWidth() - 14;
                if (item.instalado) {
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                    String s = "Instalado";
                    fm = g2.getFontMetrics();
                    int w = fm.stringWidth(s) + 16;
                    int x = getWidth() - 14 - w;
                    g2.setColor(new Color(120, 225, 160, 45));
                    g2.fillRoundRect(x, 8, w, 20, 12, 12);
                    g2.setColor(VERDE);
                    g2.drawRoundRect(x, 8, w, 20, 12, 12);
                    g2.drawString(s, x + 8, 22);
                    direita = x - 8;
                }
                g2.setColor(TEXTO);
                g2.setFont(new Font("SansSerif", Font.BOLD, 13));
                g2.drawString(item.nome, 58, 24);
                int larguraNome = g2.getFontMetrics().stringWidth(item.nome);
                g2.setColor(new Color(195, 225, 255, 170));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                String autor = "  por " + item.autor + "  •  " + item.downloads + " downloads";
                if (58 + larguraNome + g2.getFontMetrics().stringWidth(autor) <= direita) {
                    g2.drawString(autor, 58 + larguraNome, 24);
                }
                g2.setColor(new Color(195, 225, 255, 200));
                String desc = cortar(item.descricao, g2.getFontMetrics(), getWidth() - 58 - 14);
                g2.drawString(desc, 58, 43);
            }
            g2.dispose();
        }

        private static String cortar(String t, FontMetrics fm, int largura) {
            if (fm.stringWidth(t) <= largura) return t;
            String reticencias = "...";
            while (t.length() > 1 && fm.stringWidth(t + reticencias) > largura) t = t.substring(0, t.length() - 1);
            return t + reticencias;
        }
    }

    /** Linha simples de versão (usada no formulário de criar modpack). */
    private static class VersaoLinhaRenderer extends JComponent implements ListCellRenderer<VersaoMc> {
        private VersaoMc item;
        private boolean selecionado;

        @Override
        public Component getListCellRendererComponent(JList<? extends VersaoMc> l, VersaoMc v,
                                                      int i, boolean sel, boolean foco) {
            item = v;
            selecionado = sel;
            return this;
        }

        @Override public Dimension getPreferredSize() { return new Dimension(100, 28); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if (selecionado) {
                g2.setColor(SELECAO);
                g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 10, 10);
            }
            if (item != null) {
                g2.setColor(TEXTO);
                g2.setFont(new Font("SansSerif", Font.BOLD, 12));
                g2.drawString(item.id, 10, 19);
                g2.setColor(new Color(195, 225, 255, 150));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 10));
                String t = item.tipo;
                g2.drawString(t, getWidth() - 10 - g2.getFontMetrics().stringWidth(t), 19);
            }
            g2.dispose();
        }
    }

    /** Barra de progresso fina e arredondada (vazia quando valor < 0). */
    private static class Barra extends JComponent {
        private int valor = -1;

        Barra() {
            setPreferredSize(new Dimension(100, 8));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 8));
        }

        void setValor(int v) {
            valor = v;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(4, 14, 30, 200));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            if (valor >= 0) {
                g2.setColor(new Color(120, 195, 255));
                g2.fillRoundRect(0, 0, Math.min(getWidth(), getWidth() * valor / 100), getHeight(), 8, 8);
            }
            g2.dispose();
        }
    }

    // ===================================================================== Estilo

    private JList<VersaoMc> criarListaVersoes() {
        JList<VersaoMc> l = new JList<VersaoMc>(modeloVersoes) {
            @Override
            public Dimension getPreferredSize() {
                Dimension d = super.getPreferredSize();
                d.height = Math.max(getModel().getSize(), MIN_LINHAS) * 40;
                return d;
            }
        };
        l.setOpaque(false);
        l.setFixedCellHeight(40);
        l.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        l.setCellRenderer(new VersaoRenderer());
        return l;
    }

    private JScrollPane criarRolagem(JList<?> lista) {
        JScrollPane r = new JScrollPane(lista, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        r.setOpaque(false);
        r.getViewport().setOpaque(false);
        r.setBorder(BorderFactory.createEmptyBorder());
        r.getVerticalScrollBar().setUnitIncrement(40);
        JScrollBar barraV = r.getVerticalScrollBar();
        barraV.setOpaque(false);
        barraV.setPreferredSize(new Dimension(10, 0));
        barraV.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() { }
            @Override protected JButton createDecreaseButton(int o) { return vazioBtn(); }
            @Override protected JButton createIncreaseButton(int o) { return vazioBtn(); }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle rr) { }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle rr) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(150, 205, 255, 120));
                g2.fillRoundRect(rr.x + 2, rr.y, rr.width - 4, rr.height, 8, 8);
                g2.dispose();
            }
            private JButton vazioBtn() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });
        return r;
    }

    private JPanel painelTranslucido(Color fundo, int arco) {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(fundo);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);
                g2.setColor(BORDA);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        return p;
    }

    private JPanel caixaDoCampo(JTextField campo) {
        campo.setOpaque(false);
        campo.setBorder(BorderFactory.createEmptyBorder());
        campo.setForeground(TEXTO);
        campo.setCaretColor(TEXTO);
        campo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(4, 12, 4, 12));
        caixa.add(campo, BorderLayout.CENTER);
        return caixa;
    }

    private JTextField criarCampoBusca(String dica) { return criarCampoDica(dica); }

    private JTextField criarCampoDica(String dica) {
        return new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getText().isEmpty()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    g2.setColor(new Color(195, 225, 255, 110));
                    g2.setFont(getFont());
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(dica, getInsets().left, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
                    g2.dispose();
                }
            }
        };
    }

    private DocumentListener simples(Runnable r) {
        return new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { r.run(); }
            @Override public void removeUpdate(DocumentEvent e) { r.run(); }
            @Override public void changedUpdate(DocumentEvent e) { r.run(); }
        };
    }

    private JLabel rotulo(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(TEXTO_SECUNDARIO);
        l.setFont(new Font("SansSerif", Font.PLAIN, 11));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JLabel valor() {
        JLabel l = new JLabel("-");
        l.setForeground(TEXTO);
        l.setFont(new Font("SansSerif", Font.BOLD, 12));
        return l;
    }

    private JPanel linhaInfo(String rotulo, JLabel valor) {
        JLabel r = new JLabel(rotulo);
        r.setForeground(TEXTO_SECUNDARIO);
        r.setFont(new Font("SansSerif", Font.PLAIN, 11));
        JPanel p = new JPanel(new BorderLayout(0, 1));
        p.setOpaque(false);
        p.add(r, BorderLayout.NORTH);
        p.add(valor, BorderLayout.CENTER);
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        return p;
    }

    private JToggleButton chip(String texto) {
        JToggleButton b = new JToggleButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(5, 10, 5, 10));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean on = ((AbstractButton) c).isSelected();
                g2.setColor(on ? new Color(120, 195, 255, 55) : CAIXA);
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 14, 14);
                g2.setColor(on ? AZUL_CLARO : BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 14, 14);
                c.setForeground(on ? AZUL_CLARO : new Color(195, 225, 255, 150));
                g2.dispose();
                paint(g, c);
            }
        });
        return b;
    }

    private JButton botao(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setForeground(TEXTO);
        b.setBackground(BOTAO);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(7, 14, 7, 14));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color cor = c.getBackground();
                g2.setColor(c.isEnabled() ? cor : new Color(cor.getRed(), cor.getGreen(), cor.getBlue(), 90));
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 16, 16);
                g2.setColor(BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 16, 16);
                c.setForeground(c.isEnabled() ? TEXTO : new Color(240, 242, 247, 110));
                g2.dispose();
                paint(g, c);
            }
        });
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                Object h = b.getClientProperty("hover");
                b.setBackground(h instanceof Color ? (Color) h : BOTAO_HOVER);
            }
            @Override public void mouseExited(MouseEvent e) {
                Object n = b.getClientProperty("normal");
                b.setBackground(n instanceof Color ? (Color) n : BOTAO);
            }
        });
        return b;
    }
}