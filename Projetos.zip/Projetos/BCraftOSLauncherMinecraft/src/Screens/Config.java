package Screens;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicSliderUI;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Tela "Config": memória RAM e argumentos de execução.
 * Só o layout - salvar/ler configurações fica para depois (setOnSalvar etc.).
 */
public class Config extends JPanel {

    private static final Color PAINEL = new Color(12, 35, 65, 155);
    private static final Color CAIXA = new Color(4, 14, 30, 170);
    private static final Color BOTAO = new Color(25, 75, 125, 225);
    private static final Color BOTAO_HOVER = new Color(38, 105, 165, 240);
    private static final Color DESTAQUE = new Color(38, 105, 165, 235);
    private static final Color DESTAQUE_HOVER = new Color(83, 165, 235, 240);
    private static final Color TEXTO = new Color(240, 242, 247);
    private static final Color TEXTO_SECUNDARIO = new Color(195, 225, 255);
    private static final Color AZUL_CLARO = new Color(120, 195, 255);
    private static final Color BORDA = new Color(255, 255, 255, 35);
    private static final Color BORDA_BOTAO = new Color(150, 205, 255, 90);

    private final JSlider sliderRam = new JSlider(1024, 8192, 4096);
    private final JLabel valorRam = new JLabel();
    private final JTextArea campoArgumentos = new JTextArea();
    private final JLabel status = new JLabel(" ");
    private Runnable aoSalvar = () -> { };
    private Runnable aoRestaurar = () -> { };

    public Config() {
        setLayout(new BorderLayout());
        setOpaque(false);
        montarInterface();
    }

    // ---------------------------------------------------------------- API

    public int getRamMb() { return sliderRam.getValue(); }
    public void setRamMb(int mb) { sliderRam.setValue(mb); }
    /** Limite do slider (RAM disponível na máquina). */
    public void setRamMaxMb(int mb) { sliderRam.setMaximum(Math.max(2048, mb)); }
    public String getArgumentos() { return campoArgumentos.getText().trim(); }
    public void setArgumentos(String a) { campoArgumentos.setText(a); }
    public void setStatus(String texto) { status.setText(texto); }

    public void setOnSalvar(Runnable r) { aoSalvar = r == null ? () -> { } : r; }
    public void setOnRestaurar(Runnable r) { aoRestaurar = r == null ? () -> { } : r; }

    // ------------------------------------------------------------- Layout

    private void montarInterface() {
        JPanel raiz = new JPanel(new BorderLayout(12, 12));
        raiz.setOpaque(false);
        raiz.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Config");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel subtitulo = new JLabel("Defina a memória RAM e os argumentos de execução do jogo.");
        subtitulo.setForeground(TEXTO_SECUNDARIO);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel cabecalho = new JPanel();
        cabecalho.setOpaque(false);
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.add(titulo);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(subtitulo);

        JPanel cartao = painelTranslucido(PAINEL, 20);
        cartao.setLayout(new BoxLayout(cartao, BoxLayout.Y_AXIS));
        cartao.setBorder(new EmptyBorder(14, 22, 14, 22));
        cartao.setPreferredSize(new Dimension(560, 232));
        cartao.setMinimumSize(new Dimension(400, 220));

        // Memória RAM
        cartao.add(linhaRotulo("Memória RAM", valorRam));
        cartao.add(Box.createVerticalStrut(2));
        estilizarSlider();
        sliderRam.setAlignmentX(LEFT_ALIGNMENT);
        sliderRam.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
        cartao.add(sliderRam);
        cartao.add(Box.createVerticalStrut(10));

        // Argumentos da JVM
        cartao.add(rotulo("Argumentos"));
        cartao.add(Box.createVerticalStrut(3));
        cartao.add(caixaArgumentos());
        cartao.add(Box.createVerticalStrut(12));

        // Rodapé: status + botões
        status.setForeground(TEXTO_SECUNDARIO);
        status.setFont(new Font("SansSerif", Font.PLAIN, 12));
        JButton restaurar = botao("Restaurar padrão");
        restaurar.addActionListener(e -> aoRestaurar.run());
        JButton salvar = botao("Salvar");
        salvar.setBackground(DESTAQUE);
        salvar.putClientProperty("normal", DESTAQUE);
        salvar.putClientProperty("hover", DESTAQUE_HOVER);
        salvar.addActionListener(e -> aoSalvar.run());

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botoes.setOpaque(false);
        botoes.add(restaurar);
        botoes.add(salvar);
        JPanel rodape = new JPanel(new BorderLayout(8, 0));
        rodape.setOpaque(false);
        rodape.add(status, BorderLayout.CENTER);
        rodape.add(botoes, BorderLayout.EAST);
        rodape.setAlignmentX(LEFT_ALIGNMENT);
        rodape.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        cartao.add(rodape);

        JPanel centro = new JPanel(new GridBagLayout());
        centro.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.NORTH;
        c.weightx = 1;
        c.weighty = 1;
        centro.add(cartao, c);

        raiz.add(cabecalho, BorderLayout.NORTH);
        raiz.add(centro, BorderLayout.CENTER);
        add(raiz, BorderLayout.CENTER);

        atualizarValorRam();
        sliderRam.addChangeListener(e -> atualizarValorRam());
    }

    private void atualizarValorRam() {
        int mb = sliderRam.getValue();
        valorRam.setText(mb + " MB  (" + String.format("%.1f", mb / 1024.0) + " GB)");
    }

    private JLabel rotulo(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(TEXTO_SECUNDARIO);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JPanel linhaRotulo(String texto, JLabel direita) {
        direita.setForeground(AZUL_CLARO);
        direita.setFont(new Font("SansSerif", Font.BOLD, 12));
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        JLabel l = new JLabel(texto);
        l.setForeground(TEXTO_SECUNDARIO);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        p.add(l, BorderLayout.WEST);
        p.add(direita, BorderLayout.EAST);
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 18));
        return p;
    }

    /** Área de texto arredondada (3 linhas) com dica quando vazia. */
    private JComponent caixaArgumentos() {
        final String dica = "-XX:+UseG1GC -Dfile.encoding=UTF-8";
        JTextArea t = campoArgumentos;
        t.setOpaque(false);
        t.setLineWrap(true);
        t.setWrapStyleWord(true);
        t.setRows(3);
        t.setBorder(BorderFactory.createEmptyBorder());
        t.setForeground(TEXTO);
        t.setCaretColor(TEXTO);
        t.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(8, 12, 8, 12));
        caixa.add(t, BorderLayout.CENTER);
        // Dica por cima do texto quando o campo está vazio.
        JLabel hint = new JLabel(dica);
        hint.setForeground(new Color(195, 225, 255, 110));
        hint.setFont(t.getFont());
        hint.setVerticalAlignment(SwingConstants.TOP);
        t.setLayout(new BorderLayout());
        t.add(hint, BorderLayout.CENTER);
        t.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            void atualizar() { hint.setVisible(t.getText().isEmpty()); }
            @Override public void insertUpdate(javax.swing.event.DocumentEvent e) { atualizar(); }
            @Override public void removeUpdate(javax.swing.event.DocumentEvent e) { atualizar(); }
            @Override public void changedUpdate(javax.swing.event.DocumentEvent e) { atualizar(); }
        });
        caixa.setAlignmentX(LEFT_ALIGNMENT);
        caixa.setPreferredSize(new Dimension(100, 76));
        caixa.setMaximumSize(new Dimension(Integer.MAX_VALUE, 76));
        return caixa;
    }

    // ---------------------------------------------------------- Estilo

    private JPanel painelTranslucido(Color fundo, int arco) {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(fundo);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);
                g2.setColor(BORDA);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        return p;
    }

    private JButton botao(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setForeground(TEXTO);
        b.setBackground(BOTAO);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(6, 12, 6, 12));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(c.getBackground());
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 16, 16);
                g2.setColor(BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 16, 16);
                g2.dispose();
                paint(g, c);
            }
        });
        b.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                Object h = b.getClientProperty("hover");
                b.setBackground(h instanceof Color ? (Color) h : BOTAO_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                Object n = b.getClientProperty("normal");
                b.setBackground(n instanceof Color ? (Color) n : BOTAO);
            }
        });
        return b;
    }

    private void estilizarSlider() {
        sliderRam.setOpaque(false);
        sliderRam.setFocusable(false);
        sliderRam.setMinorTickSpacing(256);
        sliderRam.setSnapToTicks(true);
        sliderRam.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        sliderRam.setUI(new BasicSliderUI(sliderRam) {
            @Override protected Dimension getThumbSize() { return new Dimension(18, 18); }
            @Override public void paintFocus(Graphics g) { }
            @Override public void paintTicks(Graphics g) { }
            @Override public void paintLabels(Graphics g) { }
            @Override
            public void paintTrack(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int y = trackRect.y + trackRect.height / 2 - 3;
                g2.setColor(CAIXA);
                g2.fillRoundRect(trackRect.x, y, trackRect.width, 6, 6, 6);
                g2.setColor(AZUL_CLARO);
                int ate = thumbRect.x + thumbRect.width / 2 - trackRect.x;
                g2.fillRoundRect(trackRect.x, y, Math.max(0, ate), 6, 6, 6);
                g2.dispose();
            }
            @Override
            public void paintThumb(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(235, 245, 255));
                g2.fillOval(thumbRect.x, thumbRect.y, thumbRect.width - 1, thumbRect.height - 1);
                g2.setColor(BORDA_BOTAO);
                g2.drawOval(thumbRect.x, thumbRect.y, thumbRect.width - 1, thumbRect.height - 1);
                g2.dispose();
            }
        });
    }
}