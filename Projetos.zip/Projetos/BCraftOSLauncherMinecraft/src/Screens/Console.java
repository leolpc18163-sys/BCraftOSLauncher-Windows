package Screens;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.text.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Tela "Console": saída do servidor + campo de comandos.
 * Mesmo estilo visual de Servidores (azul, semitransparente, cantos redondos).
 */
public class Console extends JPanel {

    private static final Color PAINEL = new Color(12, 35, 65, 155);
    private static final Color CAIXA = new Color(4, 14, 30, 170);
    private static final Color BOTAO = new Color(25, 75, 125, 225);
    private static final Color BOTAO_HOVER = new Color(38, 105, 165, 240);
    private static final Color TEXTO = new Color(240, 242, 247);
    private static final Color TEXTO_SECUNDARIO = new Color(195, 225, 255);
    private static final Color BORDA = new Color(255, 255, 255, 35);
    private static final Color BORDA_BOTAO = new Color(150, 205, 255, 90);
    private static final Color LIGADO = new Color(120, 225, 160);
    private static final Color DESLIGADO = new Color(235, 125, 125);

    private final JComboBox<String> comboServidor = new JComboBox<>();
    private final JLabel estado = new JLabel();
    private final JCheckBox rolagemAuto = new JCheckBox("Rolagem automática", true);
    private final JTextPane saida = new JTextPane();
    private final JTextField campoComando = new JTextField();
    private final List<String> historico = new ArrayList<>();
    private int posHistorico = 0;
    private Consumer<String> aoEnviarComando = c -> { };

    public Console() {
        setLayout(new BorderLayout());
        setOpaque(false);
        montarInterface();
        setEstado(false);
    }

    // ---------------------------------------------------------------- API

    public void setServidores(List<String> nomes) {
        comboServidor.removeAllItems();
        for (String n : nomes) comboServidor.addItem(n);
    }

    public String getServidorSelecionado() {
        return (String) comboServidor.getSelectedItem();
    }

    public void setEstado(boolean ligado) {
        estado.setText(ligado ? "●  Ligado" : "●  Desligado");
        estado.setForeground(ligado ? LIGADO : DESLIGADO);
    }

    public void setOnComando(Consumer<String> consumidor) {
        this.aoEnviarComando = consumidor == null ? c -> { } : consumidor;
    }

    public void limpar() {
        saida.setText("");
    }

    /** Pode ser chamado de qualquer thread. */
    public void adicionarLinha(String linha) {
        SwingUtilities.invokeLater(() -> {
            StyledDocument doc = saida.getStyledDocument();
            try {
                doc.insertString(doc.getLength(), linha + "\n", estiloDa(linha));
            } catch (BadLocationException ignorado) {
                // não acontece: sempre inserimos no fim
            }
            if (rolagemAuto.isSelected()) {
                saida.setCaretPosition(doc.getLength());
            }
        });
    }

    // ------------------------------------------------------------- Layout

    private void montarInterface() {
        JPanel raiz = new JPanel(new BorderLayout(12, 12));
        raiz.setOpaque(false);
        raiz.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Console");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel subtitulo = new JLabel("Acompanhe a saída do servidor e envie comandos.");
        subtitulo.setForeground(TEXTO_SECUNDARIO);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel cabecalho = new JPanel();
        cabecalho.setOpaque(false);
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.add(titulo);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(subtitulo);

        JPanel cartao = painelTranslucido(PAINEL, 20);
        cartao.setLayout(new BorderLayout(0, 8));
        cartao.setBorder(new EmptyBorder(10, 10, 10, 10));
        cartao.add(montarBarraSuperior(), BorderLayout.NORTH);
        cartao.add(montarSaida(), BorderLayout.CENTER);
        cartao.add(montarLinhaComando(), BorderLayout.SOUTH);

        raiz.add(cabecalho, BorderLayout.NORTH);
        raiz.add(cartao, BorderLayout.CENTER);
        add(raiz, BorderLayout.CENTER);
    }

    private JPanel montarBarraSuperior() {
        JPanel barra = new JPanel(new BorderLayout(10, 0));
        barra.setOpaque(false);

        JLabel rotulo = new JLabel("Servidor");
        rotulo.setForeground(TEXTO_SECUNDARIO);
        rotulo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        estilizarCombo(comboServidor);
        estado.setFont(new Font("SansSerif", Font.BOLD, 12));

        JPanel esquerda = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        esquerda.setOpaque(false);
        esquerda.add(rotulo);
        esquerda.add(comboServidor);
        esquerda.add(estado);

        rolagemAuto.setOpaque(false);
        rolagemAuto.setFocusPainted(false);
        rolagemAuto.setForeground(TEXTO_SECUNDARIO);
        rolagemAuto.setFont(new Font("SansSerif", Font.PLAIN, 12));

        JButton copiar = botao("Copiar");
        copiar.addActionListener(e -> Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new StringSelection(saida.getText()), null));
        JButton limpar = botao("Limpar");
        limpar.addActionListener(e -> limpar());

        JPanel direita = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        direita.setOpaque(false);
        direita.add(rolagemAuto);
        direita.add(copiar);
        direita.add(limpar);

        barra.add(esquerda, BorderLayout.WEST);
        barra.add(direita, BorderLayout.EAST);
        return barra;
    }

    private JComponent montarSaida() {
        saida.setEditable(false);
        saida.setOpaque(false);
        saida.setForeground(TEXTO);
        saida.setCaretColor(TEXTO);
        saida.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        saida.setBorder(new EmptyBorder(8, 10, 8, 10));

        JScrollPane rolagem = new JScrollPane(saida,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        rolagem.setOpaque(false);
        rolagem.getViewport().setOpaque(false);
        rolagem.setBorder(BorderFactory.createEmptyBorder());
        JScrollBar barra = rolagem.getVerticalScrollBar();
        barra.setOpaque(false);
        barra.setPreferredSize(new Dimension(10, 0));
        barra.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() { }
            @Override protected JButton createDecreaseButton(int o) { return vazio(); }
            @Override protected JButton createIncreaseButton(int o) { return vazio(); }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(150, 205, 255, 120));
                g2.fillRoundRect(r.x + 2, r.y, r.width - 4, r.height, 8, 8);
                g2.dispose();
            }
            private JButton vazio() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });

        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(2, 2, 2, 2));
        caixa.add(rolagem, BorderLayout.CENTER);
        return caixa;
    }

    private JPanel montarLinhaComando() {
        JLabel prompt = new JLabel("›");
        prompt.setForeground(TEXTO_SECUNDARIO);
        prompt.setFont(new Font(Font.MONOSPACED, Font.BOLD, 16));

        campoComando.setOpaque(false);
        campoComando.setBorder(BorderFactory.createEmptyBorder());
        campoComando.setForeground(TEXTO);
        campoComando.setCaretColor(TEXTO);
        campoComando.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        campoComando.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP && posHistorico > 0) {
                    campoComando.setText(historico.get(--posHistorico));
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    if (posHistorico < historico.size() - 1) {
                        campoComando.setText(historico.get(++posHistorico));
                    } else {
                        posHistorico = historico.size();
                        campoComando.setText("");
                    }
                }
            }
        });

        JPanel campo = painelTranslucido(CAIXA, 14);
        campo.setLayout(new BorderLayout(8, 0));
        campo.setBorder(new EmptyBorder(6, 12, 6, 12));
        campo.add(prompt, BorderLayout.WEST);
        campo.add(campoComando, BorderLayout.CENTER);

        JButton enviar = botao("Enviar");
        enviar.addActionListener(e -> enviarComando());
        campoComando.addActionListener(e -> enviarComando());

        JPanel linha = new JPanel(new BorderLayout(8, 0));
        linha.setOpaque(false);
        linha.add(campo, BorderLayout.CENTER);
        linha.add(enviar, BorderLayout.EAST);
        return linha;
    }

    // --------------------------------------------------------- Comandos

    private void enviarComando() {
        String comando = campoComando.getText().trim();
        if (comando.isEmpty()) return;
        historico.add(comando);
        posHistorico = historico.size();
        campoComando.setText("");
        adicionarLinha("> " + comando);
        aoEnviarComando.accept(comando);
    }

    // ------------------------------------------------- Cores por nível

    private AttributeSet estiloDa(String linha) {
        SimpleAttributeSet a = new SimpleAttributeSet();
        Color cor = TEXTO;
        if (linha.startsWith(">")) cor = new Color(150, 205, 255);
        else if (linha.contains("ERROR") || linha.contains("Exception")) cor = new Color(255, 135, 135);
        else if (linha.contains("WARN")) cor = new Color(255, 205, 110);
        else if (linha.contains("Done") || linha.contains("joined the game")) cor = LIGADO;
        StyleConstants.setForeground(a, cor);
        return a;
    }

    // ---------------------------------------------------------- Estilo

    private JPanel painelTranslucido(Color fundo, int arco) {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(fundo);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);
                g2.setColor(BORDA);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        return p;
    }

    private JButton botao(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setForeground(TEXTO);
        b.setBackground(BOTAO);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(6, 12, 6, 12));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(c.getBackground());
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 16, 16);
                g2.setColor(BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 16, 16);
                g2.dispose();
                paint(g, c);
            }
        });
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(BOTAO_HOVER); }
            @Override public void mouseExited(MouseEvent e) { b.setBackground(BOTAO); }
        });
        return b;
    }

    private void estilizarCombo(JComboBox<String> combo) {
        combo.setPreferredSize(new Dimension(190, 28));
        combo.setForeground(TEXTO);
        combo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        combo.setOpaque(false);
        combo.setBackground(new Color(0, 0, 0, 0));
        combo.setFocusable(false);
        combo.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton seta = new JButton("▾");
                seta.setOpaque(false);
                seta.setContentAreaFilled(false);
                seta.setBorder(new EmptyBorder(0, 4, 0, 8));
                seta.setForeground(TEXTO_SECUNDARIO);
                seta.setFocusable(false);
                return seta;
            }
            @Override public void paintCurrentValueBackground(Graphics g, Rectangle r, boolean f) { }
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CAIXA);
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 14, 14);
                g2.setColor(BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 14, 14);
                g2.dispose();
                super.paint(g, c);
            }
        });
        combo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean sel, boolean f) {
                JLabel lb = (JLabel) super.getListCellRendererComponent(l, v, i, sel, f);
                lb.setForeground(TEXTO);
                lb.setBackground(sel ? new Color(38, 105, 165) : new Color(12, 35, 65));
                lb.setBorder(new EmptyBorder(4, 10, 4, 10));
                return lb;
            }
        });
    }
}