package Screens;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/**
 * Tela de login com várias contas.
 *  - "Suas contas": escolhe uma conta salva e digita a senha (sempre pedida).
 *  - "Adicionar conta": aba Microsoft ou Pirata, com a senha do launcher para a conta nova.
 * Só o layout - quem faz o login de verdade é o Core.Login (ligado pela Base com os setOnX).
 */
public class Login extends JPanel {

    private static final Color PAINEL = new Color(12, 35, 65, 155);
    private static final Color CAIXA = new Color(4, 14, 30, 170);
    private static final Color DESTAQUE = new Color(38, 105, 165, 235);
    private static final Color DESTAQUE_HOVER = new Color(83, 165, 235, 240);
    private static final Color ABA_INATIVA = new Color(4, 14, 30, 150);
    private static final Color ABA_INATIVA_HOVER = new Color(38, 105, 165, 150);
    private static final Color DESATIVADO = new Color(60, 75, 95, 170);
    private static final Color TEXTO = new Color(240, 242, 247);
    private static final Color TEXTO_SECUNDARIO = new Color(195, 225, 255);
    private static final Color TEXTO_DESATIVADO = new Color(215, 228, 245, 150);
    private static final Color ERRO = new Color(255, 150, 150);
    private static final Color BORDA = new Color(255, 255, 255, 35);
    private static final Color BORDA_BOTAO = new Color(150, 205, 255, 90);

    private static final String TELA_CONTAS = "contas";
    private static final String TELA_ADICIONAR = "adicionar";
    private static final String MODO_MICROSOFT = "microsoft";
    private static final String MODO_PIRATA = "pirata";
    private static final String ACAO_NADA = "nada";
    private static final String ACAO_VOLTAR = "voltar";
    private static final String ACAO_CANCELAR = "cancelar";

    private static final int ALTURA_LINHA = 30;
    private static final int LINHAS_VISIVEIS = 4;

    /** Conta para mostrar na lista (a Base converte do Core, a tela não depende dele). */
    public static final class ContaItem {
        public final String id;
        public final String nome;
        public final String tipo;

        public ContaItem(String id, String nome, String tipo) {
            this.id = id;
            this.nome = nome;
            this.tipo = tipo;
        }

        @Override public String toString() { return nome; }
    }

    @FunctionalInterface public interface AoEntrar { void entrar(String idConta, char[] senha); }
    @FunctionalInterface public interface AoAdicionarPirata { void adicionar(String nome, char[] senha, char[] confirmacao); }
    @FunctionalInterface public interface AoAdicionarMicrosoft { void adicionar(char[] senha, char[] confirmacao); }

    // estrutura
    private final CardLayout telas = new CardLayout();
    private final JPanel areaTelas = new JPanel(telas);
    private final CardLayout acaoInferior = new CardLayout();
    private final JPanel areaAcao = new JPanel(acaoInferior);

    // tela "Suas contas"
    private final DefaultListModel<ContaItem> modeloContas = new DefaultListModel<>();
    private final JList<ContaItem> listaContas = criarLista();
    private final JPasswordField campoSenhaEntrar = criarCampoSenha("Senha desta conta");
    private final JButton botaoEntrar = new JButton("Entrar");
    private final JButton botaoNovaConta = new JButton("+ Adicionar conta");
    private final JButton botaoRemover = new JButton("Remover conta");

    // tela "Adicionar conta"
    private final CardLayout modos = new CardLayout();
    private final JPanel areaModos = new JPanel(modos);
    private final JButton abaMicrosoft = new JButton("Conta Microsoft");
    private final JButton abaPirata = new JButton("Conta Pirata");
    private final JTextField campoNome = criarCampoDica("Nome de jogador (3 a 16: letras, números e _)");
    private final JPasswordField campoSenhaNova = criarCampoSenha("Crie uma senha para esta conta");
    private final JPasswordField campoSenhaConfirma = criarCampoSenha("Repita a senha");
    private final JButton botaoAdicionar = new JButton("Entrar com Microsoft");

    // código da Microsoft (aparece no lugar das telas)
    private final JPanel caixaCodigo = painelTranslucido(CAIXA, 14);
    private final JLabel rotuloCodigo = new JLabel(" ");
    private final JLabel rotuloUrl = new JLabel(" ");
    private final JButton botaoAbrirPagina = new JButton("Abrir página");
    private final JButton botaoCopiar = new JButton("Copiar código");

    // parte de baixo
    private final JTextArea status = new JTextArea();
    private final JButton botaoVoltar = new JButton("← Voltar para as contas");
    private final JButton botaoCancelar = new JButton("Cancelar");

    private boolean modoMicrosoft = true;
    private boolean ocupado = false;
    private boolean naTelaAdicionar = false;

    private AoEntrar aoEntrar = (id, senha) -> { };
    private AoAdicionarPirata aoAdicionarPirata = (n, s, c) -> { };
    private AoAdicionarMicrosoft aoAdicionarMicrosoft = (s, c) -> { };
    private Consumer<String> aoRemover = id -> { };
    private Runnable aoCancelar = () -> { };
    private Consumer<String> aoAbrirPagina = url -> { };

    public Login() {
        setLayout(new BorderLayout());
        setOpaque(false);
        montarInterface();
        ligarEventos();
        selecionarModo(true);
        caixaCodigo.setVisible(false);
        mostrarAdicionar();
    }

    // ---------------------------------------------------------------- API

    /** Atualiza a lista de contas salvas e deixa selecionada a do id dado (a senha continua sendo pedida). */
    public void setContas(List<ContaItem> contas, String idSelecionado) {
        modeloContas.clear();
        int sel = 0;
        for (int i = 0; i < contas.size(); i++) {
            modeloContas.addElement(contas.get(i));
            if (contas.get(i).id.equals(idSelecionado)) sel = i;
        }
        if (!modeloContas.isEmpty()) listaContas.setSelectedIndex(sel);
        if (modeloContas.isEmpty()) mostrarAdicionar();
        atualizarEstado();
    }

    /** Mostra "Suas contas" (ou "Adicionar conta" se ainda não há nenhuma). */
    public void mostrarContas() {
        if (modeloContas.isEmpty()) {
            mostrarAdicionar();
            return;
        }
        naTelaAdicionar = false;
        telas.show(areaTelas, TELA_CONTAS);
        limparSenhas();
        escreverStatus(" ", TEXTO_SECUNDARIO);
        atualizarEstado();
        SwingUtilities.invokeLater(campoSenhaEntrar::requestFocusInWindow);
    }

    public void mostrarAdicionar() {
        naTelaAdicionar = true;
        telas.show(areaTelas, TELA_ADICIONAR);
        limparSenhas();
        campoNome.setText("");
        escreverStatus(" ", TEXTO_SECUNDARIO);
        atualizarEstado();
    }

    /** Apaga o que foi digitado nos campos de senha. */
    public void limparSenhas() {
        campoSenhaEntrar.setText("");
        campoSenhaNova.setText("");
        campoSenhaConfirma.setText("");
    }

    /** Mensagem normal (progresso). */
    public void setStatus(String texto) { escreverStatus(texto, TEXTO_SECUNDARIO); }

    /** Mensagem de erro (vermelha). */
    public void setErro(String texto) { escreverStatus(texto, ERRO); }

    /** Mostra o código que o jogador precisa digitar na página da Microsoft (no lugar do formulário). */
    public void mostrarCodigo(String codigo, String url) {
        rotuloCodigo.setText(codigo);
        rotuloUrl.setText(url);
        areaTelas.setVisible(false);
        caixaCodigo.setVisible(true);
        revalidate();
        repaint();
    }

    public void esconderCodigo() {
        caixaCodigo.setVisible(false);
        areaTelas.setVisible(true);
        revalidate();
        repaint();
    }

    /** Enquanto ocupado: tudo trava e o botão Cancelar aparece. */
    public void setOcupado(boolean valor) {
        this.ocupado = valor;
        atualizarEstado();
    }

    public void setOnEntrarConta(AoEntrar a) { aoEntrar = a == null ? (id, s) -> { } : a; }
    public void setOnAdicionarPirata(AoAdicionarPirata a) { aoAdicionarPirata = a == null ? (n, s, c) -> { } : a; }
    public void setOnAdicionarMicrosoft(AoAdicionarMicrosoft a) { aoAdicionarMicrosoft = a == null ? (s, c) -> { } : a; }
    public void setOnRemoverConta(Consumer<String> c) { aoRemover = c == null ? id -> { } : c; }
    public void setOnCancelar(Runnable r) { aoCancelar = r == null ? () -> { } : r; }
    public void setOnAbrirPagina(Consumer<String> c) { aoAbrirPagina = c == null ? url -> { } : c; }

    // ------------------------------------------------------------- Layout

    private void montarInterface() {
        JPanel raiz = new JPanel(new BorderLayout(12, 12));
        raiz.setOpaque(false);
        raiz.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Entrar");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel subtitulo = new JLabel("Escolha sua conta e digite a senha.");
        subtitulo.setForeground(TEXTO_SECUNDARIO);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel cabecalho = new JPanel();
        cabecalho.setOpaque(false);
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.add(titulo);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(subtitulo);

        JPanel cartao = painelTranslucido(PAINEL, 20, 480, 470);
        cartao.setLayout(new BoxLayout(cartao, BoxLayout.Y_AXIS));
        cartao.setBorder(new EmptyBorder(18, 22, 16, 22));

        areaTelas.setOpaque(false);
        areaTelas.setAlignmentX(LEFT_ALIGNMENT);
        areaTelas.add(criarTelaContas(), TELA_CONTAS);
        areaTelas.add(criarTelaAdicionar(), TELA_ADICIONAR);
        cartao.add(areaTelas);

        montarCaixaCodigo();
        cartao.add(caixaCodigo);
        cartao.add(Box.createVerticalGlue());

        prepararTexto(status, 52);
        cartao.add(status);
        cartao.add(Box.createVerticalStrut(6));

        // Voltar e Cancelar dividem o mesmo espaço (só um aparece por vez)
        estilizarBotao(botaoVoltar, 16);
        estilizarBotao(botaoCancelar, 16);
        areaAcao.setOpaque(false);
        areaAcao.setAlignmentX(LEFT_ALIGNMENT);
        areaAcao.add(new JPanel() {{ setOpaque(false); }}, ACAO_NADA);
        areaAcao.add(botaoVoltar, ACAO_VOLTAR);
        areaAcao.add(botaoCancelar, ACAO_CANCELAR);
        areaAcao.setPreferredSize(new Dimension(100, 36));
        areaAcao.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        cartao.add(areaAcao);

        JPanel centro = new JPanel(new GridBagLayout());
        centro.setOpaque(false);
        centro.add(cartao);

        raiz.add(cabecalho, BorderLayout.NORTH);
        raiz.add(centro, BorderLayout.CENTER);
        add(raiz, BorderLayout.CENTER);
    }

    private JPanel criarTelaContas() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        p.add(rotulo("Suas contas"));
        p.add(Box.createVerticalStrut(4));
        p.add(criarCaixaDaLista());
        p.add(Box.createVerticalStrut(12));

        p.add(rotulo("Senha"));
        p.add(Box.createVerticalStrut(4));
        p.add(caixaDoCampo(campoSenhaEntrar));
        p.add(Box.createVerticalStrut(12));

        estilizarBotao(botaoEntrar, 18);
        botaoEntrar.setFont(new Font("SansSerif", Font.BOLD, 16));
        botaoEntrar.setAlignmentX(LEFT_ALIGNMENT);
        botaoEntrar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        p.add(botaoEntrar);
        p.add(Box.createVerticalStrut(10));

        estilizarBotao(botaoNovaConta, 14);
        estilizarBotao(botaoRemover, 14);
        JPanel linha = new JPanel(new GridLayout(1, 2, 8, 0));
        linha.setOpaque(false);
        linha.add(botaoNovaConta);
        linha.add(botaoRemover);
        linha.setAlignmentX(LEFT_ALIGNMENT);
        linha.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        p.add(linha);

        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel criarTelaAdicionar() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        JPanel abas = new JPanel(new GridLayout(1, 2, 8, 0));
        abas.setOpaque(false);
        estilizarBotao(abaMicrosoft, 14);
        estilizarBotao(abaPirata, 14);
        abaMicrosoft.setFont(new Font("SansSerif", Font.BOLD, 13));
        abaPirata.setFont(new Font("SansSerif", Font.BOLD, 13));
        abas.add(abaMicrosoft);
        abas.add(abaPirata);
        abas.setAlignmentX(LEFT_ALIGNMENT);
        abas.setPreferredSize(new Dimension(100, 38));
        abas.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        p.add(abas);
        p.add(Box.createVerticalStrut(12));

        areaModos.setOpaque(false);
        areaModos.setAlignmentX(LEFT_ALIGNMENT);
        areaModos.add(criarModoMicrosoft(), MODO_MICROSOFT);
        areaModos.add(criarModoPirata(), MODO_PIRATA);
        p.add(areaModos);
        p.add(Box.createVerticalStrut(10));

        p.add(rotulo("Senha do launcher para esta conta"));
        p.add(Box.createVerticalStrut(4));
        p.add(caixaDoCampo(campoSenhaNova));
        p.add(Box.createVerticalStrut(8));
        p.add(caixaDoCampo(campoSenhaConfirma));
        p.add(Box.createVerticalStrut(12));

        estilizarBotao(botaoAdicionar, 18);
        botaoAdicionar.setFont(new Font("SansSerif", Font.BOLD, 16));
        botaoAdicionar.setAlignmentX(LEFT_ALIGNMENT);
        botaoAdicionar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        p.add(botaoAdicionar);

        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel criarModoMicrosoft() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(descricao("Entre com a conta Microsoft que tem o Minecraft Java Edition. "
                + "Você vai receber um código para digitar no navegador.", 40));
        p.add(Box.createVerticalStrut(6));
        p.add(descricao("A senha da Microsoft é digitada só no site da Microsoft. "
                + "A senha abaixo é do launcher e protege esta conta aqui no PC.", 40));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel criarModoPirata() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(descricao("Conta offline: só precisa de um nome. Funciona em servidores com modo offline "
                + "e em mundos locais.", 40));
        p.add(Box.createVerticalStrut(6));
        p.add(rotulo("Nome de jogador"));
        p.add(Box.createVerticalStrut(4));
        p.add(caixaDoCampo(campoNome));
        p.add(Box.createVerticalGlue());
        return p;
    }

    private void montarCaixaCodigo() {
        caixaCodigo.setLayout(new BoxLayout(caixaCodigo, BoxLayout.Y_AXIS));
        caixaCodigo.setBorder(new EmptyBorder(10, 14, 12, 14));
        caixaCodigo.setAlignmentX(LEFT_ALIGNMENT);
        caixaCodigo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150));

        JLabel dica = new JLabel("Abra a página abaixo e digite o código:");
        dica.setForeground(TEXTO_SECUNDARIO);
        dica.setFont(new Font("SansSerif", Font.PLAIN, 12));
        dica.setAlignmentX(CENTER_ALIGNMENT);

        rotuloUrl.setForeground(TEXTO);
        rotuloUrl.setFont(new Font("SansSerif", Font.BOLD, 12));
        rotuloUrl.setAlignmentX(CENTER_ALIGNMENT);

        rotuloCodigo.setForeground(TEXTO);
        rotuloCodigo.setFont(new Font(Font.MONOSPACED, Font.BOLD, 28));
        rotuloCodigo.setAlignmentX(CENTER_ALIGNMENT);

        estilizarBotao(botaoAbrirPagina, 14);
        estilizarBotao(botaoCopiar, 14);
        JPanel linhaBotoes = new JPanel(new GridLayout(1, 2, 8, 0));
        linhaBotoes.setOpaque(false);
        linhaBotoes.add(botaoAbrirPagina);
        linhaBotoes.add(botaoCopiar);
        linhaBotoes.setAlignmentX(CENTER_ALIGNMENT);
        linhaBotoes.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        caixaCodigo.add(dica);
        caixaCodigo.add(Box.createVerticalStrut(2));
        caixaCodigo.add(rotuloUrl);
        caixaCodigo.add(Box.createVerticalStrut(4));
        caixaCodigo.add(rotuloCodigo);
        caixaCodigo.add(Box.createVerticalStrut(8));
        caixaCodigo.add(linhaBotoes);
    }

    private JLabel rotulo(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(TEXTO_SECUNDARIO);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JTextArea descricao(String texto, int altura) {
        JTextArea t = new JTextArea(texto);
        prepararTexto(t, altura);
        return t;
    }

    /** Texto com quebra de linha automática, sem fundo e sem edição (altura fixa para o layout não pular). */
    private void prepararTexto(JTextArea t, int altura) {
        t.setLineWrap(true);
        t.setWrapStyleWord(true);
        t.setEditable(false);
        t.setFocusable(false);
        t.setOpaque(false);
        t.setBorder(BorderFactory.createEmptyBorder());
        t.setForeground(TEXTO_SECUNDARIO);
        t.setFont(new Font("SansSerif", Font.PLAIN, 12));
        t.setAlignmentX(LEFT_ALIGNMENT);
        t.setPreferredSize(new Dimension(100, altura));
        t.setMaximumSize(new Dimension(Integer.MAX_VALUE, altura));
    }

    // ------------------------------------------------------------ Eventos

    private void ligarEventos() {
        // tela "Suas contas"
        botaoEntrar.addActionListener(e -> entrarNaSelecionada());
        campoSenhaEntrar.addActionListener(e -> entrarNaSelecionada());
        listaContas.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) campoSenhaEntrar.setText("");
        });
        botaoNovaConta.addActionListener(e -> mostrarAdicionar());
        botaoRemover.addActionListener(e -> removerSelecionada());

        // tela "Adicionar conta"
        abaMicrosoft.addActionListener(e -> { if (!ocupado) selecionarModo(true); });
        abaPirata.addActionListener(e -> { if (!ocupado) selecionarModo(false); });
        botaoAdicionar.addActionListener(e -> adicionar());
        campoNome.addActionListener(e -> campoSenhaNova.requestFocusInWindow());
        campoSenhaNova.addActionListener(e -> campoSenhaConfirma.requestFocusInWindow());
        campoSenhaConfirma.addActionListener(e -> { if (botaoAdicionar.isEnabled()) adicionar(); });

        // parte de baixo e código
        botaoVoltar.addActionListener(e -> mostrarContas());
        botaoCancelar.addActionListener(e -> aoCancelar.run());
        botaoAbrirPagina.addActionListener(e -> aoAbrirPagina.accept(rotuloUrl.getText()));
        botaoCopiar.addActionListener(e -> {
            try {
                Toolkit.getDefaultToolkit().getSystemClipboard()
                        .setContents(new StringSelection(rotuloCodigo.getText()), null);
                setStatus("Código copiado. Cole na página da Microsoft.");
            } catch (HeadlessException | IllegalStateException ex) {
                setErro("Não foi possível copiar. Digite o código manualmente.");
            }
        });
    }

    private void entrarNaSelecionada() {
        if (ocupado) return;
        ContaItem item = listaContas.getSelectedValue();
        if (item == null) {
            setErro("Escolha uma conta na lista.");
            return;
        }
        aoEntrar.entrar(item.id, campoSenhaEntrar.getPassword());
    }

    private void removerSelecionada() {
        if (ocupado) return;
        ContaItem item = listaContas.getSelectedValue();
        if (item == null) {
            setErro("Escolha uma conta na lista.");
            return;
        }
        int r = JOptionPane.showConfirmDialog(this,
                "Remover a conta \"" + item.nome + "\" (" + item.tipo + ") deste launcher?\n"
                        + "Você poderá adicionar de novo depois.",
                "Remover conta", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (r == JOptionPane.YES_OPTION) aoRemover.accept(item.id);
    }

    private void adicionar() {
        if (ocupado) return;
        char[] senha = campoSenhaNova.getPassword();
        char[] confirma = campoSenhaConfirma.getPassword();
        if (modoMicrosoft) {
            aoAdicionarMicrosoft.adicionar(senha, confirma);
        } else {
            aoAdicionarPirata.adicionar(campoNome.getText().trim(), senha, confirma);
        }
    }

    private void selecionarModo(boolean microsoft) {
        this.modoMicrosoft = microsoft;
        modos.show(areaModos, microsoft ? MODO_MICROSOFT : MODO_PIRATA);
        abaMicrosoft.putClientProperty("selecionada", microsoft);
        abaPirata.putClientProperty("selecionada", !microsoft);
        abaMicrosoft.setBackground(microsoft ? DESTAQUE : ABA_INATIVA);
        abaPirata.setBackground(microsoft ? ABA_INATIVA : DESTAQUE);
        botaoAdicionar.setText(microsoft ? "Entrar com Microsoft" : "Adicionar conta pirata");
        escreverStatus(" ", TEXTO_SECUNDARIO);
        if (!microsoft) SwingUtilities.invokeLater(campoNome::requestFocusInWindow);
    }

    private void atualizarEstado() {
        boolean livre = !ocupado;
        listaContas.setEnabled(livre);
        campoSenhaEntrar.setEnabled(livre);
        botaoEntrar.setEnabled(livre);
        botaoNovaConta.setEnabled(livre);
        botaoRemover.setEnabled(livre);
        abaMicrosoft.setEnabled(livre);
        abaPirata.setEnabled(livre);
        campoNome.setEnabled(livre);
        campoSenhaNova.setEnabled(livre);
        campoSenhaConfirma.setEnabled(livre);
        botaoAdicionar.setEnabled(livre);

        if (ocupado) {
            acaoInferior.show(areaAcao, ACAO_CANCELAR);
        } else if (naTelaAdicionar && !modeloContas.isEmpty()) {
            acaoInferior.show(areaAcao, ACAO_VOLTAR);
        } else {
            acaoInferior.show(areaAcao, ACAO_NADA);
        }
        revalidate();
        repaint();
    }

    private void escreverStatus(String texto, Color cor) {
        status.setForeground(cor);
        status.setText(texto == null ? "" : texto.trim());
    }

    private static String escapar(String t) {
        return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    // ------------------------------------------------------------- Estilo

    private JPanel painelTranslucido(Color fundo, int arco) {
        return painelTranslucido(fundo, arco, -1, -1);
    }

    /** Painel arredondado translúcido; largura/altura &gt; 0 fixam o tamanho preferido. */
    private JPanel painelTranslucido(Color fundo, int arco, int largura, int altura) {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(fundo);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);
                g2.setColor(BORDA);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
                g2.dispose();
            }

            @Override
            public Dimension getPreferredSize() {
                Dimension d = super.getPreferredSize();
                if (largura > 0) d.width = largura;
                if (altura > 0) d.height = altura;
                return d;
            }
        };
        p.setOpaque(false);
        return p;
    }

    private JPanel caixaDoCampo(JTextField campo) {
        campo.setOpaque(false);
        campo.setBorder(BorderFactory.createEmptyBorder());
        campo.setForeground(TEXTO);
        campo.setCaretColor(TEXTO);
        campo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(8, 12, 8, 12));
        caixa.add(campo, BorderLayout.CENTER);
        caixa.setAlignmentX(LEFT_ALIGNMENT);
        caixa.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        return caixa;
    }

    private JTextField criarCampoDica(String dica) {
        return new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getText().isEmpty()) desenharDica(g, this, dica);
            }
        };
    }

    private JPasswordField criarCampoSenha(String dica) {
        return new JPasswordField() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getPassword().length == 0) desenharDica(g, this, dica);
            }
        };
    }

    private static void desenharDica(Graphics g, JTextField campo, String dica) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setColor(new Color(195, 225, 255, 110));
        g2.setFont(campo.getFont());
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(dica, campo.getInsets().left, (campo.getHeight() - fm.getHeight()) / 2 + fm.getAscent());
        g2.dispose();
    }

    /** Lista de contas: espaço para LINHAS_VISIVEIS linhas, rola se tiver mais. */
    private JList<ContaItem> criarLista() {
        JList<ContaItem> l = new JList<>(modeloContas);
        l.setOpaque(false);
        l.setFixedCellHeight(ALTURA_LINHA);
        l.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        l.setForeground(TEXTO);
        l.setFont(new Font("SansSerif", Font.PLAIN, 13));
        l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        l.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> lista, Object v, int i,
                                                          boolean sel, boolean foco) {
                JLabel lb = (JLabel) super.getListCellRendererComponent(lista, v, i, sel, false);
                ContaItem c = (ContaItem) v;
                lb.setText("<html><b>" + escapar(c.nome) + "</b> &nbsp;<font color='#c3e1ff'>· "
                        + escapar(c.tipo) + "</font></html>");
                lb.setForeground(TEXTO);
                lb.setOpaque(sel);
                lb.setBackground(new Color(38, 105, 165, 220));
                lb.setBorder(new EmptyBorder(0, 12, 0, 12));
                return lb;
            }
        });
        return l;
    }

    private JComponent criarCaixaDaLista() {
        JScrollPane rolagem = new JScrollPane(listaContas,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        rolagem.setOpaque(false);
        rolagem.getViewport().setOpaque(false);
        rolagem.setBorder(BorderFactory.createEmptyBorder());
        rolagem.getVerticalScrollBar().setUnitIncrement(ALTURA_LINHA);

        JScrollBar barraV = rolagem.getVerticalScrollBar();
        barraV.setOpaque(false);
        barraV.setPreferredSize(new Dimension(10, 0));
        barraV.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() { }
            @Override protected JButton createDecreaseButton(int o) { return vazio(); }
            @Override protected JButton createIncreaseButton(int o) { return vazio(); }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(150, 205, 255, 120));
                g2.fillRoundRect(r.x + 2, r.y, r.width - 4, r.height, 8, 8);
                g2.dispose();
            }
            private JButton vazio() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });

        JPanel caixa = painelTranslucido(CAIXA, 14);
        caixa.setLayout(new BorderLayout());
        caixa.setBorder(new EmptyBorder(4, 4, 4, 4));
        caixa.add(rolagem, BorderLayout.CENTER);
        int altura = LINHAS_VISIVEIS * ALTURA_LINHA + 8;
        caixa.setPreferredSize(new Dimension(100, altura));
        caixa.setMaximumSize(new Dimension(Integer.MAX_VALUE, altura));
        caixa.setAlignmentX(LEFT_ALIGNMENT);
        return caixa;
    }

    /** Botão arredondado translúcido; abas usam a propriedade "selecionada" para não trocar de cor no hover. */
    private void estilizarBotao(JButton b, int arco) {
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setForeground(TEXTO);
        b.setBackground(DESTAQUE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 14, 8, 14));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(c.isEnabled() || Boolean.TRUE.equals(c.getClientProperty("selecionada"))
                        ? c.getBackground() : DESATIVADO);
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), arco, arco);
                g2.setColor(BORDA_BOTAO);
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, arco, arco);
                g2.dispose();
                paint(g, c);
            }

            @Override
            protected void paintText(Graphics g, AbstractButton btn, Rectangle area, String texto) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(btn.getFont());
                g2.setColor(btn.isEnabled() ? btn.getForeground() : TEXTO_DESATIVADO);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(texto, area.x, area.y + fm.getAscent());
                g2.dispose();
            }
        });
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { realcar(b, true); }
            @Override public void mouseExited(MouseEvent e) { realcar(b, false); }
        });
    }

    private void realcar(JButton b, boolean sobre) {
        if (!b.isEnabled()) return;
        if (b == abaMicrosoft || b == abaPirata) {
            if (Boolean.TRUE.equals(b.getClientProperty("selecionada"))) return;
            b.setBackground(sobre ? ABA_INATIVA_HOVER : ABA_INATIVA);
        } else {
            b.setBackground(sobre ? DESTAQUE_HOVER : DESTAQUE);
        }
    }
}
