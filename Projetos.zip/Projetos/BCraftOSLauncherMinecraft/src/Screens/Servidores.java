package Screens;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Servidores extends JPanel {

    private static final Color FUNDO = new Color(8, 25, 48, 225);
    private static final Color PAINEL = new Color(12, 35, 65, 155);
    private static final Color ABA_NORMAL = new Color(12, 35, 65, 145);
    private static final Color ABA_SELECIONADA = new Color(38, 105, 165, 205);
    private static final Color VERDE = new Color(120, 195, 255);
    private static final Color TEXTO = new Color(240, 242, 247);
    private static final Color TEXTO_SECUNDARIO = new Color(195, 225, 255);
    private static final Color BORDA = new Color(255, 255, 255, 35);

    private final JTabbedPane abas = new JTabbedPane();
    private final DefaultListModel<Servidor> modeloServidores =
            new DefaultListModel<>();
    private final JList<Servidor> listaServidores =
            new JList<>(modeloServidores);

    private final JTextField campoNome = new JTextField();
    private final JTextField campoBusca = new JTextField();
    private final JLabel mensagemInline = new JLabel("Digite o nome de um servidor para começar.");
    private final JButton botaoCriarInline = new JButton("+ Criar servidor");
    private JPanel painelDireito;
    private JPanel painelInicial;
    private JPanel painelGerenciamento;
    private JPanel painelCriacao;
    private CardLayout cartoesDireita;
    private JButton botaoSalvarConfig;
    private JButton botaoLigar;
    private JButton botaoDesligar;
    private JButton botaoReiniciar;
    private JButton botaoConcluirCriacao;
    private JLabel tituloFormulario;
    private final JComboBox<String> campoVersao =
            new JComboBox<>(new String[]{
                    "1.21.8", "1.21.5", "1.21.4", "1.20.1", "1.19.4"
            });
    private final JComboBox<String> campoLoader =
            new JComboBox<>(new String[]{
                    "Vanilla", "Paper", "Fabric", "Forge", "NeoForge"
            });
    private final JComboBox<String> campoJava =
            new JComboBox<>(new String[]{
                    "Detectar automaticamente", "Java 8",
                    "Java 17", "Java 21", "Java 25", "Java 27"
            });

    private final JSpinner campoRam =
            new JSpinner(new SpinnerNumberModel(2048, 512, 32768, 512));

    private final JLabel estadoServidor = new JLabel("Nenhum servidor selecionado");
    private final JLabel memoriaDisponivel = new JLabel();

    private final File pastaBase = new File(
            System.getProperty("user.home"),
            "BCraftOS/servers"
    );

    private final Map<String, Process> processos = new HashMap<>();
    private final Map<String, Thread> leitores = new HashMap<>();
    private final Map<String, Boolean> reinicios = new HashMap<>();

    private boolean atualizandoLista = false;

    public Servidores() {
        setLayout(new BorderLayout(0, 0));
        setOpaque(false);

        configurarLimitesDeEntrada();
        criarPastas();
        configurarLista();
        configurarAbas();
        montarInterface();
        carregarServidores();
        atualizarMemoria();
    }


    /** Limita o nome a 30 caracteres e impede campos com texto interminável. */
    private void configurarLimitesDeEntrada() {
        campoNome.setColumns(30);
        campoBusca.setColumns(30);
        limitarTexto(campoNome, 30);
        limitarTexto(campoBusca, 30);
    }

    private void limitarTexto(JTextField campo, int limite) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string,
                                     AttributeSet attr) throws BadLocationException {
                if (string == null) return;
                int disponivel = limite - fb.getDocument().getLength();
                if (disponivel > 0) {
                    super.insertString(fb, offset,
                            string.substring(0, Math.min(disponivel, string.length())), attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String string,
                                AttributeSet attrs) throws BadLocationException {
                String novo = string == null ? "" : string;
                int atual = fb.getDocument().getLength() - length;
                int disponivel = limite - atual;
                if (disponivel < 0) disponivel = 0;
                super.replace(fb, offset, length,
                        novo.substring(0, Math.min(disponivel, novo.length())), attrs);
            }
        });
    }

    private void criarPastas() {
        if (!pastaBase.exists()) {
            pastaBase.mkdirs();
        }
    }

    private void montarInterface() {
        JPanel raiz = new JPanel(new BorderLayout(12, 12));
        raiz.setOpaque(false);
        raiz.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Gerenciador de servidores");
        titulo.setForeground(TEXTO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));

        JLabel subtitulo = new JLabel(
                "Crie, organize e gerencie seus servidores Minecraft."
        );
        subtitulo.setForeground(TEXTO_SECUNDARIO);
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel cabecalho = new JPanel();
        cabecalho.setOpaque(false);
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.add(titulo);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(subtitulo);

        raiz.add(cabecalho, BorderLayout.NORTH);
        raiz.add(abas, BorderLayout.CENTER);

        add(raiz, BorderLayout.CENTER);
    }

    private void configurarAbas() {
        abas.setOpaque(false);
        abas.setFocusable(false);
        abas.setFont(new Font("SansSerif", Font.BOLD, 13));
        abas.setForeground(TEXTO);
        abas.setBackground(FUNDO);
        abas.setBorder(BorderFactory.createEmptyBorder());
        abas.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

        /*
         * Desenha manualmente as abas. Isso evita que o tema padrão
         * do sistema deixe os nomes brancos sobre fundo branco.
         */
        abas.setUI(new BasicTabbedPaneUI() {

            @Override
            protected void installDefaults() {
                super.installDefaults();
                contentBorderInsets = new Insets(5, 0, 0, 0);
                tabAreaInsets = new Insets(2, 2, 2, 2);
                tabInsets = new Insets(7, 12, 7, 12);
            }

            @Override
            protected void paintTabBackground(
                    Graphics g,
                    int placement,
                    int index,
                    int x,
                    int y,
                    int w,
                    int h,
                    boolean selected
            ) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                g2.setColor(selected ? ABA_SELECIONADA : ABA_NORMAL);
                g2.fillRoundRect(x + 2, y + 2, w - 4, h - 3, 12, 12);

                if (selected) {
                    g2.setColor(VERDE);
                    g2.fillRoundRect(x + 10, y + h - 5, w - 20, 3, 3, 3);
                }

                g2.dispose();
            }

            @Override
            protected void paintTabBorder(
                    Graphics g,
                    int placement,
                    int index,
                    int x,
                    int y,
                    int w,
                    int h,
                    boolean selected
            ) {
                // Sem borda padrão: visual mais limpo.
            }

            @Override
            protected void paintText(
                    Graphics g,
                    int placement,
                    Font font,
                    FontMetrics metrics,
                    int index,
                    String title,
                    Rectangle textRect,
                    boolean selected
            ) {
                g.setFont(font);
                g.setColor(selected ? Color.WHITE : TEXTO_SECUNDARIO);
                g.drawString(title, textRect.x, textRect.y + metrics.getAscent());
            }

            @Override
            protected void paintContentBorder(
                    Graphics g,
                    int placement,
                    int selectedIndex
            ) {
                // Mantém a área de conteúdo sem a borda padrão do Swing.
            }
        });

        abas.addTab("Principal", criarAbaPrincipal());
        abas.addTab("Plugins", criarAbaArquivos("plugins"));
        abas.addTab("Mods", criarAbaArquivos("mods"));
        abas.addTab("Datapacks", criarAbaArquivos("datapacks"));
        abas.addTab("Modpacks", criarAbaArquivos("modpacks"));

        for (int i = 0; i < abas.getTabCount(); i++) {
            abas.setForegroundAt(i, TEXTO);
            abas.setBackgroundAt(i, ABA_NORMAL);
        }

        abas.setSelectedIndex(0);
    }

    private JPanel criarAbaPrincipal() {
        JPanel pagina = painelTranslucido();
        pagina.setLayout(new BorderLayout(6, 6));
        pagina.setBorder(new EmptyBorder(6, 6, 6, 6));

        JPanel esquerda = painelTranslucido();
        esquerda.setLayout(new BorderLayout(5, 5));
        esquerda.setPreferredSize(new Dimension(158, 150));
        esquerda.setMinimumSize(new Dimension(125, 100));
        esquerda.setBorder(new EmptyBorder(7, 7, 7, 7));
        esquerda.add(titulo("Seus servidores"), BorderLayout.NORTH);

        listaServidores.setOpaque(false);
        listaServidores.setForeground(TEXTO);
        listaServidores.setSelectionBackground(ABA_SELECIONADA);
        listaServidores.setSelectionForeground(Color.WHITE);
        listaServidores.setFont(new Font("SansSerif", Font.PLAIN, 12));
        listaServidores.setFixedCellHeight(30);
        listaServidores.setBorder(new EmptyBorder(3, 3, 3, 3));
        listaServidores.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value,
                                                          int index, boolean selected, boolean focus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(
                        list, value, index, selected, focus);
                label.setOpaque(selected);
                label.setForeground(TEXTO);
                label.setBackground(selected ? ABA_SELECIONADA : new Color(12, 35, 65, 80));
                label.setBorder(new EmptyBorder(6, 7, 6, 7));
                return label;
            }
        });
        JScrollPane scrollLista = new JScrollPane(listaServidores);
        scrollLista.setOpaque(false);
        scrollLista.getViewport().setOpaque(false);
        scrollLista.setBorder(new LineBorder(BORDA, 1, true));
        scrollLista.getVerticalScrollBar().setUnitIncrement(12);
        estilizarRolagemAzul(scrollLista.getVerticalScrollBar());
        esquerda.add(scrollLista, BorderLayout.CENTER);

        JButton importar = botao("Importar");
        JButton criarPeloMenu = botao("+ Criar");
        for (JButton pequeno : new JButton[]{criarPeloMenu, importar}) {
            pequeno.setFont(new Font("SansSerif", Font.BOLD, 11));
            pequeno.setBorder(new EmptyBorder(5, 3, 5, 3));
        }
        JPanel acoesLista = new JPanel(new GridLayout(1, 2, 5, 0));
        acoesLista.setOpaque(false);
        acoesLista.add(criarPeloMenu);
        acoesLista.add(importar);
        esquerda.add(acoesLista, BorderLayout.SOUTH);
        criarPeloMenu.addActionListener(e -> {
            campoBusca.setText("");
            mostrarFormularioCriacao();
        });
        importar.addActionListener(e -> importarServidor());

        painelDireito = painelTranslucido();
        painelDireito.setLayout(new CardLayout());
        cartoesDireita = (CardLayout) painelDireito.getLayout();
        painelDireito.setBorder(new EmptyBorder(7, 7, 7, 7));

        // Tela inicial: a pergunta principal é o nome do servidor.
        painelInicial = new JPanel(new GridBagLayout());
        painelInicial.setOpaque(false);
        JPanel pesquisaConteudo = new JPanel();
        pesquisaConteudo.setOpaque(false);
        pesquisaConteudo.setLayout(new BoxLayout(pesquisaConteudo, BoxLayout.Y_AXIS));
        JLabel pergunta = titulo("Qual é o nome do servidor?");
        pergunta.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel ajuda = new JLabel("Digite o nome cadastrado para abrir ou um novo nome para criar.");
        ajuda.setForeground(TEXTO_SECUNDARIO);
        ajuda.setFont(new Font("SansSerif", Font.PLAIN, 12));
        ajuda.setAlignmentX(Component.LEFT_ALIGNMENT);

        campoBusca.setFont(new Font("SansSerif", Font.PLAIN, 13));
        campoBusca.setForeground(TEXTO);
        campoBusca.setCaretColor(Color.WHITE);
        campoBusca.setBackground(new Color(18, 45, 75, 135));
        campoBusca.setOpaque(false);
        campoBusca.setBorder(new CompoundBorder(
                new LineBorder(new Color(150, 205, 255, 90), 1, true),
                new EmptyBorder(8, 9, 8, 9)));
        campoBusca.setPreferredSize(new Dimension(300, 34));
        campoBusca.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        JButton buscar = botao("Buscar servidor");
        buscar.setAlignmentX(Component.LEFT_ALIGNMENT);
        buscar.setMaximumSize(new Dimension(220, 36));
        mensagemInline.setForeground(TEXTO_SECUNDARIO);
        mensagemInline.setFont(new Font("SansSerif", Font.PLAIN, 12));
        mensagemInline.setAlignmentX(Component.LEFT_ALIGNMENT);
        botaoCriarInline.setVisible(false);
        estilizarBotaoInline(botaoCriarInline);
        botaoCriarInline.setAlignmentX(Component.LEFT_ALIGNMENT);
        pesquisaConteudo.add(pergunta);
        pesquisaConteudo.add(Box.createVerticalStrut(6));
        pesquisaConteudo.add(ajuda);
        pesquisaConteudo.add(Box.createVerticalStrut(8));
        pesquisaConteudo.add(campoBusca);
        pesquisaConteudo.add(Box.createVerticalStrut(6));
        pesquisaConteudo.add(buscar);
        pesquisaConteudo.add(Box.createVerticalStrut(6));
        pesquisaConteudo.add(mensagemInline);
        pesquisaConteudo.add(Box.createVerticalStrut(7));
        pesquisaConteudo.add(botaoCriarInline);
        GridBagConstraints pc = new GridBagConstraints();
        pc.gridx = 0; pc.gridy = 0; pc.weightx = 1; pc.fill = GridBagConstraints.HORIZONTAL;
        pc.anchor = GridBagConstraints.NORTHWEST; pc.insets = new Insets(2, 2, 2, 2);
        painelInicial.add(pesquisaConteudo, pc);

        // Formulário único e compacto, reaproveitado para criação e configuração.
        JPanel formularioCartao = new JPanel(new BorderLayout(5, 5));
        formularioCartao.setOpaque(false);
        tituloFormulario = titulo("Criar novo servidor");
        formularioCartao.add(tituloFormulario, BorderLayout.NORTH);
        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(0, 2, 2, 6);
        // Campos compactos, alinhados à esquerda em vez de esticados
        // por toda a largura disponível do painel.
        c.fill = GridBagConstraints.NONE;
        c.weightx = 0;
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 0;
        c.gridy = 0;
        // Formulário compacto: campos lado a lado para ocupar menos altura.
        c.gridwidth = 2;
        adicionarCampo(formulario, c, "Nome do servidor", campoNome);
        c.gridwidth = 1;
        c.gridy++;
        // Aplica o estilo escuro aos campos (o painel temporário é descartado).
        JPanel tmp = new JPanel(new GridBagLayout());
        for (JComponent k : new JComponent[]{campoVersao, campoLoader, campoJava, campoRam}) {
            adicionarCampo(tmp, new GridBagConstraints(), "", k);
        }
        JPanel colVersao = new JPanel(new BorderLayout(0, 1));
        colVersao.setOpaque(false);
        JLabel lv = new JLabel("Versão do Minecraft");
        lv.setForeground(TEXTO_SECUNDARIO);
        lv.setFont(new Font("SansSerif", Font.PLAIN, 11));
        colVersao.add(lv, BorderLayout.NORTH);
        colVersao.add(campoVersao, BorderLayout.CENTER);
        JPanel colLoader = new JPanel(new BorderLayout(0, 1));
        colLoader.setOpaque(false);
        JLabel ll = new JLabel("Tipo de servidor");
        ll.setForeground(TEXTO_SECUNDARIO);
        ll.setFont(new Font("SansSerif", Font.PLAIN, 11));
        colLoader.add(ll, BorderLayout.NORTH);
        colLoader.add(campoLoader, BorderLayout.CENTER);
        JPanel colJava = new JPanel(new BorderLayout(0, 1));
        colJava.setOpaque(false);
        JLabel lj = new JLabel("Java");
        lj.setForeground(TEXTO_SECUNDARIO);
        lj.setFont(new Font("SansSerif", Font.PLAIN, 11));
        colJava.add(lj, BorderLayout.NORTH);
        colJava.add(campoJava, BorderLayout.CENTER);
        JPanel colRam = new JPanel(new BorderLayout(0, 1));
        colRam.setOpaque(false);
        JLabel lr = new JLabel("Memória RAM (MB)");
        lr.setForeground(TEXTO_SECUNDARIO);
        lr.setFont(new Font("SansSerif", Font.PLAIN, 11));
        colRam.add(lr, BorderLayout.NORTH);
        colRam.add(campoRam, BorderLayout.CENTER);
        for (JComponent k : new JComponent[]{campoVersao, campoLoader, campoJava, campoRam}) {
            k.setFont(new Font("SansSerif", Font.PLAIN, 12));
            k.setForeground(TEXTO);
            k.setPreferredSize(new Dimension(235, 28));
        }
        campoNome.setPreferredSize(new Dimension(480, 28));
        campoNome.setMaximumSize(new Dimension(480, 28));
        campoJava.setPreferredSize(new Dimension(235, 28));
        formulario.add(colVersao, c);
        c.gridx = 1;
        formulario.add(colLoader, c);
        c.gridx = 0;
        c.gridy++;
        formulario.add(colJava, c);
        c.gridx = 1;
        formulario.add(colRam, c);
        memoriaDisponivel.setForeground(TEXTO_SECUNDARIO);
        memoriaDisponivel.setFont(new Font("SansSerif", Font.PLAIN, 10));
        c.gridx = 0;
        c.gridwidth = 2;
        c.gridy++;
        c.weightx = 1;
        c.weighty = 1;
        c.anchor = GridBagConstraints.NORTHWEST;
        formulario.add(memoriaDisponivel, c);
        formularioCartao.add(formulario, BorderLayout.CENTER);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
        botoes.setOpaque(false);
        botaoConcluirCriacao = botao("Criar servidor");
        botaoSalvarConfig = botao("Salvar alterações");
        botaoLigar = botao("▶ Ligar");
        botaoDesligar = botao("■ Desligar");
        botaoReiniciar = botao("↻ Reiniciar");
        botoes.add(botaoConcluirCriacao);
        botoes.add(botaoSalvarConfig);
        botoes.add(botaoLigar);
        botoes.add(botaoDesligar);
        botoes.add(botaoReiniciar);
        JPanel rodapeFormulario = new JPanel(new BorderLayout(6, 6));
        rodapeFormulario.setOpaque(false);
        estadoServidor.setForeground(TEXTO_SECUNDARIO);
        estadoServidor.setFont(new Font("SansSerif", Font.PLAIN, 11));
        rodapeFormulario.add(estadoServidor, BorderLayout.NORTH);
        rodapeFormulario.add(botoes, BorderLayout.CENTER);
        formularioCartao.add(rodapeFormulario, BorderLayout.SOUTH);
        botaoConcluirCriacao.addActionListener(e -> concluirCriacaoServidor());
        botaoSalvarConfig.addActionListener(e -> salvarConfiguracaoSelecionada());
        botaoLigar.addActionListener(e -> iniciarServidorSelecionado());
        botaoDesligar.addActionListener(e -> pararServidorSelecionado(false));
        botaoReiniciar.addActionListener(e -> pararServidorSelecionado(true));

        painelGerenciamento = formularioCartao;
        painelCriacao = formularioCartao;
        painelDireito.add(painelInicial, "inicio");
        JScrollPane scrollFormulario = new JScrollPane(formularioCartao);
        scrollFormulario.setOpaque(false);
        scrollFormulario.getViewport().setOpaque(false);
        scrollFormulario.setBorder(BorderFactory.createEmptyBorder());
        scrollFormulario.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollFormulario.getVerticalScrollBar().setUnitIncrement(16);
        estilizarRolagemAzul(scrollFormulario.getVerticalScrollBar());
        painelDireito.add(scrollFormulario, "formulario");
        configurarModoCriacao(false);
        cartoesDireita.show(painelDireito, "inicio");

        Runnable procurar = this::pesquisarServidor;
        buscar.addActionListener(e -> procurar.run());
        campoBusca.addActionListener(e -> procurar.run());
        botaoCriarInline.addActionListener(e -> mostrarFormularioCriacao());

        estadoServidor.setForeground(TEXTO_SECUNDARIO);
        estadoServidor.setFont(new Font("SansSerif", Font.PLAIN, 12));
        estadoServidor.setBorder(new EmptyBorder(4, 0, 0, 0));

        painelDireito.setPreferredSize(new Dimension(540, 300));
        painelDireito.setMinimumSize(new Dimension(300, 200));
        JPanel ladoDireito = new JPanel(new GridBagLayout());
        ladoDireito.setOpaque(false);
        GridBagConstraints gl = new GridBagConstraints();
        gl.gridx = 0; gl.gridy = 0; gl.weightx = 1; gl.weighty = 1;
        gl.anchor = GridBagConstraints.NORTHWEST;
        gl.fill = GridBagConstraints.NONE;
        ladoDireito.add(painelDireito, gl);

        pagina.add(esquerda, BorderLayout.WEST);
        pagina.add(ladoDireito, BorderLayout.CENTER);

        listaServidores.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && getSelecionado() != null) {
                Servidor servidor = getSelecionado();
                campoBusca.setText(servidor.nome);
                campoNome.setText(servidor.nome);
                preencherFormulario();
                configurarModoCriacao(false);
                tituloFormulario.setText("Configuração — " + servidor.nome);
                cartoesDireita.show(painelDireito, "formulario");
            }
        });
        return pagina;
    }

    private JPanel criarAbaArquivos(String tipo) {
        JPanel pagina = painelTranslucido();
        pagina.setLayout(new BorderLayout(7, 7));
        pagina.setBorder(new EmptyBorder(8, 8, 8, 8));

        String nomeTipo = tipo.substring(0, 1).toUpperCase()
                + tipo.substring(1);

        JLabel cabecalho = titulo(nomeTipo);
        JLabel descricao = new JLabel(
                "Importe arquivos ou abra a pasta deste servidor."
        );
        descricao.setForeground(TEXTO_SECUNDARIO);

        JPanel topo = new JPanel();
        topo.setOpaque(false);
        topo.setLayout(new BoxLayout(topo, BoxLayout.Y_AXIS));
        topo.add(cabecalho);
        topo.add(Box.createVerticalStrut(6));
        topo.add(descricao);

        JTextArea informacao = new JTextArea(
                "Servidor selecionado: nenhum\n\n"
                        + "Os arquivos são organizados dentro da pasta do servidor.\n"
                        + "A compatibilidade de plugins e mods depende da versão "
                        + "do Minecraft e do loader utilizado."
        );
        informacao.setEditable(false);
        informacao.setLineWrap(true);
        informacao.setWrapStyleWord(true);
        informacao.setOpaque(false);
        informacao.setForeground(TEXTO);
        informacao.setFont(new Font("SansSerif", Font.PLAIN, 14));
        informacao.setBorder(new EmptyBorder(16, 0, 16, 0));

        JButton abrirPasta = botao("Abrir pasta");
        JButton importarArquivo = botao("Importar arquivo");

        abrirPasta.addActionListener(e -> abrirPastaTipo(tipo));
        importarArquivo.addActionListener(e -> importarArquivoTipo(tipo));

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        acoes.setOpaque(false);
        acoes.add(abrirPasta);
        acoes.add(importarArquivo);

        JPanel conteudo = painelTranslucido();
        conteudo.setLayout(new BorderLayout(8, 8));
        conteudo.setBorder(new EmptyBorder(10, 10, 10, 10));
        conteudo.add(informacao, BorderLayout.CENTER);
        conteudo.add(acoes, BorderLayout.SOUTH);

        pagina.add(topo, BorderLayout.NORTH);
        pagina.add(conteudo, BorderLayout.CENTER);

        return pagina;
    }

    private void estilizarRolagemAzul(JScrollBar barra) {
        barra.setPreferredSize(new Dimension(10, 10));
        barra.setOpaque(false);
        barra.setBackground(new Color(12, 35, 65, 90));
        barra.setUI(new javax.swing.plaf.basic.BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                thumbColor = new Color(70, 145, 205, 210);
                trackColor = new Color(12, 35, 65, 90);
            }
            @Override protected JButton createDecreaseButton(int orientation) {
                return botaoSetaVazio();
            }
            @Override protected JButton createIncreaseButton(int orientation) {
                return botaoSetaVazio();
            }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(12, 35, 65, 100));
                g2.fillRoundRect(r.x, r.y, r.width, r.height, 8, 8);
                g2.dispose();
            }
            @Override protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                if (r.isEmpty() || !scrollbar.isEnabled()) return;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(70, 145, 205, 210));
                g2.fillRoundRect(r.x + 1, r.y + 1, Math.max(3, r.width - 2), Math.max(8, r.height - 2), 8, 8);
                g2.dispose();
            }
            private JButton botaoSetaVazio() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                b.setMinimumSize(new Dimension(0, 0));
                b.setMaximumSize(new Dimension(0, 0));
                b.setOpaque(false);
                b.setContentAreaFilled(false);
                b.setBorder(BorderFactory.createEmptyBorder());
                return b;
            }
        });
    }

    private JPanel painelTranslucido() {
        JPanel p = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );
                g2.setColor(PAINEL);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDA);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(3, 3, 3, 3));
        return p;
    }

    private JLabel titulo(String texto) {
        JLabel label = new JLabel(texto);
        label.setForeground(TEXTO);
        label.setFont(new Font("SansSerif", Font.BOLD, 16));
        return label;
    }

    /** Deixa o botão com cantos realmente arredondados (sem fundo quadrado atrás). */
    private void arredondar(JButton b) {
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void update(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(c.getBackground());
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 16, 16);
                g2.setColor(new Color(150, 205, 255, 90));
                g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 16, 16);
                g2.dispose();
                paint(g, c);
            }
        });
    }

    private JButton botao(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setForeground(TEXTO);
        b.setBackground(new Color(25, 75, 120, 225));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(6, 10, 6, 10));
        arredondar(b);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        b.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                b.setBackground(new Color(55, 135, 195, 240));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                b.setBackground(new Color(25, 75, 120, 225));
            }
        });

        return b;
    }

    private void adicionarCampo(
            JPanel painel,
            GridBagConstraints c,
            String nome,
            JComponent componente
    ) {
        JLabel label = new JLabel(nome);
        label.setForeground(TEXTO_SECUNDARIO);
        label.setFont(new Font("SansSerif", Font.PLAIN, 11));

        c.gridx = 0;
        c.weightx = 0;
        c.gridy++;
        painel.add(label, c);

        c.gridy++;
        painel.add(componente, c);

        componente.setFont(new Font("SansSerif", Font.PLAIN, 13));
        if (componente == campoNome) {
            campoNome.setPreferredSize(new Dimension(310, 26));
            campoNome.setMaximumSize(new Dimension(310, 26));
        } else if (componente == campoVersao || componente == campoLoader
                || componente == campoJava) {
            componente.setPreferredSize(new Dimension(150, 26));
            componente.setMaximumSize(new Dimension(150, 26));
        } else if (componente == campoRam) {
            componente.setPreferredSize(new Dimension(150, 26));
            componente.setMaximumSize(new Dimension(150, 26));
        }
        componente.setForeground(TEXTO);
        componente.setBackground(new Color(18, 45, 75, 150));
        componente.setOpaque(false);
        componente.setBorder(new CompoundBorder(
                new LineBorder(new Color(150, 205, 255, 75), 1, true),
                new EmptyBorder(1, 6, 1, 6)
        ));
        if (componente instanceof JComboBox<?>) {
            JComboBox<?> combo = (JComboBox<?>) componente;
            combo.setOpaque(false);
            combo.setRenderer(new DefaultListCellRenderer() {
                @Override
                public Component getListCellRendererComponent(JList<?> list, Object value,
                                                              int index, boolean selected, boolean focus) {
                    JLabel label = (JLabel) super.getListCellRendererComponent(
                            list, value, index, selected, focus);
                    label.setForeground(TEXTO);
                    label.setBackground(selected ? ABA_SELECIONADA : new Color(18, 45, 75, 235));
                    label.setOpaque(true);
                    label.setBorder(new EmptyBorder(4, 6, 4, 6));
                    return label;
                }
            });
        } else if (componente instanceof JSpinner) {
            JSpinner spinner = (JSpinner) componente;
            JComponent editor = spinner.getEditor();
            editor.setOpaque(false);
            if (editor instanceof JSpinner.DefaultEditor) {
                JTextField texto = ((JSpinner.DefaultEditor) editor).getTextField();
                texto.setForeground(TEXTO);
                texto.setCaretColor(Color.WHITE);
                texto.setBackground(new Color(18, 45, 75, 140));
                texto.setOpaque(false);
                texto.setBorder(new EmptyBorder(1, 4, 1, 4));
            }
        }
    }

    private void configurarLista() {
        listaServidores.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );
    }

    private void criarServidor() {
        mostrarFormularioCriacao();
    }

    private void mostrarFormularioCriacao() {
        listaServidores.clearSelection();
        campoNome.setText(campoBusca.getText().trim());
        campoNome.setEditable(true);
        estadoServidor.setText("Novo servidor — preencha os dados e crie.");
        mensagemInline.setText("Esse nome ainda não está cadastrado.");
        botaoCriarInline.setVisible(false);
        configurarModoCriacao(true);
        if (tituloFormulario != null) tituloFormulario.setText("Criar novo servidor");
        cartoesDireita.show(painelDireito, "formulario");
        campoNome.requestFocusInWindow();
    }

    private void concluirCriacaoServidor() {
        String nome = campoNome.getText().trim();
        if (nome.isEmpty()) {
            mensagemErro("Digite um nome para o servidor.");
            campoNome.requestFocusInWindow();
            return;
        }
        if (nome.matches(".*[\\\\/:*?\"<>|].*")) {
            mensagemErro("O nome contém caracteres inválidos.");
            return;
        }
        File pasta = new File(pastaBase, nome);
        if (pasta.exists()) {
            mensagemErro("Já existe uma pasta com esse nome. Pesquise pelo servidor para abri-lo.");
            campoBusca.setText(nome);
            pesquisarServidor();
            return;
        }
        if (!pasta.mkdirs()) {
            mensagemErro("Não foi possível criar a pasta do servidor.");
            return;
        }
        Servidor servidor = new Servidor(nome, String.valueOf(campoVersao.getSelectedItem()),
                String.valueOf(campoLoader.getSelectedItem()), (Integer) campoRam.getValue(), pasta);
        salvarServidor(servidor);
        carregarServidores();
        selecionarServidor(nome);
        campoBusca.setText(nome);
        escreverConsole("Servidor criado: " + nome + "\nPasta: " + pasta.getAbsolutePath()
                + "\nColoque o arquivo executável do servidor nessa pasta.");
        configurarModoCriacao(false);
        if (tituloFormulario != null) tituloFormulario.setText("Configuração — " + nome);
        cartoesDireita.show(painelDireito, "formulario");
    }

    private void pesquisarServidor() {
        String nome = campoBusca.getText().trim();
        if (nome.isEmpty()) {
            mensagemInline.setText("Digite o nome de um servidor.");
            botaoCriarInline.setVisible(false);
            cartoesDireita.show(painelDireito, "inicio");
            return;
        }
        for (int i = 0; i < modeloServidores.size(); i++) {
            Servidor servidor = modeloServidores.get(i);
            if (servidor.nome.equalsIgnoreCase(nome)) {
                listaServidores.setSelectedIndex(i);
                listaServidores.ensureIndexIsVisible(i);
                campoBusca.setText(servidor.nome);
                botaoCriarInline.setVisible(false);
                configurarModoCriacao(false);
                if (tituloFormulario != null) tituloFormulario.setText("Configuração — " + servidor.nome);
                cartoesDireita.show(painelDireito, "formulario");
                return;
            }
        }
        File pasta = new File(pastaBase, nome);
        if (pasta.isDirectory()) {
            carregarServidores();
            selecionarServidor(pasta.getName());
            campoBusca.setText(pasta.getName());
            botaoCriarInline.setVisible(false);
            configurarModoCriacao(false);
            if (tituloFormulario != null) tituloFormulario.setText("Configuração — " + pasta.getName());
            cartoesDireita.show(painelDireito, "formulario");
            return;
        }
        listaServidores.clearSelection();
        mensagemInline.setText("Servidor '" + nome + "' não encontrado.");
        botaoCriarInline.setVisible(true);
        cartoesDireita.show(painelDireito, "inicio");
    }

    private void configurarModoCriacao(boolean criar) {
        if (botaoConcluirCriacao != null) botaoConcluirCriacao.setVisible(criar);
        if (botaoSalvarConfig != null) botaoSalvarConfig.setVisible(!criar);
        if (botaoLigar != null) botaoLigar.setVisible(!criar);
        if (botaoDesligar != null) botaoDesligar.setVisible(!criar);
        if (botaoReiniciar != null) botaoReiniciar.setVisible(!criar);
    }

    private void estilizarBotaoInline(JButton b) {
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setForeground(TEXTO);
        b.setBackground(new Color(38, 105, 165, 205));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(7, 12, 7, 12));
        arredondar(b);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void importarServidor() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Importar pasta ou arquivo ZIP");
        chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        chooser.setAcceptAllFileFilterUsed(true);

        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File origem = chooser.getSelectedFile();
        String nome = origem.getName();

        if (nome.toLowerCase(Locale.ROOT).endsWith(".zip")) {
            nome = nome.substring(0, nome.length() - 4);
        }

        nome = nome.replaceAll("[\\\\/:*?\"<>|]", "_");
        File destino = new File(pastaBase, nome);

        if (destino.exists()) {
            nome = nome + "_" + System.currentTimeMillis();
            destino = new File(pastaBase, nome);
        }

        try {
            if (origem.isDirectory()) {
                copiarPasta(origem.toPath(), destino.toPath());
            } else if (origem.getName().toLowerCase(Locale.ROOT).endsWith(".zip")) {
                extrairZip(origem, destino);
            } else {
                mensagemErro("Escolha uma pasta ou um arquivo ZIP.");
                return;
            }

            Servidor servidor = new Servidor(
                    nome,
                    String.valueOf(campoVersao.getSelectedItem()),
                    String.valueOf(campoLoader.getSelectedItem()),
                    (Integer) campoRam.getValue(),
                    destino
            );

            salvarServidor(servidor);
            carregarServidores();
            selecionarServidor(nome);

            escreverConsole("Servidor importado para: " + destino);
        } catch (IOException ex) {
            mensagemErro("Falha ao importar: " + ex.getMessage());
        }
    }

    private void copiarPasta(Path origem, Path destino) throws IOException {
        Files.walkFileTree(origem, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(
                    Path dir,
                    BasicFileAttributes attrs
            ) throws IOException {
                Path relativa = origem.relativize(dir);
                Files.createDirectories(destino.resolve(relativa));
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(
                    Path arquivo,
                    BasicFileAttributes attrs
            ) throws IOException {
                Path relativa = origem.relativize(arquivo);
                Files.copy(
                        arquivo,
                        destino.resolve(relativa),
                        StandardCopyOption.REPLACE_EXISTING
                );
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private void extrairZip(File zip, File destino) throws IOException {
        Path raiz = destino.toPath().toAbsolutePath().normalize();
        Files.createDirectories(raiz);

        try (ZipInputStream entrada = new ZipInputStream(
                new BufferedInputStream(new FileInputStream(zip)))) {

            ZipEntry item;

            while ((item = entrada.getNextEntry()) != null) {
                Path saida = raiz.resolve(item.getName()).normalize();

                if (!saida.startsWith(raiz)) {
                    throw new IOException(
                            "O ZIP contém um caminho de arquivo inválido."
                    );
                }

                if (item.isDirectory()) {
                    Files.createDirectories(saida);
                } else {
                    Path pai = saida.getParent();

                    if (pai != null) {
                        Files.createDirectories(pai);
                    }

                    Files.copy(
                            entrada,
                            saida,
                            StandardCopyOption.REPLACE_EXISTING
                    );
                }

                entrada.closeEntry();
            }
        }
    }

    private void carregarServidores() {
        atualizandoLista = true;
        modeloServidores.clear();

        File[] pastas = pastaBase.listFiles(File::isDirectory);

        if (pastas != null) {
            Arrays.sort(
                    pastas,
                    Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER)
            );

            for (File pasta : pastas) {
                Servidor s = lerServidor(pasta);
                modeloServidores.addElement(s);
            }
        }

        atualizandoLista = false;

        // Não selecionar automaticamente: primeiro o usuário pesquisa ou escolhe um servidor.
    }

    private Servidor lerServidor(File pasta) {
        File arquivo = new File(pasta, ".bcraft.properties");
        Properties props = new Properties();

        try (FileInputStream in = new FileInputStream(arquivo)) {
            props.load(in);
        } catch (IOException ignored) {
            // Servidores importados podem não ter configurações próprias.
        }

        String versao = props.getProperty("versao", "1.21.8");
        String loader = props.getProperty("loader", "Vanilla");

        int ram = 2048;
        try {
            ram = Integer.parseInt(props.getProperty("ram", "2048"));
        } catch (NumberFormatException ignored) {
        }

        return new Servidor(
                pasta.getName(),
                versao,
                loader,
                Math.max(512, ram),
                pasta
        );
    }

    private void salvarServidor(Servidor servidor) {
        Properties props = new Properties();
        props.setProperty("versao", servidor.versao);
        props.setProperty("loader", servidor.loader);
        props.setProperty("ram", String.valueOf(servidor.ramMB));

        File arquivo = new File(servidor.pasta, ".bcraft.properties");

        try (FileOutputStream out = new FileOutputStream(arquivo)) {
            props.store(out, "Configuração do BCraft Launcher");
        } catch (IOException ex) {
            mensagemErro("Não foi possível salvar: " + ex.getMessage());
        }
    }

    private void selecionarServidor(String nome) {
        for (int i = 0; i < modeloServidores.size(); i++) {
            if (modeloServidores.get(i).nome.equals(nome)) {
                listaServidores.setSelectedIndex(i);
                listaServidores.ensureIndexIsVisible(i);
                return;
            }
        }
    }

    private Servidor getSelecionado() {
        return listaServidores.getSelectedValue();
    }

    private void preencherFormulario() {
        if (atualizandoLista) {
            return;
        }

        Servidor s = getSelecionado();

        if (s == null) {
            estadoServidor.setText("Nenhum servidor selecionado");
            return;
        }

        campoNome.setText(s.nome);
        campoVersao.setSelectedItem(s.versao);
        campoLoader.setSelectedItem(s.loader);
        campoRam.setValue(Math.max(512, s.ramMB));
        estadoServidor.setText(
                processos.containsKey(s.nome)
                        ? "Servidor em execução"
                        : "Servidor parado"
        );

        escreverConsole(
                "Selecionado: " + s.nome
                        + "\nPasta: " + s.pasta.getAbsolutePath()
        );
    }

    private void salvarConfiguracaoSelecionada() {
        Servidor s = getSelecionado();

        if (s == null) {
            mensagemErro("Seleciona um servidor primeiro.");
            return;
        }

        if (processos.containsKey(s.nome)) {
            mensagemErro("Desliga o servidor antes de alterar as configurações.");
            return;
        }

        String nome = campoNome.getText().trim();

        if (nome.isEmpty() || nome.matches(".*[\\\\/:*?\"<>|].*")) {
            mensagemErro("O nome do servidor é inválido.");
            return;
        }

        File novaPasta = new File(pastaBase, nome);

        if (!novaPasta.equals(s.pasta) && novaPasta.exists()) {
            mensagemErro("Já existe uma pasta com esse nome.");
            return;
        }

        try {
            if (!novaPasta.equals(s.pasta)) {
                Files.move(s.pasta.toPath(), novaPasta.toPath());
                s.pasta = novaPasta;
            }

            s.nome = nome;
            s.versao = String.valueOf(campoVersao.getSelectedItem());
            s.loader = String.valueOf(campoLoader.getSelectedItem());
            s.ramMB = (Integer) campoRam.getValue();

            salvarServidor(s);
            carregarServidores();
            selecionarServidor(s.nome);

            escreverConsole("Configurações salvas.");
        } catch (IOException ex) {
            mensagemErro("Falha ao salvar: " + ex.getMessage());
        }
    }

    private void iniciarServidorSelecionado() {
        Servidor s = getSelecionado();

        if (s == null) {
            mensagemErro("Seleciona um servidor primeiro.");
            return;
        }

        if (processos.containsKey(s.nome)) {
            mensagemErro("Esse servidor já está ligado.");
            return;
        }

        if (!aceitouEula(s.pasta)) {
            mensagemErro("Este servidor ainda não tem eula.txt com eula=true. Abra a pasta do servidor, leia e aceite o EULA oficial e tente novamente.");
            abrirDiretorio(s.pasta);
            return;
        }

        File jar = encontrarJar(s.pasta);

        if (jar == null) {
            mensagemErro(
                    "Não encontrei um arquivo JAR executável na pasta.\n"
                            + "Instala ou coloca o servidor JAR nessa pasta."
            );
            return;
        }

        String java = encontrarJava(String.valueOf(campoJava.getSelectedItem()));

        if (java == null) {
            mensagemErro(
                    "Não encontrei uma instalação Java compatível.\n"
                            + "Instala o Java necessário para a versão do servidor."
            );
            return;
        }

        int ram = (Integer) campoRam.getValue();

        List<String> comando = new ArrayList<>();
        comando.add(java);
        comando.add("-Xms" + Math.min(1024, ram) + "M");
        comando.add("-Xmx" + ram + "M");
        comando.add("-jar");
        comando.add(jar.getName());
        comando.add("nogui");

        try {
            ProcessBuilder pb = new ProcessBuilder(comando);
            pb.directory(s.pasta);
            pb.redirectErrorStream(true);

            Process processo = pb.start();
            processos.put(s.nome, processo);
            reinicios.put(s.nome, false);

            escreverConsole("Iniciando " + s.nome + "...");
            estadoServidor.setText("Servidor iniciando...");

            Thread leitor = new Thread(() -> lerSaida(s.nome, processo));
            leitor.setDaemon(true);
            leitores.put(s.nome, leitor);
            leitor.start();

            Thread monitor = new Thread(() -> monitorarProcesso(s, processo));
            monitor.setDaemon(true);
            monitor.start();

        } catch (IOException ex) {
            mensagemErro("Falha ao iniciar o servidor: " + ex.getMessage());
        }
    }

    private boolean aceitouEula(File pasta) {
        File eula = new File(pasta, "eula.txt");

        if (!eula.isFile()) {
            return false;
        }

        Properties props = new Properties();

        try (FileInputStream in = new FileInputStream(eula)) {
            props.load(in);
            return "true".equalsIgnoreCase(props.getProperty("eula", "false").trim());
        } catch (IOException ex) {
            return false;
        }
    }

    private File encontrarJar(File pasta) {
        File[] arquivos = pasta.listFiles((dir, nome) ->
                nome.toLowerCase(Locale.ROOT).endsWith(".jar")
                        && !nome.toLowerCase(Locale.ROOT).contains("installer")
                        && !nome.toLowerCase(Locale.ROOT).contains("launcher")
        );

        if (arquivos == null || arquivos.length == 0) {
            return null;
        }

        Arrays.sort(arquivos, Comparator.comparing(File::getName));

        for (File arquivo : arquivos) {
            String nome = arquivo.getName().toLowerCase(Locale.ROOT);

            if (nome.contains("server") || nome.contains("paper")
                    || nome.contains("fabric") || nome.contains("forge")
                    || nome.contains("neoforge")) {
                return arquivo;
            }
        }

        return arquivos.length == 1 ? arquivos[0] : null;
    }

    private String encontrarJava(String escolha) {
        if (escolha.equals("Detectar automaticamente")) {
            return localizarJavaPadrao();
        }

        String versao = escolha.replace("Java ", "");
        String javaHome = System.getenv("JAVA_HOME");

        if (javaHome != null) {
            File bin = new File(javaHome, "bin/java");
            if (bin.isFile() && bin.canExecute()) {
                return bin.getAbsolutePath();
            }

            File exe = new File(javaHome, "bin/java.exe");
            if (exe.isFile() && exe.canExecute()) {
                return exe.getAbsolutePath();
            }
        }

        String[] caminhos = {
                "/usr/lib/jvm/java-" + versao + "-openjdk-amd64/bin/java",
                "/usr/lib/jvm/java-" + versao + "-openjdk/bin/java",
                "/usr/lib/jvm/jdk-" + versao + "/bin/java",
                "C:\\Program Files\\Java\\jdk-" + versao + "\\bin\\java.exe",
                "C:\\Program Files\\Eclipse Adoptium\\jdk-" + versao
                        + ".0.0-hotspot\\bin\\java.exe"
        };

        for (String caminho : caminhos) {
            File f = new File(caminho);
            if (f.isFile() && f.canExecute()) {
                return f.getAbsolutePath();
            }
        }

        return localizarJavaPadrao();
    }

    private String localizarJavaPadrao() {
        String home = System.getProperty("java.home");
        if (home != null) {
            File java = new File(home, "bin/java");
            if (java.isFile() && java.canExecute()) {
                return java.getAbsolutePath();
            }

            File exe = new File(home, "bin/java.exe");
            if (exe.isFile() && exe.canExecute()) {
                return exe.getAbsolutePath();
            }
        }

        return "java";
    }

    private void lerSaida(String nome, Process processo) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(processo.getInputStream()))) {
            String linha;

            while ((linha = br.readLine()) != null) {
                // A saída é consumida em segundo plano para não bloquear o processo;
                // o gerenciamento permanece na interface, sem console embutido.
            }
        } catch (IOException ignored) {
            // O processo pode encerrar o fluxo ao desligar.
        }
    }

    private void monitorarProcesso(Servidor s, Process processo) {
        int codigo;

        try {
            codigo = processo.waitFor();
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            return;
        }

        boolean reiniciar = Boolean.TRUE.equals(reinicios.get(s.nome));

        SwingUtilities.invokeLater(() -> {
            processos.remove(s.nome);
            leitores.remove(s.nome);
            reinicios.remove(s.nome);

            escreverConsole(
                    "Servidor finalizado com código " + codigo + "."
            );
            estadoServidor.setText("Servidor parado");

            if (reiniciar) {
                escreverConsole("Reiniciando servidor...");
                iniciarServidorSelecionado();
            }
        });
    }

    private void pararServidorSelecionado(boolean reiniciar) {
        Servidor s = getSelecionado();

        if (s == null) {
            mensagemErro("Seleciona um servidor primeiro.");
            return;
        }

        Process processo = processos.get(s.nome);

        if (processo == null) {
            mensagemErro("Esse servidor já está desligado.");
            return;
        }

        reinicios.put(s.nome, reiniciar);

        try {
            OutputStream stdin = processo.getOutputStream();
            stdin.write("stop\n".getBytes("UTF-8"));
            stdin.flush();

            escreverConsole(
                    reiniciar
                            ? "Pedido de reinício enviado..."
                            : "Pedido de desligamento enviado..."
            );
        } catch (IOException ex) {
            escreverConsole("Não foi possível enviar o comando stop.");
            processo.destroy();
        }
    }

    private void abrirPastaTipo(String tipo) {
        Servidor s = getSelecionado();

        if (s == null) {
            mensagemErro("Seleciona um servidor primeiro.");
            return;
        }

        File pasta = new File(s.pasta, tipo);

        if (!pasta.exists() && !pasta.mkdirs()) {
            mensagemErro("Não foi possível criar a pasta.");
            return;
        }

        abrirDiretorio(pasta);
    }

    private void importarArquivoTipo(String tipo) {
        Servidor s = getSelecionado();

        if (s == null) {
            mensagemErro("Seleciona um servidor primeiro.");
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Importar para " + tipo);

        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File origem = chooser.getSelectedFile();
        File pasta = new File(s.pasta, tipo);

        if (!pasta.exists() && !pasta.mkdirs()) {
            mensagemErro("Não foi possível criar a pasta de destino.");
            return;
        }

        File destino = new File(pasta, origem.getName());

        try {
            if (origem.isDirectory()) {
                if (destino.exists()) {
                    mensagemErro("Já existe uma pasta com esse nome.");
                    return;
                }
                copiarPasta(origem.toPath(), destino.toPath());
            } else {
                Files.copy(
                        origem.toPath(),
                        destino.toPath(),
                        StandardCopyOption.REPLACE_EXISTING
                );
            }

            escreverConsole(
                    "Arquivo importado para " + destino.getAbsolutePath()
            );
        } catch (IOException ex) {
            mensagemErro("Falha na importação: " + ex.getMessage());
        }
    }

    private void abrirDiretorio(File pasta) {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(pasta);
            } else {
                mensagemErro("O sistema não permite abrir pastas pelo launcher.");
            }
        } catch (IOException ex) {
            mensagemErro("Não foi possível abrir a pasta: " + ex.getMessage());
        }
    }

    private void atualizarMemoria() {
        long memoria = Runtime.getRuntime().maxMemory() / (1024L * 1024L);
        int limite = (int) Math.max(512, Math.min(32768, memoria - 512));

        SpinnerNumberModel modelo = (SpinnerNumberModel) campoRam.getModel();
        modelo.setMaximum(Math.max(512, limite));

        memoriaDisponivel.setText(
                "RAM máxima estimada para o launcher: "
                        + Math.max(512, limite) + " MB"
        );
    }

    private void escreverConsole(String texto) {
        // Compatibilidade com a lógica existente: mensagens viram status na interface,
        // sem acrescentar um console que ocupa espaço desnecessário.
        String linha = texto == null ? "" : texto.replace('\n', ' ').trim();
        if (!linha.isEmpty()) {
            if (mensagemInline != null) mensagemInline.setText(linha);
            if (estadoServidor != null) estadoServidor.setText(linha);
        }
    }

    private void mensagemErro(String texto) {
        if (mensagemInline != null) mensagemInline.setText(texto);
        if (estadoServidor != null) estadoServidor.setText(texto);
        if (painelDireito != null && cartoesDireita != null) {
            cartoesDireita.show(painelDireito, getSelecionado() == null ? "inicio" : "formulario");
        }
    }

    private static class Servidor {
        String nome;
        String versao;
        String loader;
        int ramMB;
        File pasta;

        Servidor(
                String nome,
                String versao,
                String loader,
                int ramMB,
                File pasta
        ) {
            this.nome = nome;
            this.versao = versao;
            this.loader = loader;
            this.ramMB = ramMB;
            this.pasta = pasta;
        }

        @Override
        public String toString() {
            return nome;
        }
    }
}