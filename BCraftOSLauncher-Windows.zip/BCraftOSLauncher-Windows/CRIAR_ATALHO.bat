@echo off
setlocal
cd /d "%~dp0"

if not exist "%~dp0EXECUTAR.bat" (
    echo Nao encontrei EXECUTAR.bat nesta pasta.
    pause
    exit /b 1
)

set "BC_LAUNCHER=%~dp0EXECUTAR.bat"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $launcher=$env:BC_LAUNCHER; $desktop=[Environment]::GetFolderPath('Desktop'); if ([string]::IsNullOrWhiteSpace($desktop)) { throw 'Nao encontrei a pasta Area de Trabalho.' }; $shell=New-Object -ComObject WScript.Shell; $shortcut=$shell.CreateShortcut([IO.Path]::Combine($desktop,'BCraftOS Launcher.lnk')); $shortcut.TargetPath=$launcher; $shortcut.WorkingDirectory=Split-Path -LiteralPath $launcher; $shortcut.Description='Abrir o BCraftOS Launcher'; $shortcut.Save(); Write-Host ('Atalho criado: ' + $shortcut.FullName)"
if errorlevel 1 (
    echo Nao foi possivel criar o atalho.
    pause
    exit /b 1
)

echo.
pause
exit /b 0