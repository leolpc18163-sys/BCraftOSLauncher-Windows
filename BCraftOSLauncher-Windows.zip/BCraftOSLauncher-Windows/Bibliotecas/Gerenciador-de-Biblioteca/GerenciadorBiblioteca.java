package BCraftOSproject1.BCraftOS1;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * A biblioteca local de mods e plugins.
 *
 * Tudo que você baixa do Modrinth vai primeiro para a pasta biblioteca/ e só depois é copiado para
 * o destino (um modpack ou um servidor). Assim o mesmo arquivo serve para vários modpacks e servidores
 * sem baixar de novo, e dá para instalar de novo a qualquer momento, até sem internet.
 *
 *   biblioteca/mods/neoforge/1.21.1/arquivo.jar
 *   biblioteca/plugins/paper/1.21.4/arquivo.jar
 *   biblioteca/modpacks/nome-do-modpack/arquivo.mrpack
 */
public final class GerenciadorBiblioteca {

	public static final String PASTA_MODS = "mods";
	public static final String PASTA_PLUGINS = "plugins";
	public static final String PASTA_MODPACKS = "modpacks";

	private static final int PROFUNDIDADE_DEPENDENCIAS = 3;

	private GerenciadorBiblioteca() {
	}

	public static File pastaBiblioteca() {
		return new File(System.getProperty("user.dir"), "biblioteca");
	}

	// ------------------------------------------------------------------
	// Destinos
	// ------------------------------------------------------------------

	/** Para onde um mod, plugin ou modpack pode ir: uma versão do cliente ou um servidor. */
	public static class Destino {
		public final String rotulo;
		public final boolean servidor;
		/** Nome do loader no Modrinth (forge, fabric, neoforge, paper...). Usado para organizar a biblioteca. */
		public final String loader;
		/** Todos os loaders que servem nesse destino (um servidor Paper aceita paper, spigot e bukkit). */
		public final List<String> loadersBusca;
		/** Versão do Minecraft, ou null quando não importa (proxy Velocity). */
		public final String versaoMc;
		/** Cliente: a pasta da versão (onde ficam os modpacks). */
		public final File pastaVersao;
		/** Servidor: a pasta mods/ ou plugins/ do servidor. */
		public final File pastaArquivos;

		Destino(String rotulo, boolean servidor, String loader, List<String> loadersBusca, String versaoMc,
				File pastaVersao, File pastaArquivos) {
			this.rotulo = rotulo;
			this.servidor = servidor;
			this.loader = loader;
			this.loadersBusca = loadersBusca;
			this.versaoMc = versaoMc;
			this.pastaVersao = pastaVersao;
			this.pastaArquivos = pastaArquivos;
		}

		@Override
		public String toString() {
			return rotulo;
		}
	}

	/** Descobre o Minecraft de uma versão instalada: "1.20.1-47.4.0" -> 1.20.1; NeoForge "21.1.72" -> 1.21.1. */
	static String mcDaVersaoInstalada(String loader, String codigo) {
		if (CatalogoVersoes.NEOFORGE.equalsIgnoreCase(loader)) {
			return CatalogoVersoes.converterVersaoNeoForge(codigo);
		}
		if (CatalogoVersoes.FORGE.equalsIgnoreCase(loader)) {
			int traco = codigo.indexOf('-');
			return traco > 0 ? codigo.substring(0, traco) : codigo;
		}
		return codigo; // Fabric usa a própria versão do jogo
	}

	/** Versões do cliente que já estão baixadas. Só entram as do formato novo (Loader/codigo). */
	public static List<Destino> destinosDeCliente() {
		List<Destino> destinos = new ArrayList<>();
		for (String entrada : GerenciadorVersoes.listarVersoesInstaladas()) {
			int barra = entrada.indexOf('/');
			if (barra <= 0) {
				continue;
			}
			String loader = entrada.substring(0, barra);
			String codigo = entrada.substring(barra + 1);
			String mc = mcDaVersaoInstalada(loader, codigo);
			if (mc == null) {
				continue;
			}
			String loaderModrinth = loader.toLowerCase(Locale.ROOT);
			File pastaVersao = GerenciadorVersoes.obterPastaDaVersao(loader, codigo);
			destinos.add(new Destino("Cliente · " + loader + " " + mc + " (" + codigo + ")", false, loaderModrinth,
					List.of(loaderModrinth), mc, pastaVersao, null));
		}
		return destinos;
	}

	/**
	 * Servidores criados ou importados no launcher.
	 * @param plugins verdadeiro: servidores que aceitam plugins; falso: servidores que aceitam mods
	 */
	public static List<Destino> destinosDeServidor(boolean plugins) {
		List<Destino> destinos = new ArrayList<>();
		for (GerenciadorServidores.Servidor s : GerenciadorServidores.listar()) {
			String tipo = s.tipo;
			List<String> loaders;
			String loaderPrincipal;
			String subpasta;
			if (plugins) {
				subpasta = "plugins";
				switch (tipo) {
					case CatalogoServidores.PAPER:
						loaders = List.of("paper", "spigot", "bukkit");
						break;
					case CatalogoServidores.PURPUR:
						loaders = List.of("purpur", "paper", "spigot", "bukkit");
						break;
					case CatalogoServidores.SPIGOT:
					case CatalogoServidores.ARCLIGHT:
						loaders = List.of("spigot", "bukkit", "paper");
						break;
					case CatalogoServidores.VELOCITY:
						loaders = List.of("velocity");
						break;
					default:
						continue;
				}
				loaderPrincipal = loaders.get(0);
			} else {
				subpasta = "mods";
				switch (tipo) {
					case CatalogoServidores.FORGE:
					case CatalogoServidores.NEOFORGE:
					case CatalogoServidores.FABRIC:
						loaderPrincipal = tipo.toLowerCase(Locale.ROOT);
						loaders = List.of(loaderPrincipal);
						break;
					default:
						continue;
				}
			}
			String mc = CatalogoServidores.ehProxy(tipo) ? null : s.versaoMc;
			destinos.add(new Destino("Servidor · " + s.nome + " (" + tipo + (mc == null ? "" : " " + mc) + ")", true,
					loaderPrincipal, loaders, mc, null, new File(s.pasta, subpasta)));
		}
		return destinos;
	}

	// ------------------------------------------------------------------
	// Resultado
	// ------------------------------------------------------------------

	public static class Resultado {
		public final List<String> instalados = new ArrayList<>();
		public final List<String> avisos = new ArrayList<>();
	}

	// ------------------------------------------------------------------
	// Instalar do Modrinth (com dependências)
	// ------------------------------------------------------------------

	/**
	 * Baixa a versão para a biblioteca, junto com as dependências obrigatórias, e copia tudo para o destino.
	 *
	 * @param tipo PASTA_MODS ou PASTA_PLUGINS
	 * @param nomeModpack só para destino de cliente: em qual modpack colocar
	 */
	public static Resultado instalar(CatalogoModrinth.Versao versao, String tipo, Destino destino, String nomeModpack,
			GerenciadorDownloads.Progresso progresso) throws Exception {
		File pastaFinal = pastaFinalDoDestino(destino, nomeModpack);
		pastaFinal.mkdirs();

		Resultado resultado = new Resultado();
		List<CatalogoModrinth.Versao> fila = new ArrayList<>();
		Set<String> projetosVistos = new HashSet<>();
		fila.add(versao);
		if (versao.projetoId != null) {
			projetosVistos.add(versao.projetoId);
		}
		progresso.atualizar("Procurando as dependências...", 2);
		reunirDependencias(versao, destino, fila, projetosVistos, resultado, PROFUNDIDADE_DEPENDENCIAS);

		for (int i = 0; i < fila.size(); i++) {
			CatalogoModrinth.Versao v = fila.get(i);
			int de = 5 + (90 * i) / fila.size();
			int ate = 5 + (90 * (i + 1)) / fila.size();
			File naBiblioteca = baixarParaBiblioteca(v, tipo, destino, progresso, de, ate);
			Files.copy(naBiblioteca.toPath(), new File(pastaFinal, naBiblioteca.getName()).toPath(),
					StandardCopyOption.REPLACE_EXISTING);
			resultado.instalados.add(naBiblioteca.getName());
		}
		progresso.atualizar("Pronto.", 100);
		return resultado;
	}

	private static void reunirDependencias(CatalogoModrinth.Versao versao, Destino destino,
			List<CatalogoModrinth.Versao> fila, Set<String> vistos, Resultado resultado, int profundidade) {
		if (profundidade <= 0) {
			return;
		}
		for (CatalogoModrinth.Dependencia dep : versao.dependencias) {
			if (!"required".equals(dep.tipo)) {
				continue;
			}
			if (dep.projetoId != null && !vistos.add(dep.projetoId)) {
				continue;
			}
			try {
				CatalogoModrinth.Versao v = null;
				if (dep.versaoId != null) {
					v = CatalogoModrinth.versaoPorId(dep.versaoId);
				} else if (dep.projetoId != null) {
					v = CatalogoModrinth.melhorVersao(dep.projetoId, destino.loadersBusca, destino.versaoMc);
				}
				if (v == null) {
					resultado.avisos.add("Dependência sem versão compatível: "
							+ (dep.projetoId != null ? CatalogoModrinth.tituloDoProjeto(dep.projetoId) : "desconhecida"));
					continue;
				}
				fila.add(v);
				reunirDependencias(v, destino, fila, vistos, resultado, profundidade - 1);
			} catch (Exception erro) {
				resultado.avisos.add("Não consegui resolver uma dependência (" + erro.getMessage() + ")");
			}
		}
	}

	private static File pastaFinalDoDestino(Destino destino, String nomeModpack) {
		if (destino.servidor) {
			return destino.pastaArquivos;
		}
		String nome = nomeSeguro(nomeModpack);
		if (nome.isEmpty()) {
			throw new IllegalStateException("Escolha ou crie um modpack para receber os mods.");
		}
		return new File(GerenciadorModpacks.obterPastaModpacks(destino.pastaVersao), nome);
	}

	/** Baixa o arquivo principal da versão para biblioteca/<tipo>/<loader>/<mc>/. Reaproveita se já estiver lá. */
	static File baixarParaBiblioteca(CatalogoModrinth.Versao v, String tipo, Destino destino,
			GerenciadorDownloads.Progresso progresso, int de, int ate) throws Exception {
		String nome = nomeDeArquivoSeguro(v.arquivo.nome);
		if (!nome.toLowerCase(Locale.ROOT).endsWith(".jar")) {
			throw new IOException("O arquivo \"" + v.arquivo.nome + "\" não é um .jar e não foi instalado.");
		}
		File pasta = new File(new File(new File(pastaBiblioteca(), tipo), nomeDeVersaoSeguro(destino.loader)),
				destino.versaoMc == null ? "qualquer" : nomeDeVersaoSeguro(destino.versaoMc));
		File arquivo = new File(pasta, nome);
		baixarVerificado(v.arquivo, arquivo, progresso, de, ate);
		return arquivo;
	}

	/** Baixa e confere o SHA-1. Se o arquivo já existe e confere, não baixa de novo. */
	static void baixarVerificado(CatalogoModrinth.Arquivo a, File destino, GerenciadorDownloads.Progresso progresso,
			int de, int ate) throws Exception {
		if (!CatalogoModrinth.enderecoPermitido(a.url)) {
			throw new IOException("Endereço de download não permitido: " + a.url);
		}
		if (destino.isFile() && a.sha1 != null && a.sha1.equalsIgnoreCase(sha1(destino))) {
			progresso.atualizar("Já estava na biblioteca: " + destino.getName(), ate);
			return;
		}
		destino.getParentFile().mkdirs();
		GerenciadorDownloads.baixarArquivo(a.url, destino, progresso, de, ate, "Baixando " + destino.getName());
		if (a.sha1 != null && !a.sha1.equalsIgnoreCase(sha1(destino))) {
			destino.delete();
			throw new IOException("O arquivo " + destino.getName() + " veio corrompido (SHA-1 diferente). Tente de novo.");
		}
	}

	// ------------------------------------------------------------------
	// Biblioteca local
	// ------------------------------------------------------------------

	public static class ItemBiblioteca {
		public final String tipo;
		public final String loader;
		public final String mc;
		public final File arquivo;

		ItemBiblioteca(String tipo, String loader, String mc, File arquivo) {
			this.tipo = tipo;
			this.loader = loader;
			this.mc = mc;
			this.arquivo = arquivo;
		}

		@Override
		public String toString() {
			return arquivo.getName() + "   ·   " + (PASTA_PLUGINS.equals(tipo) ? "plugin" : "mod") + " · " + loader
					+ " · " + mc;
		}
	}

	/** Tudo que já foi baixado (mods e plugins). */
	public static List<ItemBiblioteca> listarBiblioteca() {
		List<ItemBiblioteca> itens = new ArrayList<>();
		for (String tipo : new String[] { PASTA_MODS, PASTA_PLUGINS }) {
			File[] loaders = new File(pastaBiblioteca(), tipo).listFiles(File::isDirectory);
			if (loaders == null) {
				continue;
			}
			for (File pastaLoader : loaders) {
				File[] versoes = pastaLoader.listFiles(File::isDirectory);
				if (versoes == null) {
					continue;
				}
				for (File pastaMc : versoes) {
					File[] jars = pastaMc.listFiles((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(".jar"));
					if (jars == null) {
						continue;
					}
					for (File jar : jars) {
						itens.add(new ItemBiblioteca(tipo, pastaLoader.getName(), pastaMc.getName(), jar));
					}
				}
			}
		}
		itens.sort(Comparator.comparing(i -> i.arquivo.getName().toLowerCase(Locale.ROOT)));
		return itens;
	}

	/** Copia um item da biblioteca para o destino, depois de conferir se ele serve ali. */
	public static String instalarDaBiblioteca(ItemBiblioteca item, Destino destino, String nomeModpack)
			throws IOException {
		if (!destino.loadersBusca.contains(item.loader)) {
			throw new IllegalStateException("Esse item é para " + item.loader + " e o destino usa "
					+ String.join("/", destino.loadersBusca) + ".");
		}
		if (destino.versaoMc != null && !"qualquer".equals(item.mc) && !destino.versaoMc.equals(item.mc)) {
			throw new IllegalStateException("Esse item é para o Minecraft " + item.mc + " e o destino é "
					+ destino.versaoMc + ".");
		}
		File pastaFinal = pastaFinalDoDestino(destino, nomeModpack);
		pastaFinal.mkdirs();
		Files.copy(item.arquivo.toPath(), new File(pastaFinal, item.arquivo.getName()).toPath(),
				StandardCopyOption.REPLACE_EXISTING);
		return item.arquivo.getName();
	}

	/** Apaga um arquivo da biblioteca. Só age dentro da pasta biblioteca/. */
	public static void excluirDaBiblioteca(ItemBiblioteca item) throws IOException {
		File raiz = pastaBiblioteca().getCanonicalFile();
		File alvo = item.arquivo.getCanonicalFile();
		if (!alvo.getPath().startsWith(raiz.getPath() + File.separator)) {
			throw new IOException("Esse arquivo não está dentro da biblioteca.");
		}
		Files.deleteIfExists(alvo.toPath());
	}

	// ------------------------------------------------------------------
	// Modpacks do cliente
	// ------------------------------------------------------------------

	public static String[] listarModpacks(Destino destino) {
		GerenciadorModpacks.configurarDiretoriosIniciais(destino.pastaVersao);
		String[] nomes = GerenciadorModpacks.listarModpacksDisponiveis(destino.pastaVersao);
		if (nomes.length == 1 && nomes[0].startsWith("Nenhum")) {
			return new String[0];
		}
		return nomes;
	}

	/** Cria uma pasta de modpack vazia na versão e devolve o nome final. */
	public static String criarModpack(Destino destino, String nomeDigitado) {
		String nome = nomeSeguro(nomeDigitado);
		if (nome.isEmpty()) {
			throw new IllegalStateException("Dê um nome ao modpack (letras, números, espaço, '_' ou '-').");
		}
		File pasta = new File(GerenciadorModpacks.obterPastaModpacks(destino.pastaVersao), nome);
		if (pasta.exists()) {
			throw new IllegalStateException("Já existe um modpack chamado \"" + nome + "\" nessa versão.");
		}
		if (!pasta.mkdirs()) {
			throw new IllegalStateException("Não consegui criar a pasta do modpack.");
		}
		return nome;
	}

	// ------------------------------------------------------------------
	// Nomes e hash
	// ------------------------------------------------------------------

	/** Nome de pasta seguro: só letras, números, espaço, _ e -. */
	public static String nomeSeguro(String nome) {
		if (nome == null) {
			return "";
		}
		String limpo = nome.trim().replaceAll("[^a-zA-Z0-9 _-]", "_").replaceAll("\\s+", " ");
		return limpo.length() > 60 ? limpo.substring(0, 60).trim() : limpo;
	}

	/** Nome de pasta de loader/versão (mantém o ponto: 1.21.1). Nunca vira ".." nem sai da pasta. */
	static String nomeDeVersaoSeguro(String nome) {
		String limpo = nome == null ? "" : nome.replaceAll("[^a-zA-Z0-9._-]", "_");
		while (limpo.startsWith(".")) {
			limpo = limpo.substring(1);
		}
		return limpo.isEmpty() ? "qualquer" : limpo;
	}

	/** Nome de arquivo seguro: nunca tem barra, e nunca começa com ponto. */
	static String nomeDeArquivoSeguro(String nome) {
		String limpo = nome == null ? "" : nome.replaceAll("[^a-zA-Z0-9._+() -]", "_");
		while (limpo.startsWith(".")) {
			limpo = limpo.substring(1);
		}
		return limpo.isEmpty() ? "arquivo.jar" : limpo;
	}

	static String sha1(File arquivo) throws IOException {
		try (InputStream in = Files.newInputStream(arquivo.toPath())) {
			MessageDigest md = MessageDigest.getInstance("SHA-1");
			byte[] bloco = new byte[65536];
			int lidos;
			while ((lidos = in.read(bloco)) != -1) {
				md.update(bloco, 0, lidos);
			}
			StringBuilder sb = new StringBuilder();
			for (byte b : md.digest()) {
				sb.append(String.format("%02x", b));
			}
			return sb.toString();
		} catch (java.security.NoSuchAlgorithmException e) {
			throw new IOException(e);
		}
	}
}
