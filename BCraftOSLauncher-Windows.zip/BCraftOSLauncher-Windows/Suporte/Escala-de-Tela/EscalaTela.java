package BCraftOSproject1.BCraftOS1;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.KeyStroke;

/**
 * Deixa o layout do launcher do tamanho certo para a tela de cada computador.
 *
 * O desenho original foi pensado para uma tela de uns 900 px de altura. Em telas menores (notebook
 * de 1366x768) tudo encolhe um pouco; em telas grandes (Full HD, 2K, 4K) tudo cresce, para o launcher
 * não ficar pequeno num canto. O fator vai de 0,8 a 1,6. O Java já cuida do zoom do Windows (125%, 150%),
 * então aqui só olhamos o espaço útil da tela, já sem a barra de tarefas.
 */
public final class EscalaTela {

	/** Altura de tela em que o layout original foi desenhado. */
	private static final double ALTURA_BASE = 900.0;
	private static final double FATOR_MINIMO = 0.8;
	private static final double FATOR_MAXIMO = 1.6;

	private static final double FATOR = calcularFator();

	private EscalaTela() {
	}

	private static double calcularFator() {
		Rectangle util = areaUtil();
		double f = util.height / ALTURA_BASE;
		return Math.max(FATOR_MINIMO, Math.min(FATOR_MAXIMO, f));
	}

	/** O espaço útil da tela principal (sem a barra de tarefas). Sem tela (testes), assume Full HD. */
	public static Rectangle areaUtil() {
		try {
			if (!GraphicsEnvironment.isHeadless()) {
				GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
				Rectangle b = ge.getMaximumWindowBounds();
				if (b.width > 0 && b.height > 0) {
					return b;
				}
			}
		} catch (RuntimeException ignorado) {
			// cai no padrão abaixo
		}
		return new Rectangle(0, 0, 1920, 1040);
	}

	public static double fator() {
		return FATOR;
	}

	/** Um tamanho em pixels, ajustado à tela. */
	public static int px(int valor) {
		return (int) Math.round(valor * FATOR);
	}

	/** A fonte padrão do launcher, ajustada à tela. */
	public static Font fonte(int estilo, int tamanho) {
		return new Font("Arial", estilo, Math.max(9, (int) Math.round(tamanho * FATOR)));
	}

	/**
	 * Ajusta a janela ao conteúdo sem passar do tamanho da tela e centraliza. Se a pessoa maximizou
	 * (tela cheia), não mexe: o conteúdo já fica centralizado pelo próprio layout.
	 */
	public static void ajustarJanela(JFrame janela) {
		if ((janela.getExtendedState() & JFrame.MAXIMIZED_BOTH) != 0) {
			janela.revalidate();
			return;
		}
		janela.pack();
		Rectangle util = areaUtil();
		Dimension d = janela.getSize();
		int largura = Math.min(d.width + px(18), (int) (util.width * 0.96));
		int altura = Math.min(d.height, (int) (util.height * 0.96));
		janela.setSize(largura, altura);
		janela.setLocation(util.x + (util.width - largura) / 2, util.y + (util.height - altura) / 2);
	}

	/** Tamanho mínimo que a janela pode ter ao ser redimensionada à mão. */
	public static Dimension tamanhoMinimo() {
		Rectangle util = areaUtil();
		return new Dimension(Math.min(px(520), util.width), Math.min(px(420), util.height));
	}

	/** F11 liga e desliga a tela cheia (janela maximizada). */
	public static void instalarTeclaTelaCheia(JFrame janela) {
		JComponent raiz = janela.getRootPane();
		raiz.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0), "telaCheia");
		raiz.getActionMap().put("telaCheia", new AbstractAction() {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				boolean cheia = (janela.getExtendedState() & JFrame.MAXIMIZED_BOTH) != 0;
				janela.setExtendedState(cheia ? JFrame.NORMAL : JFrame.MAXIMIZED_BOTH);
			}
		});
	}

	/** Margens escaladas. */
	public static Insets margens(int cima, int esq, int baixo, int dir) {
		return new Insets(px(cima), px(esq), px(baixo), px(dir));
	}

	/** Só para a tela de diagnóstico: o tamanho do monitor reportado pelo Java. */
	public static Dimension tamanhoDaTela() {
		try {
			return Toolkit.getDefaultToolkit().getScreenSize();
		} catch (RuntimeException e) {
			return new Dimension(1920, 1080);
		}
	}
}
